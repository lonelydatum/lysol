(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.boy = function() {
	this.initialize(img.boy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.boy_frost = function() {
	this.initialize(img.boy_frost);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.germs_sm = function() {
	this.initialize(img.germs_sm);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,150,125);


(lib.hand_spray = function() {
	this.initialize(img.hand_spray);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,87,172);


(lib.ice = function() {
	this.initialize(img.ice);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,49,46);


(lib.product = function() {
	this.initialize(img.product);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,71,109);


(lib.spray_01 = function() {
	this.initialize(img.spray_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,141,93);


(lib.spray_02 = function() {
	this.initialize(img.spray_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);


(lib.text_cold = function() {
	this.initialize(img.text_cold);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.whatittaketoprotect = function() {
	this.initialize(img.whatittaketoprotect);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,65,22);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whitebox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebox, new cjs.Rectangle(0,0,728,90), null);


(lib.whatittakes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.whatittaketoprotect();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whatittakes, new cjs.Rectangle(0,0,65,22), null);


(lib.text_cold3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape.setTransform(478.625,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AAuBjIguiWIAAAAIgtCWIghAAIg5jEIAmAAIAlCNIAAAAIAtiNIAhAAIAsCNIAAAAIAniNIAjAAIg5DEg");
	this.shape_1.setTransform(453.9,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgIgTABgXQgBgXAIgTQAIgTAOgOQANgNAUgIQATgHAWAAQAWgBAUAIQATAHAOANQANAOAIATQAJATAAAXQAAAXgJATQgIATgNAOQgOANgTAIQgUAIgWAAQgWAAgTgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQANAGAOAAQAPAAAMgGQANgFAJgKQAJgKAFgNQAEgNABgPQgBgPgEgNQgFgMgJgKQgJgKgNgFQgMgFgPAAQgOAAgNAFg");
	this.shape_2.setTransform(428.65,19.1984);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_3.setTransform(409.075,19.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AhDBjIAAjEICCAAIAAAfIhfAAIAAAxIBaAAIAAAeIhaAAIAAA2IBkAAIAAAgg");
	this.shape_4.setTransform(393.075,19.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_5.setTransform(376.125,19.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_6.setTransform(360.175,19.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgqBgQgSgHgOgNQgOgOgIgTQgIgTAAgXQAAgXAIgTQAIgTAOgOQAOgNASgIQAUgHAWAAQAXgBATAIQATAHAOANQANAOAJATQAHATABAXQgBAXgHATQgJATgNAOQgOANgTAIQgTAIgXAAQgWAAgUgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQANAGAOAAQAPAAANgGQAMgFAJgKQAJgKAFgNQAFgNgBgPQABgPgFgNQgFgMgJgKQgJgKgMgFQgNgFgPAAQgOAAgNAFg");
	this.shape_7.setTransform(340.6,19.1984);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_8.setTransform(322.725,19.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AAgBjIgthUIgZAAIAABUIgjAAIAAjEIBEAAQANgBAOADQANADAKAGQAKAGAGALQAHALAAARQAAAVgMAPQgMAOgWACIA0BYgAgmgOIAbAAIAOgBQAIgBAGgCQAGgCAEgGQAEgGAAgJQAAgJgEgFQgDgGgGgCQgGgDgHgBIgNgBIgeAAg");
	this.shape_9.setTransform(306.725,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AA9BjIgTgtIhVAAIgRAtIgnAAIBVjEIAeAAIBUDEgAAdAXIgdhPIgfBPIA8AAg");
	this.shape_10.setTransform(287.05,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AAuBjIAAhYIhbAAIAABYIgjAAIAAjEIAjAAIAABOIBbAAIAAhOIAjAAIAADEg");
	this.shape_11.setTransform(266.7,19.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgaBgQgTgIgNgNQgOgNgIgTQgIgTAAgXQAAgXAIgTQAIgUAOgNQANgOATgHQATgIAWAAQAUABARAGQARAIAPARIgbATQgLgLgKgEQgKgDgLAAQgPAAgLAEQgNAGgIAJQgJALgFAMQgFANAAAPQAAAOAFAOQAFANAJAKQAIAJANAGQALAFAPABQAMgBAMgFQALgGAKgMIAdAUQgOATgTAIQgTAJgWgBQgWABgTgIg");
	this.shape_12.setTransform(247.375,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_cold3, new cjs.Rectangle(0,0,727,40.5), null);


(lib.text_cold_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.text_cold();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_cold_1, new cjs.Rectangle(0,0,300,250), null);


(lib.text_andFluSeason = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape.setTransform(185.925,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgQBjIAAjEIAhAAIAADEg");
	this.shape_1.setTransform(171,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape_2.setTransform(147.875,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgHgTgBgXQABgXAHgTQAIgTAOgOQANgNAUgIQASgHAXAAQAWgBATAIQAUAHAOANQAOAOAHATQAJATgBAXQABAXgJATQgHATgOAOQgOANgUAIQgTAIgWAAQgXAAgSgIgAgbhBQgNAFgIAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAIAKANAFQAMAGAPAAQAPAAANgGQAMgFAJgKQAJgKAFgNQAEgNAAgPQAAgPgEgNQgFgMgJgKQgJgKgMgFQgNgFgPAAQgPAAgMAFg");
	this.shape_3.setTransform(125.2,19.1984);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_4.setTransform(105.325,19.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AA9BjIgTgtIhUAAIgSAtIgnAAIBVjEIAeAAIBVDEgAAdAXIgdhPIgfBPIA8AAg");
	this.shape_5.setTransform(87.6,19.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AhDBjIAAjEICCAAIAAAfIhfAAIAAAxIBaAAIAAAeIhaAAIAAA2IBkAAIAAAgg");
	this.shape_6.setTransform(69.575,19.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_7.setTransform(52.275,19.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgeBfQgPgFgKgKQgLgKgGgOQgGgOAAgTIAAh7IAjAAIAAB6QAAAIACAIQACAHAGAHQAFAHAIAFQAJADALAAQANAAAIgDQAJgFAFgHQAFgHACgHQACgIAAgIIAAh6IAjAAIAAB7QAAATgGAOQgGAOgKAKQgLAKgOAFQgPAGgRAAQgQAAgOgGg");
	this.shape_8.setTransform(26.325,19.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_9.setTransform(10.025,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("Ag/BjIAAjEIB+AAIAAAfIhbAAIAAA0IBXAAIAAAfIhXAAIAABSg");
	this.shape_10.setTransform(-5.5,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("Ag0BkQgMgEgJgHQgJgIgGgKQgGgLAAgOQAAgLAEgIQADgIAGgIQAGgGAHgFQAIgGAJgDIgJgKIgHgLIgFgLQgBgGAAgHQgBgMAFgJQAFgKAHgFQAIgHAKgCQALgEALAAQALAAAJAEQAKACAHAGQAJAGAEAIQAEAKAAALQAAAJgDAIQgDAHgFAHQgHAHgHAEIgNAJIAfAhIAWggIAnAAIgnA4IAqAvIgrAAIgVgXQgMAOgOAHQgMAHgTgBQgNAAgMgDgAgoARIgJAGIgFAJQgDAFAAAHQAAAGADAGQACAFAEAEQAFAEAGACQAFACAGAAQALABAJgHIAQgNIgogsgAghhDQgHAFAAAKIABAHIAFAIIAGAGIAGAHIAJgFIAJgHQAEgDABgFQADgEAAgGQAAgIgFgGQgGgEgJAAQgLgBgGAGg");
	this.shape_11.setTransform(-32.1,19.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhYBjIAAjEIBOAAQASgBASAHQATAGANAMQAOAMAJASQAIATAAAYQAAAagKASQgJATgPALQgPANgTAFQgSAHgRAAgAg1BDIAaAAQARAAAOgEQAOgEALgHQALgJAGgNQAGgMAAgSQAAgRgFgNQgGgMgKgJQgKgHgNgEQgNgEgQAAIggAAg");
	this.shape_12.setTransform(-61.125,19.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_13.setTransform(-78.525,19.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgHgTAAgXQAAgXAHgTQAIgTAOgOQANgNAUgIQATgHAWAAQAXgBASAIQAUAHAOANQAOAOAHATQAJATgBAXQABAXgJATQgHATgOAOQgOANgUAIQgSAIgXAAQgWAAgTgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQANAGAOAAQAPAAAMgGQANgFAJgKQAJgKAFgNQAEgNABgPQgBgPgEgNQgFgMgJgKQgJgKgNgFQgMgFgPAAQgOAAgNAFg");
	this.shape_14.setTransform(-98.2,19.1984);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgaBgQgTgIgNgNQgOgNgIgTQgIgTAAgXQAAgXAIgTQAIgUAOgNQANgOATgHQATgIAWAAQAUABARAGQARAIAPARIgbATQgLgLgKgEQgKgDgLAAQgPAAgLAEQgNAGgIAJQgJALgFAMQgFANAAAPQAAAOAFAOQAFANAJAKQAIAJANAGQALAFAPABQAMgBAMgFQALgGAKgMIAdAUQgOATgTAIQgTAJgWgBQgWABgTgIg");
	this.shape_15.setTransform(-118.825,19.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_16.setTransform(-145.375,19.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgNAlIAAhJIAbAAIAABJg");
	this.shape_17.setTransform(-157.125,13.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_18.setTransform(-169.225,19.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgRBjIAAjEIAiAAIAADEg");
	this.shape_19.setTransform(-181.1,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_andFluSeason, new cjs.Rectangle(-357.9,0,727.9,40.5), null);


(lib.spray_mist = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray_02();
	this.instance.setTransform(53,49,0.6474,0.6474);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.7467,scaleY:0.7467,rotation:180,x:262,y:250},0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0.118)","#FFFFFF","rgba(255,255,255,0)"],[0,0,0,1],0,0,0,0,0,73.3).s().p("AoCIDQjVjVAAkuQAAktDVjVQDWjVEsAAQEuAADVDVQDVDVAAEtQAAEujVDVQjVDVkuAAQksAAjWjVg");
	this.shape.setTransform(153.9,148.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-307.5,-189.5,1129.1,765);


(lib.spray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray_01();
	this.instance.setTransform(4.5,0,1,0.8635,3.2113);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,88.1);


(lib.product_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.product();
	this.instance.setTransform(0,0,0.57,0.57);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.product_1, new cjs.Rectangle(0,0,40.5,62.2), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(0,0,49,46), null);


(lib.ice_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ice();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ice_1, new cjs.Rectangle(0,0,300,250), null);


(lib.girl = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.boy();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girl, new cjs.Rectangle(0,0,728,90), null);


(lib.germs_group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.germs_sm();
	this.instance.setTransform(-106,145,1,1,180);

	this.instance_1 = new lib.germs_sm();
	this.instance_1.setTransform(352,296,1,1,0,180,0);

	this.instance_2 = new lib.germs_sm();
	this.instance_2.setTransform(489,317,1,1,-90);

	this.instance_3 = new lib.germs_sm();
	this.instance_3.setTransform(-156,264,1,1,0,180,0);

	this.instance_4 = new lib.germs_sm();
	this.instance_4.setTransform(43,145,1,1,180);

	this.instance_5 = new lib.germs_sm();
	this.instance_5.setTransform(687,40,1,1,90);

	this.instance_6 = new lib.germs_sm();
	this.instance_6.setTransform(417,46);

	this.instance_7 = new lib.germs_sm();
	this.instance_7.setTransform(-8,146,1,1,0,-90,90);

	this.instance_8 = new lib.germs_sm();
	this.instance_8.setTransform(112,297,1,1,-90);

	this.instance_9 = new lib.germs_sm();
	this.instance_9.setTransform(217,291,1,1,0,180,0);

	this.instance_10 = new lib.germs_sm();
	this.instance_10.setTransform(421,20,1,1,90);

	this.instance_11 = new lib.germs_sm();
	this.instance_11.setTransform(310,20,1,1,90);

	this.instance_12 = new lib.germs_sm();
	this.instance_12.setTransform(40,26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.germs_group, new cjs.Rectangle(-256,20,943,297), null);


(lib.frost = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.boy_frost();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.frost, new cjs.Rectangle(0,0,728,90), null);


(lib.copy_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AgCADQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgCg");
	this.shape.setTransform(205.375,9.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_1.setTransform(203.3,6.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_2.setTransform(200.175,8.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgHAdIgFgGIAAAHIgHAAIAAg8IAHAAIAAAdQACgDAEgCQADgCADAAQAFAAADACIAGAEIAEAFQACAEAAAEQAAAEgCAEIgEAGIgFAEQgEACgEAAQgEAAgEgCgAgFgBIgEACQgCACAAADIgBAFIABAGQAAAAAAABQAAABABAAQAAABAAAAQABAAAAABIAEADIAFABIAFgBIAFgDIACgEIABgGIgBgFIgCgFIgFgCIgFgBIgFABg");
	this.shape_3.setTransform(195.625,7.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_4.setTransform(190.975,8.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_5.setTransform(188,6.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_6.setTransform(182.675,8.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AAKAeIAAgWQAAgFgCgDQgCgBgEAAIgFABIgDACIgCAEIgBAGIAAASIgGAAIAAg7IAGAAIAAAcIAAAAIACgCIADgCIADgCIADAAIAGABIAFADQACACAAACIABAGIAAAXg");
	this.shape_7.setTransform(178.275,6.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AAAAXIgCgCIgBgEIgBgFIAAgTIgIAAIAAgGIAIAAIAAgKIAGAAIAAAKIALAAIAAAGIgLAAIAAARIAAADIAAADIACACIADABIADAAIADgCIAAAGIgEABIgDAAIgGgBg");
	this.shape_8.setTransform(174.625,7.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AAKATIgKgcIAAAAIgJAcIgGAAIgNglIAIAAIAIAcIAKgcIAGAAIAKAcIAIgcIAGAAIgMAlg");
	this.shape_9.setTransform(168.1,8.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgIASIgFgEIgFgGIgBgIQAAgDABgEQACgEADgCIAFgEQAFgCADAAIAIACIAGAEQADACABAEQACAEAAADQAAAEgCAEIgEAGIgGAEIgIACQgDAAgFgCgAgEgMIgFADIgCAFIgBAEIABAGIACAEIAFADIAEABIAFgBIAEgDIADgEIABgGIgBgEIgDgFIgEgDIgFgBIgEABg");
	this.shape_10.setTransform(162.8,8.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_11.setTransform(159.45,6.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_12.setTransform(157.55,6.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgIASIgFgEIgFgGIgBgIQAAgDABgEQACgEADgCIAFgEQAFgCADAAIAIACIAGAEQADACABAEQACAEAAADQAAAEgCAEIgEAGIgGAEIgIACQgDAAgFgCgAgEgMIgFADIgDAFIAAAEIAAAGIADAEIAFADIAEABIAGgBIADgDIADgEIABgGIgBgEIgDgFIgDgDIgGgBIgEABg");
	this.shape_13.setTransform(154.25,8.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgEAfIAAgfIgIAAIAAgGIAIAAIAAgIIABgGIACgFIADgEIAGgBIADABIACAAIAAAGIgFgBIgEABIgBACIgBAEIAAAEIAAAHIAJAAIAAAGIgJAAIAAAfg");
	this.shape_14.setTransform(150.75,6.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_15.setTransform(144.675,7.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AAKATIAAgVQAAgFgCgDQgCgCgEAAIgEABIgEADIgCAEIgBAFIAAASIgGAAIAAgbIgBgFIAAgEIAHAAIAAADIAAADIAAAAIABgDIAEgCIADgCIADAAIAGABIAFADQACACABADIABAGIAAAWg");
	this.shape_16.setTransform(140.1,8.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_17.setTransform(135.775,8.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_18.setTransform(129.075,7.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_19.setTransform(124.575,8.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_20.setTransform(120.375,8.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgJATIAAgbIgBgFIAAgEIAGAAIAAADIAAADIABAAIABgDIACgCIAEgCIAEAAIABAAIACAAIgBAHIgDgBQgGAAgBAEQgDAEAAAFIAAASg");
	this.shape_21.setTransform(116.975,8.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_22.setTransform(111.425,8.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgOAcIgDgBIABgFIACABIACAAQABAAABAAQABAAAAgBQABAAAAAAQABAAAAgBIACgEIADgIIgPgkIAHAAIAKAcIABAAIAKgcIAIAAIgTAtIgBAEIgCAEIgEACIgFAAg");
	this.shape_23.setTransform(107.85,9.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_24.setTransform(103.775,8.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AAKATIgKgcIAAAAIgJAcIgGAAIgNglIAIAAIAIAcIAKgcIAGAAIAKAcIAIgcIAGAAIgMAlg");
	this.shape_25.setTransform(98.8,8.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_26.setTransform(94.9,6.975);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2B3785").s().p("AAUAcIgGgOIgbAAIgGAOIgIAAIAZg3IAGAAIAYA3gAALAIIgLgbIgLAbIAWAAg");
	this.shape_27.setTransform(91.175,7.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B3785").s().p("AgCADQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgCg");
	this.shape_28.setTransform(85.075,9.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_29.setTransform(81.475,7.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_30.setTransform(76.925,8.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2B3785").s().p("AAAAXIgCgCIgBgEIgBgFIAAgTIgIAAIAAgGIAIAAIAAgKIAGAAIAAAKIALAAIAAAGIgLAAIAAARIAAADIAAADIACACIADABIADAAIADgCIAAAGIgEABIgDAAIgGgBg");
	this.shape_31.setTransform(73.275,7.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2B3785").s().p("AgFASIgGgEQgCgCgCgEIgBgIIABgHIAEgGIAGgEIAHgCQAFAAADACQAEABADADIgFAFIgFgEIgFgBIgEABIgEADIgCAFIgBAEIABAFIACAFIAEADIAEABQAHAAADgFIAFAFQgDADgEABIgIACIgHgCg");
	this.shape_32.setTransform(70.125,8.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_33.setTransform(65.875,8.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2B3785").s().p("AgJATIAAgbIgBgFIAAgEIAGAAIAAADIAAADIABAAIABgDIACgCIAEgCIAEAAIABAAIACAAIgBAHIgDgBQgGAAgBAEQgDAEAAAFIAAASg");
	this.shape_34.setTransform(62.475,8.075);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2B3785").s().p("AgCAcIAAgkIAFAAIAAAkgAgCgUQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAIACgBIADABIACADIgCADQAAABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQgBAAAAgBg");
	this.shape_35.setTransform(59.9,7.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_36.setTransform(56.475,7.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2B3785").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_37.setTransform(50.175,8.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_38.setTransform(46.375,8.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_39.setTransform(39.675,7.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_40.setTransform(35.125,8.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2B3785").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_41.setTransform(31.175,8.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2B3785").s().p("AgIASIgEgDQgCgCAAgDIgBgGIAAgWIAFAAIAAAVQABAFACADQACACAEAAIAFgBIADgDQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIABgFIAAgSIAGAAIAAAbIAAAFIAAAEIgFAAIAAgDIAAgDIgBAAIgCADIgDACIgDACIgEAAIgGgBg");
	this.shape_42.setTransform(27.35,8.175);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#2B3785").s().p("AALATIAAgVQAAgFgDgDQgCgCgEAAIgFABIgDADIgCAEIgBAFIAAASIgGAAIAAgbIAAgFIAAgEIAFAAIAAADIAAADIABAAIACgDIADgCIADgCIAEAAIAFABIAFADQACACAAADIABAGIAAAWg");
	this.shape_43.setTransform(20.7,8.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_44.setTransform(16.325,8.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2B3785").s().p("AAKAeIAAgWQAAgFgCgDQgCgBgEAAIgFABIgDACIgCAEIgBAGIAAASIgGAAIAAg7IAGAAIAAAcIAAAAIACgCIADgCIADgCIADAAIAGABIAFADQACACAAACIABAGIAAAXg");
	this.shape_45.setTransform(11.925,6.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2B3785").s().p("AAOAcIgOgvIgNAvIgIAAIgQg3IAHAAIAOAuIANguIAHAAIAOAuIANguIAHAAIgQA3g");
	this.shape_46.setTransform(5.85,7.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_04, new cjs.Rectangle(0,0,208.7,15), null);


(lib.copy_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AgHAVIgHgFIgGgHQgBgEAAgFIABgIIAGgHQACgDAFgBQAEgCADAAQAEAAAEACQAFABACADQAEADACAEIABAIQAAAFgBAEQgCAEgEADQgCADgFACQgEABgEAAQgDAAgEgBg");
	this.shape.setTransform(351.45,23.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgcA6QgMgEgJgJIAWgYQAFAGAHADQAGAEAHAAQAGAAAFgCQAFgCAAgFQAAgEgFgCQgEgDgGgBIgOgEQgIgBgHgEQgHgEgEgFQgFgHAAgLQAAgKAFgIQADgHAIgFQAGgFAJgCQAJgCAIAAQALAAAMADQAMADAIAJIgWAWQgIgKgMAAQgEAAgEACQgFACAAAGQAAAEAFACIAKAEIAPADQAHACAHAEQAHADAEAGQAFAHAAALQAAALgFAHQgFAIgHAEQgJAFgJABQgKACgIAAQgMAAgNgDg");
	this.shape_1.setTransform(342.35,20.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AA3A8IAAhDQABgIgEgGQgDgGgJAAQgGAAgFACQgEACgCAEQgDADgBAFIgBAKIAAA9IgjAAIAAg9IgBgIIgBgIQgBgEgEgDQgDgDgGAAQgHAAgFACQgEADgCAEQgCAEgBAGIAAAKIAAA6IgkAAIAAh0IAiAAIAAAQIABAAIAEgHIAHgGIAKgEQAGgCAHAAQAMAAAJAFQAIAFAGALQAGgLAIgFQAKgFANAAQALAAAIAEQAIAEAFAHQAEAHACAJQACAJAAALIAABEg");
	this.shape_2.setTransform(326.4,20.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgoA8IAAh0IAkAAIAAATQAFgLAIgFQAIgGAMAAIAGAAIAGABIAAAhIgIgBIgHgBQgLAAgGADQgGADgDAFQgDAFgBAHIAAAPIAAAxg");
	this.shape_3.setTransform(311.6,20.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgTA5QgMgEgJgJQgJgIgFgLQgFgLAAgOQAAgNAFgLQAFgMAJgIQAJgIAMgEQAMgEAMAAQANAAAKAEQAKAEAHAIQAHAIAEAMQAEALAAANIAAALIhTAAQACALAIAGQAHAGAJAAQAJAAAGgEQAHgEAEgGIAZASQgIALgNAGQgOAGgOAAQgMAAgMgEgAgIggQgEABgEAEQgDACgCAEIgCAJIAvAAQAAgJgGgHQgGgGgKAAQgFAAgFACg");
	this.shape_4.setTransform(299.325,20.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgiBVQgPgDgNgKIAUgeQAJAHAJAEQAJAEALAAQAQAAAIgIQAHgIAAgNIAAgLIAAAAQgGAIgKAEQgJAEgHAAQgNAAgLgFQgKgFgIgHQgHgJgEgJQgEgMAAgNQAAgMADgLQAEgKAHgJQAHgIAKgFQAJgGANAAQAIABAFABIALAFIAJAFIAGAHIAAAAIAAgQIAhAAIAABqQAAAhgQASQgRAQghABQgQgBgPgDgAgJg1QgFACgEAEIgGAJQgCAFAAAGQAAAGACAFIAGAJQAEAEAFADQAFABAFAAQAGAAAGgBQAFgDAEgEIAGgJQACgFAAgGQAAgGgCgFIgGgJQgEgEgFgCQgGgDgGAAQgFAAgFADg");
	this.shape_5.setTransform(284.525,22.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgiA3QgJgEgEgHQgFgIgCgKQgBgKAAgMIAAg/IAkAAIAAA5IAAAKIACAKQACAEAEADQADADAIAAQAFAAAFgDQAEgCACgEIADgKIABgKIAAg6IAkAAIAAB0IgiAAIAAgQIgBAAIgFAHIgHAGIgJAEQgFACgHAAQgOAAgIgFg");
	this.shape_6.setTransform(263.4,20.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgRBbIAAi1IAjAAIAAC1g");
	this.shape_7.setTransform(253.4,16.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgVBcIAAhYIgXAAIAAgbIAXAAIAAgVQAAgKACgIQACgJAFgGQAEgHAIgDQAJgEAPAAIALAAIAKACIgCAfIgFgCIgGgBQgJAAgEAEQgFAEAAALIAAATIAbAAIAAAbIgbAAIAABYg");
	this.shape_8.setTransform(246.125,16.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AguBWQgLgDgJgHQgIgGgFgJQgFgKAAgNQAAgHADgIQACgIAFgGQAFgFAHgEIAOgHIgIgJIgGgIIgEgKIgBgLQAAgMAFgHQAEgJAHgFQAIgGAJgCQAKgCAKAAQAKgBAIADQAJADAHAFQAGAFAEAIQAFAIAAALQAAAHgDAGQgCAHgFAGIgKAKIgMAIIAWAWIARgVIApAAIgjAuIAlAoIguAAIgOgQQgLALgMAEQgLAGgPAAQgLgBgLgDgAghARIgGAFIgFAGQgBAEAAAEQAAAFACAEQACAEADADQADACAEACIAIABQAJABAGgEQAGgDAFgGIgdghgAgag3QgFAEAAAIIACAGIADAFIAFAGIAEADIAHgDIAGgFIAEgGQABgEAAgDQAAgHgDgEQgFgFgHAAQgHABgFAEg");
	this.shape_9.setTransform(225.675,17.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgdBYQgKgFgIgIQgHgIgEgLQgEgLAAgNQAAgMADgLQAEgLAHgIQAHgJAKgFQAJgFANAAQAKAAAKADQAKAEAGAIIAAAAIAAhNIAkAAIAAC0IghAAIAAgPIAAAAIgGAGIgIAGIgKAEQgGACgFAAQgNAAgLgEgAgTAKQgHAIAAANQAAANAHAIQAIAIAMAAQAOAAAIgIQAHgIAAgNQAAgNgHgIQgIgJgOAAQgMAAgIAJg");
	this.shape_10.setTransform(201.125,17.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgRBbIAAi1IAjAAIAAC1g");
	this.shape_11.setTransform(190.85,16.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgYA5QgMgEgJgJQgJgIgFgLQgFgLAAgOQAAgNAFgLQAFgMAJgIQAJgIAMgEQAMgEAMAAQANAAAMAEQAMAEAJAIQAJAIAFAMQAFALAAANQAAAOgFALQgFALgJAIQgJAJgMAEQgMAEgNAAQgMAAgMgEgAgUgUQgIAIAAAMQAAANAIAIQAHAIANAAQAOAAAHgIQAIgIAAgNQAAgMgIgIQgHgJgOAAQgNAAgHAJg");
	this.shape_12.setTransform(180.475,20.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgNA5QgMgEgIgJQgJgIgFgLQgFgLAAgOQAAgNAFgLQAFgMAJgIQAIgIAMgEQAMgEANAAQAKAAALADQAMAEAIAIIgYAZQgCgEgFgCQgFgDgFAAQgNAAgIAJQgHAIAAAMQAAANAHAIQAIAIANAAQAGAAAEgCIAHgGIAYAYQgIAJgMAEQgLADgKAAQgNAAgMgEg");
	this.shape_13.setTransform(167.825,20.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgVBcIAAhYIgXAAIAAgbIAXAAIAAgVQAAgKACgIQACgJAFgGQAEgHAIgDQAJgEAPAAIALAAIAKACIgCAfIgFgCIgGgBQgJAAgEAEQgFAEAAALIAAATIAbAAIAAAbIgbAAIAABYg");
	this.shape_14.setTransform(150.325,16.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgYA5QgMgEgJgJQgJgIgFgLQgFgLAAgOQAAgNAFgLQAFgMAJgIQAJgIAMgEQAMgEAMAAQANAAAMAEQAMAEAJAIQAJAIAFAMQAFALAAANQAAAOgFALQgFALgJAIQgJAJgMAEQgMAEgNAAQgMAAgMgEgAgUgUQgIAIAAAMQAAANAIAIQAHAIANAAQAOAAAHgIQAIgIAAgNQAAgMgIgIQgHgJgOAAQgNAAgHAJg");
	this.shape_15.setTransform(138.375,20.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AAAAOIgMARIgNgKIANgRIgUgGIAFgPIAUAIIAAgWIAPAAIAAAWIAUgHIAFAPIgUAFIANASIgNAKg");
	this.shape_16.setTransform(120.225,9.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("Ag5BSIBgitIAUALIhiCsgAAqBUQgJgDgGgHQgGgGgEgJQgEgJAAgKQAAgKAEgJQAEgIAGgGQAGgHAJgCQAJgFAJAAQAKAAAJAFQAJACAGAHQAGAGAEAIQAEAJAAAKQAAAKgEAJQgEAJgGAGQgGAHgJADQgJAEgKAAQgJAAgJgEgAAsAYQgGAHAAAJQAAAKAGAGQAHAIAJAAQAKAAAHgIQAGgGAAgKQAAgJgGgHQgHgHgKAAQgJAAgHAHgAhOADQgIgDgHgGQgGgGgEgJQgEgJAAgKQAAgJAEgJQAEgIAGgHQAHgGAIgEQAJgEAKAAQAKAAAIAEQAJAEAGAGQAHAHADAIQAEAJAAAJQAAAKgEAJQgDAJgHAGQgGAGgJADQgIAEgKAAQgKAAgJgEgAhMg3QgGAGAAAJQAAAKAGAHQAHAHAKAAQAJAAAHgHQAHgHAAgKQAAgJgHgGQgHgIgJABQgKgBgHAIg");
	this.shape_17.setTransform(105.575,17.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AglBXIAng9IgFABIgGAAQgMABgKgFQgJgEgIgHQgHgIgDgJQgFgKAAgMQABgNAFgLQAEgKAJgIQAJgIALgEQAMgFAMABQANgBAMAFQAMAEAIAIQAJAIAFAKQAEALAAANQAAAJgCAHIgDAOIgIANIgHAMIgmA7gAgTgtQgIAIAAALQAAAMAIAHQAIAHALAAQANAAAHgHQAIgHgBgMQABgLgIgIQgHgHgNAAQgLAAgIAHg");
	this.shape_18.setTransform(87.65,17.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgHAVIgHgFIgGgHQgBgEAAgFIABgIIAGgHQACgDAFgBQAEgCADAAQAEAAAEACQAFABACADQAEADACAEIABAIQAAAFgBAEQgCAEgEADQgCADgFACQgEABgEAAQgDAAgEgBg");
	this.shape_19.setTransform(76.95,23.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AglBXIAng9IgFABIgGAAQgMABgKgFQgJgEgIgHQgHgIgEgJQgDgKAAgMQAAgNAEgLQAGgKAIgIQAJgIALgEQALgFANABQANgBAMAFQAMAEAIAIQAJAIAEAKQAGALAAANQAAAJgCAHIgFAOIgHANIgHAMIgmA7gAgTgtQgIAIABALQgBAMAIAHQAIAHALAAQANAAAHgHQAIgHAAgMQAAgLgIgIQgHgHgNAAQgLAAgIAHg");
	this.shape_20.setTransform(66.35,17.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AglBXIAmg9IgEABIgGAAQgMABgKgFQgKgEgGgHQgHgIgFgJQgDgKAAgMQAAgNAEgLQAGgKAIgIQAJgIALgEQAMgFAMABQANgBAMAFQAMAEAIAIQAJAIAEAKQAGALAAANQgBAJgBAHIgFAOIgGANIgIAMIglA7gAgTgtQgHAIAAALQAAAMAHAHQAIAHALAAQAMAAAIgHQAHgHAAgMQAAgLgHgIQgIgHgMAAQgLAAgIAHg");
	this.shape_21.setTransform(52.15,17.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgRBbIAAi1IAjAAIAAC1g");
	this.shape_22.setTransform(34.8,16.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgRBbIAAi1IAjAAIAAC1g");
	this.shape_23.setTransform(28.6,16.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgRBXIAAhzIAjAAIAABzgAgOgyQgGgGAAgJQAAgJAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAJQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape_24.setTransform(22.425,17.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AAbBVIhEhRIAABRIglAAIAAipIAlAAIAABGIBBhGIAxAAIhLBPIBRBag");
	this.shape_25.setTransform(11.825,17.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_03, new cjs.Rectangle(0,0,357.2,36.8), null);


(lib.copy_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAXBDIAAhAIAAgLQgBgGgCgFQgCgFgEgDQgFgEgIAAQgGAAgFADQgFADgCAFQgDAFgBAFIAAAMIAABBIgpAAIAAiCIAmAAIAAASIABAAIAGgIIAIgGIAKgFQAGgCAIAAQAPAAAJAFQAKAEAFAJQAGAIACALQABAMAAANIAABHg");
	this.shape.setTransform(291.2,54.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgbBAQgOgFgKgJQgJgJgHgNQgFgNAAgPQAAgOAFgOQAHgMAJgJQAKgJAOgFQAMgFAPAAQAPAAAOAFQANAFAJAJQAKAJAGAMQAGAOAAAOQAAAPgGANQgGANgKAJQgJAJgNAFQgOAFgPAAQgPAAgMgFgAgXgXQgJAJAAAOQAAAOAJAKQAIAJAPAAQAPAAAJgJQAIgKAAgOQAAgOgIgJQgJgJgPAAQgPAAgIAJg");
	this.shape_1.setTransform(275.15,54.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgfBBQgPgEgJgKIAYgbQAGAHAHADQAHAEAJAAQAGAAAGgCQAGgCgBgFQAAgGgEgCIgMgFIgRgDQgIgDgIgEQgIgDgFgHQgEgHAAgMQgBgMAFgJQAEgIAJgFQAHgGAKgCQAKgDAKAAQANAAANAEQANADAJALIgZAYQgJgLgOAAQgFAAgEACQgGADAAAFQAAAFAGADIALAEIARADQAIADAJAEQAHAFAFAFQAFAIAAAMQAAANgGAJQgFAIgIAEQgJAFgLADQgLACgJAAQgOAAgOgEg");
	this.shape_2.setTransform(260.55,54.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AghBCQgJgDgGgEQgGgFgEgJQgEgHAAgKQAAgLAEgIQAEgIAHgEQAIgFAJgDIATgEIASgCIASAAQAAgLgHgGQgIgGgKAAQgJgBgJAFQgHAEgHAIIgWgXQAMgKAOgGQAPgFAQAAQASAAALAEQALAFAIAJQAGAIADANQADAMAAARIAABCIgmAAIAAgRIAAAAQgHALgLAEQgKAFgNAAQgIAAgJgDgAAEAIIgMADQgHACgEADQgFAEABAHQgBAHAHAEQAGADAHAAQAFAAAFgBQAGgCAEgDQAEgDADgFQADgEgBgHIAAgIIgKAAg");
	this.shape_3.setTransform(246.85,54.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgWBAQgNgFgKgJQgKgJgGgNQgFgNAAgPQAAgOAFgOQAGgMAKgJQAKgJANgFQANgFAOAAQAOAAAMAFQALAFAIAJQAIAJAFAMQAEAOAAAOIAAANIhdAAQACALAJAHQAIAHAKAAQAKAAAHgFQAHgEAFgHIAdAVQgKAMgPAHQgPAHgQAAQgOAAgNgFgAAbgOQAAgKgHgHQgHgIgLAAQgGAAgFACQgFACgEAEQgEADgCAFQgCAEAAAFIA1AAIAAAAg");
	this.shape_4.setTransform(231.975,54.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AggBBQgOgEgJgKIAZgbQAFAHAHADQAHAEAJAAQAGAAAGgCQAFgCABgFQAAgGgGgCIgLgFIgQgDQgKgDgHgEQgIgDgEgHQgGgHAAgMQABgMAEgJQAFgIAHgFQAIgGAKgCQAKgDAJAAQANAAANAEQAOADAJALIgZAYQgJgLgPAAQgDAAgGACQgEADAAAFQAAAFAEADIANAEIAQADQAJADAHAEQAIAFAFAFQAFAIAAAMQAAANgFAJQgGAIgJAEQgJAFgKADQgLACgJAAQgOAAgPgEg");
	this.shape_5.setTransform(217.85,54.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgnA+QgJgEgGgJQgEgIgCgMQgCgLAAgNIAAhHIAoAAIAABAIAAALQABAGACAFQACAFAEADQAFADAHAAQAHAAAFgCQAFgDADgFQACgFABgGIABgLIAAhBIAoAAIAACCIgnAAIAAgSIAAAAIgGAHIgIAHIgKAFQgHACgGAAQgQAAgKgFg");
	this.shape_6.setTransform(195.75,54.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgTBmIAAjLIAnAAIAADLg");
	this.shape_7.setTransform(184.425,50.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgXBoIAAhjIgbAAIAAgfIAbAAIAAgYQAAgKACgKQACgKAFgHQAFgHAJgEQAKgFARAAIANABIALACIgCAiIgGgCIgHgBQgKAAgFAFQgEAEAAANIAAAVIAdAAIAAAfIgdAAIAABjg");
	this.shape_8.setTransform(176.1,50.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("Ag0BhQgNgDgJgIQgKgHgGgLQgFgLAAgOQAAgJADgIQADgIAFgIQAGgGAIgEQAHgFAIgDIgIgJIgHgKIgEgLQgCgGAAgHQAAgNAFgJQAFgJAIgGQAJgGALgDQAKgDAMABQALAAAJACQAKADAIAGQAHAFAFAKQAEAIABAMQAAAJgEAIQgCAGgFAHQgFAGgGAGIgOAIIAZAaIATgZIAvAAIgpA1IArAtIg1AAIgPgSQgMAMgNAFQgNAGgSgBQgNABgLgEgAgmATIgHAGIgEAHQgCAEAAAFQAAAGACAEQACAFAEACIAHAFQAGACAEAAQAKAAAGgEQAIgFAFgFIghglgAgeg+QgFAFAAAHIACAHIADAHIAGAGIAFAEIAHgDIAHgGIAFgHQACgEAAgEQgBgIgEgEQgGgFgHAAQgJAAgFAFg");
	this.shape_9.setTransform(153,51.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AggBjQgMgFgJgKQgIgJgFgMQgEgMAAgPQAAgOAEgNQAEgLAIgKQAHgKAMgFQALgGAOAAQALAAALAEQALAEAHAJIABAAIAAhXIAoAAIAADLIglAAIAAgRIgBAAIgGAHIgJAHIgMAFQgGACgGAAQgOAAgMgFgAgVALQgJAJAAAPQAAAOAJAKQAIAJAPAAQAPAAAJgJQAIgKAAgOQAAgPgIgJQgJgKgPAAQgPAAgIAKg");
	this.shape_10.setTransform(125.175,50.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgTBmIAAjLIAnAAIAADLg");
	this.shape_11.setTransform(113.525,50.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgcBAQgNgFgKgJQgJgJgHgNQgFgNAAgPQAAgOAFgOQAHgMAJgJQAKgJANgFQANgFAPAAQAPAAAOAFQAMAFAKAJQALAJAFAMQAGAOAAAOQAAAPgGANQgFANgLAJQgKAJgMAFQgOAFgPAAQgPAAgNgFgAgXgXQgIAJAAAOQAAAOAIAKQAJAJAOAAQAPAAAJgJQAIgKAAgOQAAgOgIgJQgJgJgPAAQgOAAgJAJg");
	this.shape_12.setTransform(101.7,54.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgPBAQgNgFgKgJQgKgJgFgNQgGgNAAgPQAAgOAGgOQAFgMAKgJQAKgJANgFQAOgFAOAAQAMAAAMAEQANAEAKAKIgbAcQgDgFgFgDQgGgCgGAAQgOAAgJAJQgIAJAAAOQAAAOAIAKQAJAJAOAAQAHAAAFgDIAIgHIAbAcQgKAKgNAEQgMAEgMAAQgOAAgOgFg");
	this.shape_13.setTransform(87.375,54.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgfBBQgPgEgJgKIAZgbQAFAHAHADQAHAEAJAAQAGAAAGgCQAFgCAAgFQABgGgGgCIgLgFIgRgDQgIgDgIgEQgIgDgEgHQgFgHgBgMQAAgMAFgJQAFgIAHgFQAIgGAKgCQAKgDAKAAQAMAAANAEQAOADAJALIgZAYQgJgLgOAAQgEAAgGACQgEADAAAFQAAAFAEADIANAEIAQADQAJADAIAEQAHAFAFAFQAFAIAAAMQAAANgFAJQgGAIgJAEQgJAFgKADQgLACgJAAQgOAAgOgEg");
	this.shape_14.setTransform(65.95,54.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgTBiIAAiCIAnAAIAACCgAgPg5QgIgHAAgKQAAgJAIgHQAHgHAIAAQAKAAAHAHQAGAHAAAJQAAAKgGAHQgHAHgKAAQgIAAgHgHg");
	this.shape_15.setTransform(56.1,51.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AAXBmIAAhAIAAgMQgBgGgCgGQgCgEgEgDQgFgEgIAAQgGAAgFADQgFADgDAEQgCAGgBAFIAAANIAABBIgpAAIAAjLIApAAIAABbIAAAAQABgEADgEIAIgHQAFgCAFgDQAGgCAIAAQAPAAAKAGQAJAEAFAIQAFAJACAKQACAMAAAMIAABJg");
	this.shape_16.setTransform(44.8,50.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AAEBUQgIgCgGgFQgGgEgFgIQgDgHAAgLIAAg+IgaAAIAAggIAaAAIAAgnIAnAAIAAAnIAkAAIAAAgIgkAAIAAArIABAKQABAFACADQABADAEACQAEACAHAAIAIgBQAFgBADgCIAAAhQgHADgHABIgOABQgLAAgIgDg");
	this.shape_17.setTransform(31.25,52.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AggBBQgOgEgJgKIAYgbQAGAHAHAEQAHADAJAAQAGAAAGgCQAGgCAAgGQgBgEgFgDIgLgEIgQgEQgKgCgHgEQgIgFgEgGQgGgIAAgMQABgLAEgJQAEgIAJgFQAHgGAKgCQAKgDAJAAQANAAANAEQAOAEAJAJIgZAZQgJgLgPAAQgEAAgFACQgEADAAAFQAAAFAEADIANAEIAQAEQAIACAIAEQAIAEAFAHQAFAHAAANQAAAMgFAIQgGAIgJAGQgJAEgKACQgLADgKAAQgNAAgPgEg");
	this.shape_18.setTransform(310.9,23.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgWBAQgNgFgKgJQgKgJgGgNQgFgMAAgQQAAgPAFgMQAGgNAKgKQAKgIANgFQANgFAOAAQAOAAAMAFQALAFAIAIQAIAKAFANQAEAMAAAPIAAAMIhdAAQACAMAJAHQAIAHAKAAQAKAAAHgEQAHgFAFgHIAdAVQgKAMgPAHQgPAHgQAAQgOAAgNgFgAAbgOQAAgKgHgIQgHgHgLAAQgGAAgFADQgFACgEADQgEADgCAEQgCAFAAAFIA1AAIAAAAg");
	this.shape_19.setTransform(296.875,23.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AAXBDIAAhAIAAgLQgBgGgCgFQgCgFgEgDQgFgEgIAAQgGAAgFADQgFADgDAFQgCAFgBAFIAAAMIAABBIgpAAIAAiCIAmAAIAAASIABAAIAFgIIAJgGIAKgFQAGgCAIAAQAPAAAJAFQAKAEAFAJQAGAIACALQABAMAAANIAABHg");
	this.shape_20.setTransform(281.3,23.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgbBAQgOgFgKgJQgJgJgHgNQgFgMAAgQQAAgPAFgMQAHgNAJgKQAKgIAOgFQANgFAOAAQAPAAAOAFQANAFAJAIQAKAKAGANQAGAMAAAPQAAAQgGAMQgGANgKAJQgJAJgNAFQgOAFgPAAQgOAAgNgFgAgXgXQgJAJAAAOQAAAPAJAJQAIAJAPAAQAPAAAJgJQAIgJAAgPQAAgOgIgJQgJgKgPAAQgPAAgIAKg");
	this.shape_21.setTransform(265.25,23.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AggBjQgMgFgJgKQgIgJgFgMQgEgMAAgPQAAgOAEgNQAEgLAIgKQAHgKAMgFQALgGAOAAQALAAALAEQALAEAHAJIABAAIAAhXIAoAAIAADLIglAAIAAgRIgBAAIgGAHIgJAHIgMAFQgGACgGAAQgOAAgMgFgAgVALQgJAJAAAPQAAAOAJAKQAIAJAPAAQAPAAAJgJQAIgKAAgOQAAgPgIgJQgJgKgPAAQgPAAgIAKg");
	this.shape_22.setTransform(239.925,19.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgWBAQgNgFgKgJQgKgJgGgNQgFgMAAgQQAAgPAFgMQAGgNAKgKQAKgIANgFQANgFAOAAQAOAAAMAFQALAFAIAIQAIAKAFANQAEAMAAAPIAAAMIhdAAQACAMAJAHQAIAHAKAAQAKAAAHgEQAHgFAFgHIAdAVQgKAMgPAHQgPAHgQAAQgOAAgNgFgAAbgOQAAgKgHgIQgHgHgLAAQgGAAgFADQgFACgEADQgEADgCAEQgCAFAAAFIA1AAIAAAAg");
	this.shape_23.setTransform(224.075,23.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgTBBIg3iBIAsAAIAhBYIAAAAIAfhYIApAAIg0CBg");
	this.shape_24.setTransform(208.7,23.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AgbBAQgOgFgKgJQgJgJgHgNQgFgMAAgQQAAgPAFgMQAHgNAJgKQAKgIAOgFQANgFAOAAQAPAAAOAFQANAFAKAIQAJAKAGANQAGAMAAAPQAAAQgGAMQgGANgJAJQgKAJgNAFQgOAFgPAAQgOAAgNgFgAgXgXQgJAJAAAOQAAAPAJAJQAIAJAPAAQAPAAAJgJQAIgJAAgPQAAgOgIgJQgJgKgPAAQgPAAgIAKg");
	this.shape_25.setTransform(192.9,23.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2B3785").s().p("AgTBmIAAjLIAnAAIAADLg");
	this.shape_26.setTransform(181.075,19.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2B3785").s().p("AgtBDIAAiCIApAAIAAAVIAAAAQAGgMAIgGQAJgGAOAAIAHAAIAGABIAAAlIgJgCIgIgBQgLAAgIAEQgGADgEAGQgCAGgBAIIgBAQIAAA3g");
	this.shape_27.setTransform(164.5,23.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B3785").s().p("AgnA+QgJgEgGgJQgEgIgCgMQgCgLAAgNIAAhHIApAAIAABAIAAALQAAAGACAFQACAFAFADQAEADAHAAQAHAAAFgCQAFgDACgFQADgFABgGIABgLIAAhBIAoAAIAACCIgnAAIAAgSIAAAAIgGAHIgIAHIgKAFQgHACgGAAQgQAAgKgFg");
	this.shape_28.setTransform(150.65,23.625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2B3785").s().p("AgbBAQgOgFgKgJQgKgJgFgNQgGgMAAgQQAAgPAGgMQAFgNAKgKQAKgIAOgFQAMgFAPAAQAPAAANAFQANAFALAIQAKAKAFANQAGAMAAAPQAAAQgGAMQgFANgKAJQgLAJgNAFQgNAFgPAAQgPAAgMgFgAgXgXQgJAJAAAOQAAAPAJAJQAIAJAPAAQAPAAAJgJQAIgJAAgPQAAgOgIgJQgJgKgPAAQgPAAgIAKg");
	this.shape_29.setTransform(134.6,23.45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2B3785").s().p("AhGBdIAFghQAJAEAKgBIALgBQAFgBACgDIAFgHIAEgJIADgIIg5iDIArAAIAhBXIABAAIAchXIAqAAIg7CXIgIATQgEAIgFAGQgGAFgJADQgIADgPAAQgQAAgOgFg");
	this.shape_30.setTransform(118.775,26.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2B3785").s().p("AAEBUQgIgCgGgFQgGgEgFgIQgDgHAAgLIAAg+IgaAAIAAggIAaAAIAAgnIAnAAIAAAnIAkAAIAAAgIgkAAIAAArIABAKQABAFACADQABADAEACQAEACAHAAIAIgBQAFgBADgCIAAAhQgHADgHABIgOABQgLAAgIgDg");
	this.shape_31.setTransform(97.4,21.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2B3785").s().p("AgPBAQgNgFgKgJQgKgJgFgNQgGgMAAgQQAAgPAGgMQAFgNAKgKQAKgIANgFQAOgFAOAAQAMAAAMAEQANAEAKAJIgbAcQgDgDgFgDQgGgEgGAAQgOAAgJAKQgIAJAAAOQAAAPAIAJQAJAJAOAAQAHAAAFgDIAIgHIAbAcQgKAKgNAEQgMAEgMAAQgOAAgOgFg");
	this.shape_32.setTransform(86.075,23.45);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2B3785").s().p("AgWBAQgNgFgKgJQgKgJgGgNQgFgMAAgQQAAgPAFgMQAGgNAKgKQAKgIANgFQANgFAOAAQAOAAAMAFQALAFAIAIQAIAKAFANQAEAMAAAPIAAAMIhdAAQACAMAJAHQAIAHAKAAQAKAAAHgEQAHgFAFgHIAdAVQgKAMgPAHQgPAHgQAAQgOAAgNgFgAAbgOQAAgKgHgIQgHgHgLAAQgGAAgFADQgFACgEADQgEADgCAEQgCAFAAAFIA1AAIAAAAg");
	this.shape_33.setTransform(71.275,23.45);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2B3785").s().p("AAEBUQgIgCgGgFQgGgEgFgIQgDgHAAgLIAAg+IgaAAIAAggIAaAAIAAgnIAnAAIAAAnIAkAAIAAAgIgkAAIAAArIABAKQABAFACADQACADADACQAEACAHAAIAIgBQAFgBADgCIAAAhQgHADgHABIgOABQgLAAgIgDg");
	this.shape_34.setTransform(57.7,21.675);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2B3785").s().p("AgbBAQgOgFgKgJQgKgJgFgNQgGgMAAgQQAAgPAGgMQAFgNAKgKQAKgIAOgFQAMgFAPAAQAPAAANAFQANAFALAIQAKAKAFANQAGAMAAAPQAAAQgGAMQgFANgKAJQgLAJgNAFQgNAFgPAAQgPAAgMgFgAgXgXQgJAJAAAOQAAAPAJAJQAIAJAPAAQAPAAAJgJQAIgJAAgPQAAgOgIgJQgJgKgPAAQgPAAgIAKg");
	this.shape_35.setTransform(44.15,23.45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2B3785").s().p("AgtBDIAAiCIAoAAIAAAVIABAAQAFgMAKgGQAIgGANAAIAHAAIAHABIAAAlIgJgCIgIgBQgLAAgHAEQgHADgEAGQgDAGgBAIIgBAQIAAA3g");
	this.shape_36.setTransform(30.9,23.275);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2B3785").s().p("AhHBfIAAi+IBHAAQAOABANACQANADAKAGQAKAHAGALQAGALAAASQAAAQgGAMQgFAKgJAHQgKAGgNADQgNADgPAAIgeAAIAABKgAgdgOIAcAAIAKgBQAGgBAEgCQAEgDADgEQACgFAAgGQAAgIgDgFQgEgEgFgCQgFgCgHgCIgLAAIgWAAg");
	this.shape_37.setTransform(16.875,20.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_02, new cjs.Rectangle(5.7,1,313.7,71.8), null);


(lib.copy_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AiLCcIAAk3IB6AAQAeAAAdAKQAcAJAWATQAWAUANAdQAOAdgBAnQAAAogPAdQgPAegYATQgYATgdAJQgeAKgaAAgAhUBqIApAAQAaAAAWgGQAXgGARgNQASgMAJgUQALgUAAgdQgBgbgIgUQgKgVgPgMQgPgNgWgGQgUgGgaAAIgyAAg");
	this.shape.setTransform(197.9,30.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AhdCcIAAk3IA3AAIAAEFICEAAIAAAyg");
	this.shape_1.setTransform(170.425,30.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AhCCYQgegMgWgVQgVgVgNgeQgMgeAAglQAAgkAMgfQANgeAVgWQAWgVAegMQAegMAkAAQAkAAAeALQAeALAXAWQAWAVAMAfQAMAeAAAlQAAAkgMAeQgMAegWAWQgXAVgeAMQgeAMgkABQgkAAgegMgAgrhoQgUAJgOAPQgOAPgHAUQgIAUAAAYQAAAYAIAVQAHAVAOAQQAOAPAUAJQAUAIAXAAQAYAAAUgIQAUgJAOgPQAOgQAHgVQAIgVAAgYQAAgYgIgUQgHgUgOgPQgOgPgUgJQgUgIgYAAQgXAAgUAIg");
	this.shape_2.setTransform(139.225,30.424);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgpCYQgfgMgVgVQgVgVgNgeQgMgeAAglQAAgkAMgfQANgeAVgWQAVgVAfgMQAegMAjAAQAfAAAcALQAbAMAXAbIgrAfQgRgSgQgGQgQgGgRAAQgYAAgTAIQgTAJgOAPQgOAPgIAUQgHAUgBAYQABAYAHAVQAIAVAOAQQAOAPATAJQATAIAYAAQAUAAARgJQASgIAPgUIAuAgQgVAdgeANQgfAOgiAAQgjAAgegMg");
	this.shape_3.setTransform(106.65,30.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("Ag8CaQgcgKgTgXIAqgoQAKAPAQAJQARAIATAAQAJAAAJgCQAJgDAIgFQAJgFAEgIQAFgJAAgKQAAgRgLgKQgLgJgQgGIgigMQgUgGgQgKQgQgJgLgQQgLgRAAgcQgBgYAKgRQAKgSAQgMQAQgLAVgGQAVgGAUAAQAZAAAXAIQAXAHASASIgoAqQgJgNgPgGQgOgFgQAAIgSACQgKACgGAFQgIAFgFAHQgEAIAAALQAAAPALAJQAMAIAPAGIAjAMQATAGARAKQAQAJALARQALARAAAbQAAAZgJATQgKATgPAMQgQAMgUAGQgVAHgVAAQgdAAgbgKg");
	this.shape_4.setTransform(64.7,30.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgpA6IAehzIA1AAIglBzg");
	this.shape_5.setTransform(46.075,20.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgbCcIAAkFIhfAAIAAgyID1AAIAAAyIhfAAIAAEFg");
	this.shape_6.setTransform(26.925,30.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgbCcIAAk3IA3AAIAAE3g");
	this.shape_7.setTransform(8.225,30.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_01, new cjs.Rectangle(0,0,215.8,64.1), null);


(lib.click = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#044F04").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.btn_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AARAkIgRgwIgPAwIgSAAIgZhHIATAAIAQAyIAAAAIAPgyIASAAIAQAyIAAAAIAPgyIASAAIgYBHg");
	this.shape.setTransform(87.025,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAjQgIgDgFgFQgFgFgDgGQgDgIAAgIQAAgHADgIQADgHAFgFQAFgEAIgDQAHgDAHAAQAIAAAHADQAIADAFAEQAFAFADAHQADAIAAAHQAAAIgDAIQgDAGgFAFQgFAFgIADQgHADgIAAQgHAAgHgDgAgIgTIgHAFIgEAHIgBAHIABAIIAEAHIAHAFQAEACAEAAQAFAAAEgCIAHgFIAEgHIABgIIgBgHIgEgHIgHgFQgEgCgFABQgEgBgEACg");
	this.shape_1.setTransform(76.475,20.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAYA1Ig0hRIAABRIgTAAIAAhpIAZAAIAzBNIAAhNIATAAIAABpg");
	this.shape_2.setTransform(65.975,19.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgkA0IADgQIAEABIAFABIAFgBIAEgCIACgDIADgFIADgJIgfhHIAUAAIAUAyIASgyIATAAIgiBXIgFAJIgEAGQgDACgFABQgEACgGAAQgHAAgHgCg");
	this.shape_3.setTransform(51.75,22.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAiQgFgCgDgEQgDgEgBgFQgCgFAAgGIAAgsIASAAIAAAkIABAGIABAHQACADACACQADACAEABQAEAAADgCIAFgEIADgGIABgGIAAgnIASAAIAABHIgRAAIAAgLIgBAAQgCAFgGAEQgFAEgHAAQgIAAgFgDg");
	this.shape_4.setTransform(43.55,20.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmA1IAAhpIAoAAIAMABQAGABAEAEQAFADADAFQADAGAAAGQAAAKgGAGQgFAFgIADQAFABAEABQAFACADAEQADADABAEQACAFAAAFQAAAIgDAGQgEAGgFADQgGAEgHABIgOACgAgTAlIARAAIAHgBIAHgCQAEgBACgDQACgDAAgGQAAgIgFgEQgGgDgKAAIgSAAgAgTgJIARAAQAIAAAFgDQAFgFAAgFQAAgIgFgCQgFgEgKAAIgPAAg");
	this.shape_5.setTransform(34.675,19.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DA3F55").s().p("AphDNIAAmZITDAAIAAGZg");
	this.shape_6.setTransform(61,20.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_cta, new cjs.Rectangle(0,0,122,41), null);


(lib.bg_lightblue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7E6F4").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_lightblue, new cjs.Rectangle(0,0,728,90), null);


(lib.bg_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AvnHCIAAuDIfPAAIAAODg");
	this.shape.setTransform(100,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_blue, new cjs.Rectangle(0,0,200,90), null);


(lib.spray_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray("synched",0);
	this.instance.setTransform(12.1,44,0.1793,0.1594,0,0,0,12,43.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:12.1,regY:44,scaleX:1,scaleY:1},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,88.1);


(lib.hand_spray_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hand_spray_png
	this.instance = new lib.hand_spray();
	this.instance.setTransform(30,16,0.7402,0.7402);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(31).to({_off:true},1).wait(6).to({_off:false},0).wait(22).to({_off:true},1).wait(15));

	// spray_01_png
	this.instance_1 = new lib.spray_anim("synched",0);
	this.instance_1.setTransform(127.05,31.2,0.7402,0.2537,0,0,0,72.8,44.1);
	this.instance_1.alpha = 0.5781;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(30).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(22).to({startPosition:2},0).to({_off:true},1).wait(15));

	// spray_01_png
	this.instance_2 = new lib.spray_anim("synched",0);
	this.instance_2.setTransform(130,31.2,0.7797,0.9605,0,0,0,72.9,44);
	this.instance_2.alpha = 0.5781;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).wait(29).to({startPosition:2},0).to({_off:true},1).wait(6).to({_off:false,startPosition:0},0).wait(22).to({startPosition:1},0).to({_off:true},1).wait(15));

	// spray_01_png
	this.instance_3 = new lib.spray_anim("synched",0);
	this.instance_3.setTransform(127.05,31.15,0.7402,0.7402,0,0,0,72.8,44);
	this.instance_3.alpha = 0.5781;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(27).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(22).to({startPosition:2},0).to({_off:true},1).wait(15));

	// spray_01_png
	this.instance_4 = new lib.spray_anim("synched",0);
	this.instance_4.setTransform(127.05,31.15,0.7402,0.7402,0,0,0,72.8,44);
	this.instance_4.alpha = 0.5781;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).wait(30).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(22).to({startPosition:2},0).to({_off:true},1).wait(15));

	// Layer_8
	this.instance_5 = new lib.spray_mist("synched",0);
	this.instance_5.setTransform(144.5,35.4,0.3899,0.3899,0,0,0,150.1,150.1);
	this.instance_5.alpha = 0.3398;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).wait(27).to({startPosition:1},0).to({_off:true},1).wait(6).to({_off:false,startPosition:0},0).wait(22).to({startPosition:0},0).to({_off:true},1).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(30,-12.9,158.1,156.20000000000002);


(lib.germs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_18 = new cjs.Graphics().p("AVUHdQg5gIAMgWIANgQQAHgJgDgDQgCgBg0AQQg2AQgLAAQgdAAgUgRQgVgRAAgXQAAgYAVgRIANgNIAJgIQAfgKABgJQACgIgRgIIgggOQgSgJAAgIQAAgWADgJQAFgNAPgNIAsgkQAZgVATgIQATgIAiAhQAegBBUAFQBVAFg1AeQg1AegDAdQgCAdBYAJQBZAJgGApQgHApgjAXQgPAKg6gbQAPAxgeAMQgqAQgeAAIgOgBg");
	var mask_graphics_19 = new cjs.Graphics().p("AUMIZQhggOAUglQADgGASgWQANgOgGgFQgCgChYAaQhcAcgTAAQgwAAgjgcQgigdAAgoQAAgoAigcIAXgWQANgMADgBQAzgTADgPQACgMgdgOIg2gYQgegPAAgOQAAgkAGgRQAIgWAagVIBJg9QArgiAfgOQAggOA7A3QAygBCPAIQCPAJhZAzQhaAzgFAxQgEAxCWAPQCWAPgLBEQgLBFg7AoQgaARhigtQAaBTgzATQhHAbgzAAQgNAAgLgBg");
	var mask_graphics_20 = new cjs.Graphics().p("ATFJUQiHgTAcg1QAEgHAaggQASgUgIgHQgDgCh8AlQiCAngZAAQhFAAgwgoQgxgoAAg4QAAg5AxgoIAggeQASgRAEgCQBIgZAEgWQADgRgpgUQgzgWgYgLQgqgVAAgTQAAg0AIgXQAKgeAlgeIBnhWQA8gxAsgTQAtgUBTBPQBFgCDJAMQDKAMh+BHQh9BHgHBFQgHBEDTAWQDTAVgQBgQgPBhhTA4QgkAYiKhAQAkB1hHAbQhkAmhIAAQgRAAgQgCg");
	var mask_graphics_21 = new cjs.Graphics().p("AR/KOQiugYAkhDQAGgKAhgpQAWgagJgIQgEgDifAvQinAygiAAQhXAAg+g0Qg/gzAAhIQAAhIA/g0IApgnQAXgWAFgCQBdghAFgbQAEgWg0gaQhDgcgfgPQg2gbAAgYQAAhCALgdQANgoAwgnICEhuQBMg/A6gZQA6gZBpBmQBagDECAPQEDAPiiBcQihBdgJBWQgIBZEOAbQEQAbgVB8QgTB9hrBIQguAfixhTQAuCWhbAjQiBAxhcAAQgWAAgUgDg");
	var mask_graphics_22 = new cjs.Graphics().p("AQ5LIQjUgdAthTQAGgMAogxQAcgggMgKQgFgEjBA5QjMA+gpAAQhqAAhNg/QhMg/AAhXQAAhZBMg+IAzgwQAcgbAGgCQBygoAFgiQAFgbhAgfQhQgjgmgRQhCggAAgeQAAhRANgkQAQgxA6gvIChiGQBehNBFgfQBHgfCBB9QBtgDE7ASQE9ASjGBwQjFBxgLBrQgKBrFKAhQFLAigZCXQgXCXiCBYQg5AmjXhlQA4C3hwAqQidA9hwAAQgcAAgYgEg");
	var mask_graphics_23 = new cjs.Graphics().p("AP0MBQj5giA0hhQAHgPAwg5QAggmgOgMQgFgFjkBEQjxBIgvAAQh+AAhahKQhahKAAhnQAAhoBahKQAQgOAsgqQAhggAHgDQCGgvAGgoQAGgfhLgjQhfgpgtgWQhOgmAAgkQAAhfAQgrQATg4BEg5IC+idQBuhbBTgkQBTglCYCTQCAgEF0AWQF0AVjpCFQjnCEgNB/QgMB/GFAmQGFAngdCyQgbCziaBnQhDAtj9h2QBCDXiDAyQi6BHiEAAQggAAgdgFg");
	var mask_graphics_24 = new cjs.Graphics().p("AOwNMQkfgoA8hwQAJgQA2hCQAmgrgQgPQgHgFkGBOQkVBTg2AAQiRAAhmhVQhnhVAAh3QAAh3BnhVQATgRAwgwQAnglAHgDQCbg2AHguQAGgjhVgqQhugvgygYQhagsAAgpQAAhuASgxQAWhBBOhBIDZi1QB/hoBfgqQBggqCuCpQCUgEGrAYQGtAZkMCYQkLCZgOCRQgOCSG/AtQHAAsgiDNQgfDNixB3QhNAzkjiIQBMD4iXA5QjVBSiYAAQglAAghgFg");
	var mask_graphics_25 = new cjs.Graphics().p("ANsO5QlDgtBDh+QAKgTA+hLQAqgwgSgRQgHgFkpBXQk4Beg+AAQiiAAh0hgQh1hgAAiGQAAiHB1hgQAVgSA4g3QAsgpAIgEQCtg9AJg0QAHgnhggwQh8g1g6gbQhlgyAAguQAAh8AUg3QAZhKBZhJQBohVCNh3QCPh2BrgwQBsgvDFC/QCngFHiAcQHkAbkvCtQksCsgRCkQgQClH5AzQH6AxgmDoQgjDojICGQhXA5lJiZQBWEXiqBBQjxBcisAAQgpAAgmgFg");
	var mask_graphics_26 = new cjs.Graphics().p("AMpQkQlogyBLiMQALgVBFhTQAvg2gUgSQgIgHlKBiQlaBohFAAQi2AAiBhqQiChrAAiVQAAiXCChqQAXgVA/g8QAwgvAJgEQDChEAKg5QAIgshsg1QiKg7hAgfQhxg3AAg0QAAiJAWg+QAchSBjhRQB0hgCeiEQCeiDB3g1QB4g0DbDUQC7gFIYAeQIaAflQDAQlPC/gTC3QgRC4IyA4QIzA4gqEBQgoECjeCVQhhBBluirQBgE3i9BIQkNBmi/AAQguAAgqgGg");
	var mask_graphics_27 = new cjs.Graphics().p("ALnSPQmMg3BTibQAMgWBLhcQA0g8gWgTQgJgIlrBsQl9BzhMAAQjIAAiPh2QiOh1AAikQAAimCOh1QAagXBFhCQA2gzAKgFQDVhLALg/QAIgxh3g6QiXhBhHgiQh8g9AAg4QAAiYAZhDQAfhbBshZQB/hpCuiSQCwiQCCg6QCEg6DxDqQDNgGJOAiQJQAilyDTQlwDSgVDJQgTDLJqA+QJsA9guEbQgsEcj0CkQhrBHmSi8QBpFWjRBQQknBwjSAAQgzAAgugGg");
	var mask_graphics_28 = new cjs.Graphics().p("AKlT4Qmvg8BaioQANgZBThkQA4hBgZgVQgJgImMB1QmgB9hSAAQjaAAiciAQibiAAAizQAAi0CbiBQAdgYBLhJQA6g3ALgFQDphSALhFQAJg1iBg/QilhHhNglQiHhDAAg9QAAilAahKQAihjB2hhQCLhyC9ifQDAidCOhAQCQg/EHD/QDfgHKEAlQKFAlmTDmQmSDmgWDbQgVDdKiBDQKjBDgyE1QgvE2kLCzQh0BNm3jNQByF1jjBWQlBB7jmAAQg3AAgzgHg");
	var mask_graphics_29 = new cjs.Graphics().p("AJlVgQnThBBhi2QAOgaBahtQA9hGgbgXQgKgJmrB/QnDCHhaAAQjrAAipiKQioiLAAjBQAAjDCoiLQAfgbBRhOQA/g8AMgFQD8hZAMhLQAKg5iMhFQiyhMhUgoQiShIAAhDQAAiyAchRQAlhqCAhqQCWh7DNisQDPiqCbhFQCchEEbETQDygGK4AoQK7Aom1D4QmyD5gZDtQgWDvLZBJQLbBJg3FNQgzFQkgDBQh+BUnbjeQB8GUj2BdQlcCFj4AAQg8AAg2gIg");
	var mask_graphics_30 = new cjs.Graphics().p("AIlXHQn2hGBojDQAQgdBgh0QBBhMgcgZQgLgJnMCJQnkCRhgAAQj9AAi2iVQi1iVAAjQQAAjSC1iVQAhgcBXhVQBEhAANgGQEPhfANhRQALg9iXhKQjAhShZgrQidhOAAhHQAAjAAehWQAnhzCKhxQChiFDdi5QDei3CmhJQCohKExEoQEEgHLsArQLvArnVELQnTEMgaD+QgYEBMPBPQMSBOg7FnQg3Fok2DQQiHBan/jvQCGGykJBlQl2CPkKAAQhBAAg6gJg");
	var mask_graphics_31 = new cjs.Graphics().p("AHlYtQoXhKBvjRQAQgfBnh9QBGhQgfgbQgLgKnsCSQoGCbhmAAQkPAAjCifQjBifAAjeQAAjhDBifQAjgfBehaQBIhFAOgFQEhhmAOhWQAMhCihhPQjNhYhgguQiohTAAhMQAAjOAhhcQAqh6CTh5QCsiODsjGQDujDCxhPQC0hOFGE8QEVgIMgAuQMjAun2EeQnzEegcEQQgaESNGBVQNIBTg/GAQg6GBlMDeQiQBgoij/QCOHQkaBsQmQCYkdAAQhFAAg/gJg");
	var mask_graphics_32 = new cjs.Graphics().p("AGnaSQo6hPB3jfQARggBsiFQBLhWgggcQgNgKoKCbQonClhuAAQkfAAjOipQjOiqAAjsQAAjvDOipQAlghBjhgQBNhJAPgGQE0hsAOhcQANhHirhTQjbhehmgxQiyhYAAhRQAAjbAjhhQAsiDCdiAQC3iXD7jSQD9jRC9hTQC/hUFbFRQEmgINUAxQNVAxoVEvQoTEwgeEiQgbEkN7BZQN9BZhDGYQg+GalgDtQiaBmpFkQQCXHuksByQmpCjkwAAQhJAAhCgKg");
	var mask_graphics_33 = new cjs.Graphics().p("AFpb2QpchUB+jsQATgiByiNQBPhbgigeQgNgLoqClQpICvhzAAQkxAAjai0QjbizAAj7QAAj9DbizQAngiBphmQBShOAPgGQFGhzAQhhQANhLi1hYQjnhkhsgzQi9hdAAhXQAAjnAkhoQAwiKCliIQDDigEJjeQEMjdDIhYQDLhZFwFkQE4gIOFA0QOJA0o2FBQoyFCggEzQgdE1OwBfQOzBehHGwQhCGzl1D6QijBspokfQChILk+B5QnDCslBAAQhOAAhGgKg");
	var mask_graphics_34 = new cjs.Graphics().p("AErdZQp9hZCFj5QAUgkB6iVQBShfgjggQgOgMpJCuQpoC4h6AAQlCAAjmi9Qjni9AAkJQAAkLDni9QApgkBvhrQBWhTARgGQFYh5ARhnQANhPi/hdQj0hphyg3QjIhiAAhbQAAj0AnhtQAyiSCviQQDNipEYjrQEbjoDTheQDWhdGEF4QFJgJO4A3QO6A3pUFTQpSFUghFEQgfFGPkBkQPnBjhLHJQhFHKmKEIQisByqJkvQCpIolQCAQnbC1lTAAQhTAAhKgKg");
	var mask_graphics_35 = new cjs.Graphics().p("ADve6QqeheCMkFQAUgmCAicQBYhlgmgiQgOgMpoC3QqIDCiAAAQlTAAjyjHQjyjHAAkWQAAkZDyjHQAsgmB0hxQBbhWARgIQFqh/AShsQAOhTjJhiQkBhuh3g6QjThnAAhgQAAkAAph0QA1iZC4iXQDYiyEmj3QEqj0DehjQDghiGZGMQFagKPpA6QPsA5p0FmQpwFlgjFVQggFXQXBpQQbBphPHfQhJHimeEWQi1B4qrk/QCyJFlhCGQn0C/llAAQhWAAhOgLg");
	var mask_graphics_36 = new cjs.Graphics().p("EACzAgaQq/hiCTkSQAVgoCHikQBchpgogkQgPgMqGC/QqnDMiHAAQljAAj+jRQj+jRAAkkQAAkmD+jRQAugoB6h2QBfhbATgHQF7iFAShyQAQhXjThnQkOhzh9g9QjchsAAhkQAAkOAqh4QA3ihDBifQDji6E1kDQE4kADohoQDshnGsGfQFsgKQZA9QQdA8qSF3QqPF3glFlQghFnRKBvQROBuhTH3QhMH5mzEkQi9B+rMlPQC6JhlyCNQoNDIl2AAQhaAAhSgMg");
	var mask_graphics_37 = new cjs.Graphics().p("EAB4Ah5QrfhmCZkfQAXgqCNirQBghugqglQgQgNqjDIQrHDViNAAQlzAAkKjbQkJjaAAkxQAAk0EJjaQAwgqCAh8QBkhfATgIQGNiLATh2QAQhbjdhsQkah5iDg/QjmhyAAhpQAAkZAth/QA5ioDKimQDtjCFDkPQFGkMD0hsQD2hsHAGyQF9gLRJBAQRNA/qwGIQqtGIgnF1QgjF4R9B0QSABzhWIOQhQIRnHExQjGCDrtleQDDJ9mDCTQolDSmHAAQhfAAhVgNg");
	var mask_graphics_38 = new cjs.Graphics().p("EAA9AjXQr/hrChkrQAXgsCTiyQBkhzgrgnQgRgNrBDQQrlDeiTAAQmDAAkVjjQkWjkAAk/QAAlBEWjjQAygsCFiBQBohjAUgIQGeiSAUh7QARhfjnhxQkmh+iJhCQjwh2AAhuQAAklAviEQA8iwDSitQD3jLFSkaQFUkYD+hxQEBhwHUHEQGNgLR4BCQR9BCrOGZQrLGZgoGGQgkGISuB5QSzB4hbIlQhTInnaE/QjPCJsOltQDMKYmUCaQo8DamYAAQhjAAhagNg");
	var mask_graphics_39 = new cjs.Graphics().p("EAAFAk0QsehvCnk3QAYguCZi6QBoh4gtgoQgRgOreDZQsDDniZAAQmUAAkgjtQkhjtAAlLQAAlPEhjtQA0guCLiGQBshnAVgIQGviYAUiAQAShjjwh1QkyiEiOhEQj7h7AAhyQAAkyAxiJQA+i3Dbi0QECjUFfkmQFikjEJh1QELh2HnHYQGegMSnBFQSsBFrsGpQrnGqgqGWQgmGYTgB+QTjB9heI7QhXI+ntFMQjYCPstl8QDUKzmlCgQpUDkmpAAQhnAAhdgOg");
	var mask_graphics_40 = new cjs.Graphics().p("EAAGAmQQs+h0CtlDQAagwCfjBQBsh8gvgqQgSgPr6DiQsiDwifAAQmjAAksj2Qkrj2AAlZQAAlbErj2QA3gwCQiLQBwhrAWgJQG/ieAWiFQAShnj5h6Qk+iIiUhIQkEh/AAh3QAAk+AziOQBBi+Dji7QELjcFtkxQFxkvESh6QEWh6H6HqQGugMTVBIQTbBHsJG6QsFG6grGmQgoGoURCDQUUCChhJRQhbJVoBFYQjfCVtOmLQDdLOm1CnQprDsm6AAQhrAAhggOg");
	var mask_graphics_41 = new cjs.Graphics().p("EAAGAnrQtdh4C0lQQAagxCljIQBxiBgxgsQgTgPsWDqQtAD5ikAAQmzAAk3j/Qk3kAAAllQAAloE3j/QA4gyCWiQQB0hvAXgJQHQikAXiKQAShrkCh+QlKiOiZhJQkOiFAAh7QAAlJA1iUQBDjFDsjCQEVjkF6k9QF+k6Edh+QEgh+INH8QG+gNUDBKQUJBKsmHLQshHKgtG2QgpG4VACHQVFCHhlJnQheJroUFlQjoCattmZQDlLpnFCsQqCD1nKAAQhvAAhkgOg");
	var mask_graphics_42 = new cjs.Graphics().p("EAAGApEQt7h8C6lbQAcgzCqjPQB0iGgygtQgTgQsyDyQtdECirAAQnCAAlCkIQlBkJAAlxQAAl1FBkJQA7gzCbiVQB4hzAXgKQHhipAXiPQAUhvkMiCQlViTifhMQkXiJAAiAQAAlVA2iZQBGjMD0jIQEfjsGIlJQGLlFEniCQEqiDIfIOQHOgNUxBNQU1BMtBHbQs+HbgvHEQgqHIVwCMQV0CMhpJ9QhhKBomFxQjxCguLmoQDsMDnVCyQqZD+nZAAQhzAAhogPg");
	var mask_graphics_43 = new cjs.Graphics().p("EAAGAqdQuZiBDBlnQAcg1CwjWQB4iKg0guQgUgRtND7Qt6ELiwAAQnRAAlNkSQlNkRAAl+QAAmCFNkRQA8g1CgibQB9h2AYgKQHxivAYiUQAUhykViHQlgiYilhPQkgiOAAiDQAAlhA4ieQBIjTD8jPQEpj0GVlTQGZlQEwiHQE1iHIxIfQHdgNVdBPQVjBPteHrQtZHrgwHUQgsHXWeCRQWjCQhsKSQhkKWo5F+Qj5Cluqm2QD1MdnlC5QqvEGnqAAQh3AAhrgPg");
	var mask_graphics_44 = new cjs.Graphics().p("EAAGAr0Qu2iFDHlyQAdg3C2jdQB8iOg2gwQgVgRtpECQuWEUi2AAQngAAlXkaQlXkbAAmKQAAmOFXkaQA+g2CligQCBh7AYgKQIBi0AZiZQAVh2keiLQlsidiphRQkqiSAAiIQAAlsA6ijQBKjaEFjWQEyj8GileQGmlbE6iLQE/iLJDIwQHsgNWKBSQWPBRt6H7Qt1H6gxHjQguHmXNCWQXRCUhvKoQhoKspLGKQkBCqvInEQD9M3n1C+QrFEPn5AAQh7AAhvgQg");
	var mask_graphics_45 = new cjs.Graphics().p("EAAHAtKQvUiJDNl+QAeg4C7jjQCAiUg3gxQgWgRuDEKQuzEci7AAQnvAAlikjQlikjAAmWQAAmaFikjQBAg4CrilQCEh+AZgLQIRi5AaieQAVh6kmiPQl3ihivhVQkziWAAiMQAAl3A7ipQBNjgENjdQE7kDGvlpQGzllFEiQQFIiQJVJDQH7gOW2BUQW6BUuUIKQuRIKgzHyQgvH1X7CaQX/CZhzK9QhrLApdGXQkJCvvlnSQEENQoEDEQrbEXoJAAQh+AAhygQg");
	var mask_graphics_46 = new cjs.Graphics().p("EAAHAufQvxiNDTmJQAfg6DBjqQCEiYg5gyQgWgSueESQvPEkjBAAQn9AAlskrQltksAAmiQAAmmFtkrQBBg6CwiqQCIiCAagKQIhjAAaiiQAWh9kviUQmCimi0hXQk8ibAAiQQAAmCA9itQBPjnEVjjQFFkLG7l0QG/lwFOiTQFSiUJmJTQILgPXgBXQXmBXuwIZQurIag1IAQgwIEYoCeQYsCeh3LSQhtLVpwGiQkQC0wDnfQEMNooTDKQrwEgoZAAQiCAAh1gRg");
	var mask_graphics_47 = new cjs.Graphics().p("EAAHAvzQwNiRDZmUQAfg7DHjxQCHicg6g0QgXgTu4EaQvqEtjGAAQoMAAl2k0Ql3k0AAmuQAAmyF2k0QBEg8C1iuQCMiFAbgLQIvjFAbinQAXiBk4iYQmNiqi5hZQlFigAAiUQAAmNBAiyQBRjuEcjpQFOkTHIl+QHMl6FXiYQFbiYJ4JkQIZgPYLBZQYQBZvKIpQvFIog3IPQgxISZUCkQZYCih5LmQhxLpqBGuQkYC6wgnuQEUOCojDQQsFEnooAAQiFAAh5gRg");
	var mask_graphics_48 = new cjs.Graphics().p("EAAHAxGQwpiVDfmfQAgg9DMj4QCLigg8g1QgXgTvSEhQwFE1jMAAQoaAAmAk8QmBk8AAm6QAAm+GBk8QBFg9C6izQCPiJAcgMQI/jKAcirQAXiElAicQmYiwi+hbQlOikAAiYQAAmYBBi3QBUjzEkjwQFXkaHUmJQHYmEFhicQFkicKJJ0QIogPY1BbQY6BcvlI3QvfI4g4IdQgzIgaACoQaECnh9L5Qh0L+qSG6QkfC+w9n6QEbOaoxDVQsaEvo3AAQiJAAh8gRg");
	var mask_graphics_49 = new cjs.Graphics().p("EAAHAyXQxEiYDkmqQAhg/DSj+QCOikg+g3QgXgTvsEpQwfE8jSAAQonAAmLlEQmKlEAAnGQAAnJGKlEQBIg/C+i4QCTiMAdgMQJNjPAdiwQAYiIlJigQmii0jDheQlWioAAicQAAmiBCi8QBWj6Erj2QFgkhHgmTQHlmOFqihQFuigKaKFQI2gQZeBeQZjBev+JGQv6JHg5IrQg0IuarCsQawCriAMOQh3MSqkHFQkmDDxZoIQEiOyo/DbQsvE3pGAAQiMAAiAgSg");
	var mask_graphics_50 = new cjs.Graphics().p("EAAIAzoQxgidDqm0QAihADWkFQCSiog/g4QgYgUwFEwQw6FFjWAAQo1AAmVlNQmUlMAAnRQAAnUGUlNQBJhADDi8QCXiQAdgNQJdjUAdi0QAYiLlQikQmti5jIhgQlfisAAigQAAmtBFjAQBXkBEzj8QFpkoHsmdQHxmYFzilQF3ikKqKVQJEgQaHBgQaNBgwYJVQwTJVg7I5Qg1I9bVCwQbbCviEMhQh6Mlq0HRQkuDIx0oUQEpPJpODgQtDE/pUAAQiQAAiCgSg");
	var mask_graphics_51 = new cjs.Graphics().p("EAAIA03Qx7igDwm/QAihCDckKQCWithBg5QgZgVwdE4QxUFMjcAAQpDAAmelUQmelVAAnbQAAngGelVQBLhBDIjBQCaiUAegMQJrjaAei4QAZiPlYioQm4i9jMhiQlniwAAikQAAm3BFjFQBakHE7kCQFxkwH4mmQH9miF7ipQGBioK6KlQJSgQavBiQa1BjwxJjQwsJjg8JGQg3JLcAC0QcEC0iGM0Qh9M5rFHbQk1DOyQoiQEwPhpbDlQtYFHpiAAQiUAAiFgTg");
	var mask_graphics_52 = new cjs.Graphics().p("EAAIA2FQyVikD1nJQAjhDDhkRQCZiwhCg7QgagVw1E/QxuFUjgAAQpQAAmolcQmoldAAnnQAAnrGolcQBMhDDNjFQCeiXAegNQJ6jeAei9QAaiSlhisQnBjBjRhlQlwi0AAioQAAnBBIjKQBbkMFCkJQF6k2IEmwQIImsGEisQGKitLLK1QJfgRbWBlQbdBlxKJxQxEJxg+JUQg4JYcpC5QcuC4iKNHQh/NLrVHnQk9DSyrouQE4P3pqDrQtrFPpwAAQiXAAiJgUg");
	var mask_graphics_53 = new cjs.Graphics().p("EAAIA3SQyvinD6nUQAlhEDlkXQCdi0hEg9QgagVxNFGQyHFbjmAAQpdAAmxlkQmylkAAnxQAAn2GxlkQBPhFDRjKQChiaAggNQKHjjAfjBQAaiVloiwQnLjGjWhnQl4i4AAisQAAnLBJjOQBekSFJkOQGCk+IPm6QIVm1GMiwQGSiwLbLEQJtgRb9BnQcEBnxiJ/QxdJ/g/JhQg5JmdSC8QdXC8iNNaQiDNerlHyQlDDXzGo7QE/QOp4DwQt/FWp+AAQiaAAiMgUg");
	var mask_graphics_157 = new cjs.Graphics().p("EAAIA3SQyvinD6nUQAlhEDlkXQCdi0hEg9QgagVxNFGQyHFbjmAAQpdAAmxlkQmylkAAnxQAAn2GxlkQBPhFDRjKQChiaAggNQKHjjAfjBQAaiVloiwQnLjGjWhnQl4i4AAisQAAnLBJjOQBekSFJkOQGCk+IPm6QIVm1GMiwQGSiwLbLEQJtgRb9BnQcEBnxiJ/QxdJ/g/JhQg5JmdSC8QdXC8iNNaQiDNerlHyQlDDXzGo7QE/QOp4DwQt/FWp+AAQiaAAiMgUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_graphics_18,x:157.9986,y:47.7968}).wait(1).to({graphics:mask_graphics_19,x:165.7327,y:53.8278}).wait(1).to({graphics:mask_graphics_20,x:173.3911,y:59.7997}).wait(1).to({graphics:mask_graphics_21,x:180.9736,y:65.7125}).wait(1).to({graphics:mask_graphics_22,x:188.4803,y:71.5661}).wait(1).to({graphics:mask_graphics_23,x:195.9112,y:77.3606}).wait(1).to({graphics:mask_graphics_24,x:203.2663,y:81.3304}).wait(1).to({graphics:mask_graphics_25,x:210.5455,y:81.7443}).wait(1).to({graphics:mask_graphics_26,x:217.7489,y:82.1539}).wait(1).to({graphics:mask_graphics_27,x:224.8765,y:82.5592}).wait(1).to({graphics:mask_graphics_28,x:231.9283,y:82.9603}).wait(1).to({graphics:mask_graphics_29,x:238.9042,y:83.3569}).wait(1).to({graphics:mask_graphics_30,x:245.8043,y:83.7493}).wait(1).to({graphics:mask_graphics_31,x:252.6286,y:84.1374}).wait(1).to({graphics:mask_graphics_32,x:259.3771,y:84.5211}).wait(1).to({graphics:mask_graphics_33,x:266.0498,y:84.9005}).wait(1).to({graphics:mask_graphics_34,x:272.6466,y:85.2757}).wait(1).to({graphics:mask_graphics_35,x:279.1676,y:85.6465}).wait(1).to({graphics:mask_graphics_36,x:285.6128,y:86.013}).wait(1).to({graphics:mask_graphics_37,x:291.9821,y:86.3751}).wait(1).to({graphics:mask_graphics_38,x:298.2757,y:86.733}).wait(1).to({graphics:mask_graphics_39,x:304.3095,y:87.0865}).wait(1).to({graphics:mask_graphics_40,x:304.7272,y:87.4358}).wait(1).to({graphics:mask_graphics_41,x:305.1397,y:87.7807}).wait(1).to({graphics:mask_graphics_42,x:305.5471,y:88.1213}).wait(1).to({graphics:mask_graphics_43,x:305.9493,y:88.4576}).wait(1).to({graphics:mask_graphics_44,x:306.3464,y:88.7896}).wait(1).to({graphics:mask_graphics_45,x:306.7383,y:89.1172}).wait(1).to({graphics:mask_graphics_46,x:307.1251,y:89.4406}).wait(1).to({graphics:mask_graphics_47,x:307.5067,y:89.7596}).wait(1).to({graphics:mask_graphics_48,x:307.8832,y:90.0744}).wait(1).to({graphics:mask_graphics_49,x:308.2545,y:90.3848}).wait(1).to({graphics:mask_graphics_50,x:308.6207,y:90.6909}).wait(1).to({graphics:mask_graphics_51,x:308.9817,y:90.9927}).wait(1).to({graphics:mask_graphics_52,x:309.3375,y:91.2902}).wait(1).to({graphics:mask_graphics_53,x:310.2102,y:91.5833}).wait(104).to({graphics:mask_graphics_157,x:310.2102,y:91.5833}).wait(1).to({graphics:null,x:0,y:0}).wait(32));

	// Layer_5
	this.instance = new lib.germs_group();
	this.instance.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({_off:false},0).wait(139).to({_off:true},1).wait(32));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_36 = new cjs.Graphics().p("AjyLgQgRAAg0gDQgzgEAggWQAggXACgVQACgVg2gHQg2gGAEgeQAEgeAVgSQAJgHAjAUQgJgkASgJQAggPAVAEQAiAGgHAQIgIAMQgEAGACADQAAAAAggLQAhgMAHAAQARAAAMAMQANANAAARQAAASgNAMIgIAJIgFAGQgTAIgBAHQAAAFAKAGIATALQALAGAAAGQAAAQgCAHQgDAKgJAJIgaAbQgQAPgLAGIgFABQgLAAgRgTg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ai6MGQgjAChjgHQhjgHA+grQA+grADgqQADgphngNQhogMAHg6QAIg6ApgiQASgOBDAmQgRhGAjgQQA9gdAoAHQBCAMgOAfQgCAFgMASQgJANAEAEQABABA9gWQBAgXANAAQAiAAAYAYQAXAYAAAhQAAAigXAYIgQASIgLAMQgkAPgBANQgCAKAUAMIAlAUQAUANAAALQAAAfgEAOQgEATgSASIgzAzQgdAdgWAMQgFADgFAAQgVAAgggng");
	var mask_1_graphics_38 = new cjs.Graphics().p("AiEMsQgzACiSgKQiSgLBcg/QBbg/AFg8QAEg9iYgTQiZgSAMhVQAKhWA8gxQAbgVBjA4QgahmA0gYQBagqA6AKQBiARgVAuQgDAHgSAbQgNASAGAGQACACBZggQBdgiATAAQAxAAAkAjQAjAjAAAxQAAAygjAjIgYAbQgNAPgCABQg1AXgDATQgCAPAeARIA2AeQAfASAAARQAAAugGAUQgIAbgbAbIhKBLQgqArggASQgHADgHAAQgfAAgvg4g");
	var mask_1_graphics_39 = new cjs.Graphics().p("AhRNRQhCACi+gOQi/gNB3hTQB3hSAHhPQAGhQjHgYQjIgYAPhwQAOhvBOhBQAjgbCCBKQgiiHBDgfQB2g2BMAMQCAAWgbA9QgDAIgZAlQgRAXAIAIQACACB1gqQB7gtAYAAQBBAAAuAuQAuAuAABBQAABBguAuIgfAjQgRAUgDACQhFAdgDAZQgDATAmAXQAxAaAXANQAoAYAAAWQAAA8gIAaQgKAkgjAjIhhBiQg5A5gqAWQgJAFgJAAQgnAAg/hJg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AgeN0QhRACjqgQQjrgQCThmQCShlAIhhQAHhij0geQj2geATiIQARiJBghPQArgiCfBbQgpikBSgnQCRhDBeAQQCbAbgfBKQgFALgeArQgUAdAIAKQAEADCPgzQCXg3AeAAQBPAAA5A4QA4A4AABPQAABQg4A4IgmArQgVAZgEACQhVAkgEAfQgDAYAvAcQA8AfAcAQQAxAeAAAbQAABJgKAhQgMArgrArIh3B5QhGBFgzAcQgLAGgMAAQgxAAhLhag");
	var mask_1_graphics_41 = new cjs.Graphics().p("AAROWQhfADkTgTQkVgUCth3QCsh4AKhyQAJhzkhgkQkhgjAVihQAVihByhcQAxgpC9BrQgyjCBigtQCrhQBuAUQC4AfgnBYQgFAMgjA1QgYAhALAMQAEAECog9QCzhCAjAAQBdAABDBDQBDBDAABcQAABehDBDIgsAyQgZAdgFADQhkAqgFAlQgEAcA4AhQBHAlAhATQA5AiAAAhQAABWgLAmQgOA0gzAyIiNCOQhSBSg9AhQgMAHgOAAQg6AAhahqg");
	var mask_1_graphics_42 = new cjs.Graphics().p("ABAO2QhtAEk8gWQk9gWDGiJQDFiKALiCQALiElLgpQlMgoAZi4QAXi5CDhqQA5guDYB6Qg5jfBwgzQDEhcB+AWQDTAkgsBlQgHAPgoA7QgbAnALANQAFAFDChGQDNhLAoAAQBrAABNBMQBMBNAABrQAABrhMBMIgzA6QgdAhgFADQhyAxgGApQgEAgA/AmQBRArAmAWQBCAnAAAlQAABjgNAsQgQA7g6A6IihCjQheBehGAmQgPAHgQAAQhCAAhnh6g");
	var mask_1_graphics_43 = new cjs.Graphics().p("ABtPWQh7AEligZQlkgZDeiaQDeiaAMiTQALiUlzgtQl0guAcjOQAajPCSh4QBBg0DyCKQhAj7B+g6QDchmCOAZQDsAogxBxQgHAQguBEQgfArAOAPQAFAFDahPQDmhUAtAAQB4AABWBWQBWBWAAB4QAAB5hWBVQgQAQgpAxQggAlgGADQiBA3gGAvQgFAkBHAqQBbAwArAZQBKAsAAAqQAABugOAyQgTBChBBBIi1C3QhpBqhPAqQgQAJgSAAQhKAAh0iJg");
	var mask_1_graphics_44 = new cjs.Graphics().p("ACYP0QiIAFmHgcQmKgbD2iqQD1irANiiQANijmagzQmcgyAfjkQAdjlCiiFQBHg5ELCYQhFkVCKhAQDzhxCdAcQEGAsg3B9QgIASgyBKQgjAwAPAQQAGAGDxhXQD+hcAyAAQCFAABfBfQBeBeAACFQAACGheBfQgSASgtA1QgkApgHADQiNA9gHAzQgGAoBPAvQBlA1AuAbQBTAxAAAuQAAB6gQA3QgVBJhIBIIjIDLQh0B0hXAvQgSAJgUAAQhSAAiAiXg");
	var mask_1_graphics_45 = new cjs.Graphics().p("ADBQRQiUAFmrgeQmtgeEMi5QELi6APixQAOiznAg3QnBg2Aij5QAfj7CxiQQBNg/EkCmQhMktCXhGQEJh8CrAeQEeAxg8CIQgIAUg3BRQgmA0AQASQAHAGEHhfQEVhlA3AAQCQAABoBoQBnBnAACRQAACShnBnQgTAUgyA7QgnAsgHADQibBCgHA5QgGArBWAzQBtA6A0AeQBZA1AAAyQAACGgRA7QgXBQhOBPIjaDdQiAB/heAzQgTAKgXAAQhZAAiMilg");
	var mask_1_graphics_46 = new cjs.Graphics().p("ADnQtQigAFnNggQnQggEijJQEgjJAQi/QAPjAnjg8Qnlg7AkkMQAikPC/icQBUhEE7CzQhSlFCihMQEfiFC5AgQE1A1hBCSQgJAWg8BYQgoA4ARATQAHAHEchnQErhtA8AAQCcAABwBwQBvBwAACcQAACehvBvQgVAWg1A/QgqAxgIAEQinBGgIA9QgHAvBdA3QB2A+A4AgQBhA6AAA2QAACQgTBBQgZBWhUBVQhkBkiICKQiJCKhnA3QgUALgYAAQhhAAiXiyg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AD3RIQirAFnugiQnwgjE2jXQE1jXARjMQAQjPoGg/QoHhAAnkfQAkkiDNinQBZhIFRC/QhYldCvhQQEziPDGAjQFKA4hFCdQgKAXg/BeQgsA8ATAVQAHAHExhuQFAh1A/AAQCoAAB3B4QB4B4AACnQAACph4B4QgVAXg6BDQgtA0gIAFQizBLgJBBQgHAyBjA8QB/BCA8AjQBnA+AAA5QAACbgUBFQgaBchbBbQhqBriSCUQiTCThuA7QgWAMgaAAQhnAAiii+g");
	var mask_1_graphics_48 = new cjs.Graphics().p("AEHRhQi3AGoMglQoQglFKjkQFIjkASjaQARjbomhEQoohDApkyQAnk0DZiyQBfhNFnDMQhelzC6hWQFHiXDSAkQFfA8hJCnQgLAZhEBkQguBAAUAVQAIAIFEh0QFUh9BDAAQCyAAB/CAQCAB/AACyQAACziAB/QgXAZg9BIQgvA3gKAFQi+BRgJBEQgIA2BqA/QCHBGA/AlQBuBCAAA9QAACkgVBKQgcBihgBgQhyByibCeQicCch0A/QgYANgbAAQhuAAisjLg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AEWR5QjBAGorgmQotgnFcjyQFbjxAUjmQARjnpFhIQpHhGAslEQAolFDmi8QBkhRF7DXQhimIDEhbQFZigDdAnQF0A/hOCxQgLAahHBpQgxBEAVAXQAIAIFWh7QFoiEBHAAQC8AACGCHQCHCGAAC8QAAC+iHCGQgYAahBBMQgyA6gKAFQjJBWgJBIQgJA5BwBCQCPBLBCAmQB1BGAABBQAACtgXBOQgdBohmBmQh4B3ikCnQilClh7BDQgZANgdAAQh0AAi1jWg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AEkSjQjLAGpGgpQpKgoFuj+QFsj9AVjyQASjzpjhLQpkhKAulVQAqlWDyjFQBphVGPDiQhomcDOhfQFqioDpApQGHBChSC5QgMAchLBuQgzBIAWAYQAJAIFniBQF6iKBLAAQDFAACNCNQCNCNAADGQAADHiNCNQgZAbhEBQQg1A+gKAFQjTBagLBMQgIA7B1BGQCWBOBGApQB6BJAABEQAAC2gXBSQgfBthrBrQh+B+isCvQiuCuiBBGQgaANgeAAQh6AAi/jgg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AExTZQjUAHphgrQpkgrF+kJQF9kJAWj9QATj+p/hOQqAhOAwljQAslmD9jOQBuhZGhDsQhtmuDXhkQF7iwD0ArQGYBFhVDCQgMAchPB0Qg1BLAXAZQAJAJF3iIQGLiQBPAAQDOAACUCUQCTCUAADOQAADQiTCUQgbAchHBUQg3BAgLAFQjdBfgKBQQgJA9B7BJQCcBSBJAqQCABNAABHQAAC/gZBVQggByhwBwQiDCEi0C3Qi2C1iHBJQgbAPggAAQh/AAjIjrg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AE+UMQjdAHp6gsQp9gtGOkUQGMkUAWkHQAVkJqZhRQqbhRAylyQAul1EHjXQBzhcGyD2QhxnADghoQGKi3D+AsQGpBIhZDKQgNAehRB4Qg4BOAYAaQAKAJGGiMQGciWBRAAQDXAACaCZQCaCaAADXQAADZiaCZQgcAehKBXQg6BDgLAFQjlBjgLBTQgKBACABMQCjBVBMAsQCFBQAABKQAADGgZBZQgiB3h1B1QiJCJi7C+Qi9C9iMBMQgdAPghAAQiFAAjPj0g");
	var mask_1_graphics_53 = new cjs.Graphics().p("AFJU8QjkAHqSguQqVguGdkeQGbkeAXkRQAVkTqxhVQq0hTA0mAQAwmCERjfQB3hgHBD/Qh1nRDphrQGZi/EHAvQG5BKhcDSQgOAfhUB8Qg6BRAZAbQAKAKGViSQGqicBVAAQDfAACfCgQCgCfAADfQAADhigCfQgcAfhNBaQg8BFgLAGQjvBmgLBWQgKBDCFBOQCpBZBPAuQCKBSAABNQAADOgbBcQgjB7h5B5QiOCOjCDGQjEDEiSBPQgdAPgiAAQiKAAjYj9g");
	var mask_1_graphics_54 = new cjs.Graphics().p("AFUVoQjsAIqogvQqrgwGrkoQGpkoAYkaQAWkbrJhYQrLhWA2mNQAxmPEajnQB7hjHREIQh5ngDwhwQGnjEEQAvQHIBOhgDYQgOAghXCBQg8BUAaAbQAKAKGjiXQG5igBXAAQDnAACkCkQClClAADmQAADpilClQgdAfhQBeQg9BHgMAGQj3BpgLBaQgKBECJBSQCuBbBSAwQCPBVAABPQAADVgcBfQgkB/h9B9QiTCTjIDNQjLDKiXBSQgeAQgkAAQiOAAjfkHg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AFfWSQj0AIq8gxQrAgxG4kxQG2kwAYkjQAXkkrfhaQrghZA3mZQAzmbEjjuQB/hmHeEQQh9nvD4hyQG0jLEYAxQHVBQhiDfQgOAhhaCFQg+BVAbAdQAKAKGwibQHGimBaAAQDtAACqCqQCqCqAADtQAADviqCqQgfAhhSBgQg/BKgMAGQj+BsgMBcQgKBHCNBUQC0BeBUAxQCTBYAABRQAADbgdBiQglCDiACBQiYCYjODSQjRDRicBUQgfAQgkAAQiTAAjlkOg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AFoW5Qj6AIrPgyQrTgzHEk5QHBk5AZkqQAXksryhdQr0hbA5mkQA0mnErjzQCChpHrEXQiAn8D+h2QHAjQEgAyQHiBShlDlQgPAihcCIQg/BZAbAdQALALG7igQHSiqBdAAQDzAACvCuQCuCvAADzQAAD2iuCuQggAihUBjQhBBLgMAHQkFBvgNBfQgKBICRBWQC5BhBWAyQCXBbAABUQAADggdBlQgmCHiECEQicCcjUDYQjWDWigBWQggARgmAAQiWAAjskVg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AFxXcQkAAJrhg0QrkgzHOlBQHNlBAakxQAXk0sEheQsHheA6mvQA2mwExj6QCGhrH3EeQiDoJEFh4QHKjVEnAzQHuBUhoDrQgPAiheCMQhBBaAcAfQALAKHGijQHdiuBfAAQD6AACyCyQCzCzAAD5QAAD8izCzQggAihWBlQhDBOgNAGQkKBygNBhQgLBKCUBZQC+BjBYAzQCbBdAABWQAADmgeBnQgnCKiICIQifCfjZDdQjcDcijBYQghASgmAAQibAAjxkdg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AF5X9QkGAJrxg1Qr0g1HZlHQHWlIAak4QAZk7sWhgQsXhgA7m4QA3m6E5j/QCIhtICEkQiGoUEKh7QHUjaEuA1QH4BWhpDvQgQAjhgCPQhCBdAcAeQALALHQinQHoiyBhAAQD/AAC2C3QC3C2AAD/QAAEBi3C3QghAjhYBnQhEBQgNAGQkRB1gNBjQgLBMCYBaQDBBlBbA1QCeBeAABYQAADrgfBqQgoCMiKCLQijCjjeDiQjgDginBaQgiASgnAAQieAAj2kig");
	var mask_1_graphics_59 = new cjs.Graphics().p("AGAYaQkLAJr/g2QsDg1HilOQHflOAbk+QAZlBskhiQsnhiA9nAQA4nCE+kEQCLhwIMEqQiJoeEPh+QHejeEzA2QICBYhsD0QgPAkhjCRQhDBeAdAgQALALHZiqQHxi2BjAAQEEAAC6C6QC6C6AAEEQAAEGi6C6QgiAkhaBpQhFBRgNAHQkWB2gOBlQgLBOCbBbQDFBoBcA1QChBhAABZQAADwgfBsQgpCPiNCNQimCmjiDnQjkDkirBcQgiASgoAAQihAAj7kog");
	var mask_1_graphics_60 = new cjs.Graphics().p("AGHY0QkQAKsMg3QsQg3HqlTQHolUAblDQAZlGsyhkQs0hjA+nIQA5nKFDkIQCNhyIVEvQiLonEUiAQHljiE4A3QILBZhtD4QgQAlhkCUQhEBfAdAgQAMAMHgitQH6i5BkAAQEJAAC9C9QC9C9AAEJQAAEKi9C9QgjAlhbBrQhGBSgOAHQkaB4gOBnQgMBPCeBdQDIBpBeA2QCkBiAABcQAADzggBuQgpCRiQCQQioCpjnDqQjoDpitBdQgjATgpAAQijAAj/kug");
	var mask_1_graphics_61 = new cjs.Graphics().p("AGMZMQkTAJsYg4Qsbg3HxlYQHvlZAclIQAZlLs+hlQtAhlA/nOQA5nRFJkMQCPh0IdE0QiNowEXiBQHtjlE8A4QITBahvD8QgQAlhmCWQhFBhAeAgQALAMHoiwQIBi7BmAAQEMAADADAQDADAAAEMQAAEOjADAQgjAlhcBtQhIBTgOAHQkeB6gOBoQgMBQCgBfQDLBqBfA4QCmBjAABdQAAD3ggBvQgqCUiRCSQirCrjqDuQjrDsiwBeQgkATgpAAQimAAkDkxg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AGRZgQkWAJsig4Qslg4H3ldQH1ldAclMQAalPtIhnQtLhmA/nUQA7nWFMkPQCRh1IkE3QiPo3EbiDQHzjnFAA4QIaBbhxD/QgQAmhnCYQhGBiAeAhQAMAMHuiyQIHi+BnAAQEQAADCDCQDCDDAAEPQAAESjCDCQgjAmheBuQhIBUgOAHQkjB8gOBpQgLBRChBgQDOBsBgA4QCoBlAABdQAAD7ggBwQgqCWiUCTQitCtjsDxQjvDviyBgQgkATgqAAQinAAkHk1g");
	var mask_1_graphics_63 = new cjs.Graphics().p("AGVZxQkZAJsqg5Qsug4H9lhQH6lgAclQQAalStRhoQtThnBAnZQA7nbFQkSQCSh3IqE7QiQo8EeiFQH3jqFEA5QIfBchxECQgRAmhoCZQhHBkAfAhQAMAMHzi0QINjABoAAQESAADEDFQDEDEAAESQAAEVjEDEQgjAmhfBvQhJBVgOAHQkmB+gOBqQgMBSCkBhQDQBsBhA5QCqBmAABeQAAD9ghByQgrCXiVCVQivCvjvD0QjxDxizBhQglATgqAAQipAAkKk4g");
	var mask_1_graphics_64 = new cjs.Graphics().p("AGZZ/QkcAJsxg5Qs0g5IBlkQH+ljAclSQAblVtYhpQtbhoBBndQA7ngFTkUQCUh3IuE9QiSpBEhiGQH8jsFGA5QIkBdhzEEQgQAmhpCbQhIBlAfAhQAMAMH3i1QISjCBpAAQEUAADGDGQDGDGAAEVQAAEXjGDGQgkAmhfBwQhKBWgOAHQkoB+gOBsQgMBSCkBiQDSBuBiA5QCsBmAABgQAAD/giByQgrCZiWCWQiwCxjxD1QjzD0i2BhQgkAUgrAAQirAAkLk7g");
	var mask_1_graphics_65 = new cjs.Graphics().p("AGbaKQkdAJs2g5Qs6g6IElmQICllAclVQAblXtehqQtghpBBngQA8niFVkWQCVh4IxE/QiSpFEiiGQH/juFJA6QInBdhzEGQgRAmhpCcQhIBlAfAiQAMAMH6i3QIVjCBqAAQEWAADHDHQDIDHAAEXQAAEYjIDIQgkAmhgBxQhKBWgOAHQkqCAgOBsQgMBTClBiQDTBuBjA6QCtBnAABgQAAEBgiBzQgrCaiXCXQiyCyjyD3Qj1D1i3BiQgkAUgrAAQisAAkOk9g");
	var mask_1_graphics_66 = new cjs.Graphics().p("AGdaRQkfAKs6g6Qs9g6IGlnQIElnAdlXQAblZtihqQtkhpBBniQA9nlFWkXQCVh5I1FBQiTpIEjiHQICjuFKA5QIqBeh0EHQgRAnhqCdQhIBlAfAiQAMAMH9i4QIXjDBqAAQEYAADIDIQDIDIAAEYQAAEajIDIQgkAnhgBxQhLBXgPAHQkrCAgOBtQgMBTCmBjQDUBvBjA6QCuBnAABhQAAECgiBzQgrCbiYCYQizCyjzD4Qj2D2i3BjQglAUgrAAQitAAkPk/g");
	var mask_1_graphics_67 = new cjs.Graphics().p("AGfaWQkgAKs9g6Qs/g7IIloQIFloAdlXQAblatkhrQtnhpBBnjQA9nmFXkZQCWh5I2FCQiUpJEliIQIDjvFLA6QIrBeh0EIQgRAmhqCeQhJBlAgAiQAMAMH+i4QIZjEBqAAQEZAADIDJQDJDJAAEYQAAEbjJDJQgkAnhhBxQhLBXgOAIQksCAgOBsQgMBUCmBjQDVBvBjA6QCuBoAABhQAAEDghB0QgsCbiYCYQizCzj0D5Qj3D3i4BjQglATgrAAQitAAkPk/g");
	var mask_1_graphics_68 = new cjs.Graphics().p("AGfaXQkgAKs9g6QtBg6IJlpQIGloAdlYQAalatlhqQtnhqBBnkQA9nmFYkZQCWh5I2FCQiUpKEliHQIEjwFLA6QIsBeh0EIQgRAnhrCdQhIBmAfAiQAMAMH/i4QIZjEBrAAQEYAADJDJQDJDJAAEYQAAEcjJDIQgkAnhhByQhLBXgOAHQktCBgOBsQgMBUCnBjQDVBwBjA6QCuBoAABhQAAEDgiB0QgrCbiZCYQizCzj0D5Qj3D3i4BkQglATgrAAQiuAAkPlAg");
	var mask_1_graphics_157 = new cjs.Graphics().p("AGfaXQkgAKs9g6QtBg6IJlpQIGloAdlYQAalatlhqQtnhqBBnkQA9nmFYkZQCWh5I2FCQiUpKEliHQIEjwFLA6QIsBeh0EIQgRAnhrCdQhIBmAfAiQAMAMH/i4QIZjEBrAAQEYAADJDJQDJDJAAEYQAAEcjJDIQgkAnhhByQhLBXgOAHQktCBgOBsQgMBUCnBjQDVBwBjA6QCuBoAABhQAAEDgiB0QgrCbiZCYQizCzj0D5Qj3D3i4BkQglATgrAAQiuAAkPlAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(36).to({graphics:mask_1_graphics_36,x:-39.9241,y:75.529}).wait(1).to({graphics:mask_1_graphics_37,x:-49.0187,y:81.2662}).wait(1).to({graphics:mask_1_graphics_38,x:-57.8246,y:86.8213}).wait(1).to({graphics:mask_1_graphics_39,x:-66.3417,y:92.1943}).wait(1).to({graphics:mask_1_graphics_40,x:-74.5701,y:97.3852}).wait(1).to({graphics:mask_1_graphics_41,x:-82.5098,y:102.3939}).wait(1).to({graphics:mask_1_graphics_42,x:-90.1608,y:107.2205}).wait(1).to({graphics:mask_1_graphics_43,x:-97.5231,y:111.8649}).wait(1).to({graphics:mask_1_graphics_44,x:-104.5966,y:116.3273}).wait(1).to({graphics:mask_1_graphics_45,x:-111.3815,y:120.6074}).wait(1).to({graphics:mask_1_graphics_46,x:-117.7084,y:124.7055}).wait(1).to({graphics:mask_1_graphics_47,x:-121.7667,y:128.6214}).wait(1).to({graphics:mask_1_graphics_48,x:-125.6362,y:132.3552}).wait(1).to({graphics:mask_1_graphics_49,x:-129.317,y:135.9068}).wait(1).to({graphics:mask_1_graphics_50,x:-132.809,y:137.413}).wait(1).to({graphics:mask_1_graphics_51,x:-136.1123,y:137.3509}).wait(1).to({graphics:mask_1_graphics_52,x:-139.2268,y:137.2923}).wait(1).to({graphics:mask_1_graphics_53,x:-142.1526,y:137.2372}).wait(1).to({graphics:mask_1_graphics_54,x:-144.8896,y:137.1857}).wait(1).to({graphics:mask_1_graphics_55,x:-147.4378,y:137.1377}).wait(1).to({graphics:mask_1_graphics_56,x:-149.7973,y:137.0933}).wait(1).to({graphics:mask_1_graphics_57,x:-151.968,y:137.0525}).wait(1).to({graphics:mask_1_graphics_58,x:-153.95,y:137.0152}).wait(1).to({graphics:mask_1_graphics_59,x:-155.7432,y:136.9814}).wait(1).to({graphics:mask_1_graphics_60,x:-157.3476,y:136.9512}).wait(1).to({graphics:mask_1_graphics_61,x:-158.7633,y:136.9246}).wait(1).to({graphics:mask_1_graphics_62,x:-159.9902,y:136.9015}).wait(1).to({graphics:mask_1_graphics_63,x:-161.0284,y:136.882}).wait(1).to({graphics:mask_1_graphics_64,x:-161.8778,y:136.866}).wait(1).to({graphics:mask_1_graphics_65,x:-162.5385,y:136.8536}).wait(1).to({graphics:mask_1_graphics_66,x:-163.0103,y:136.8447}).wait(1).to({graphics:mask_1_graphics_67,x:-163.2935,y:136.8394}).wait(1).to({graphics:mask_1_graphics_68,x:-159.5157,y:136.3536}).wait(89).to({graphics:mask_1_graphics_157,x:-159.5157,y:136.3536}).wait(1).to({graphics:null,x:0,y:0}).wait(32));

	// Layer_10
	this.instance_1 = new lib.germs_group();
	this.instance_1.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(36).to({_off:false},0).wait(121).to({_off:true},1).wait(32));

	// mask_idn (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_1 = new cjs.Graphics().p("AMpLGQgSABg2gEQg2gDAigYQAhgXACgXQACgWg4gHQg5gHAEgfQAEggAXgSQAJgIAlAVQgKgmATgJQAigPAVAEQAkAGgHARIgIANQgFAGACACQABABAhgMQAjgMAHAAQASgBANAOQANANAAASQAAASgNANIgJAKIgFAGQgUAIgBAHQgBAGALAGIAUALQAMAHAAAGQAAARgCAIQgDAKgKAKIgcAbQgQAQgMAHIgFABQgLAAgSgVg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AMYLXQgZABhLgGQhLgFAvggQAughADgfQACgfhOgJQhOgKAGgsQAFgrAfgaQANgLAzAdQgNg0AbgMQAugWAeAFQAyAJgLAXIgLASQgGAJADADQABABAugQQAwgSAKAAQAZAAASASQASASAAAaQAAAZgSASIgMAOIgIAIQgbAMgBAKQgBAHAPAJIAcAQQAPAJAAAJQAAAXgDAKQgEAOgNAOIgmAnQgXAWgQAJQgEACgDAAQgQAAgZgdg");
	var mask_2_graphics_3 = new cjs.Graphics().p("AMILnQghABhggHQhggGA8gqQA8gpADgoQADgohkgMQhkgMAHg4QAHg4AoggQARgOBBAlQgRhDAigQQA7gbAmAGQBBALgOAfIgOAWQgIAMADAEQACABA6gVQA+gXAMAAQAhAAAXAXQAXAYAAAgQAAAggXAYIgPARIgLALQgiAPgCAMQgBAKATALIAkAUQAUAMAAALQAAAegEANQgFASgSARIgwAyQgdAcgVAMQgEACgFAAQgUAAgfglg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AL3L3QgoACh0gJQh1gIBJgyQBIgzAEgwQAEgwh5gPQh6gPAJhEQAIhEAwgnQAVgRBQAtQgVhSApgTQBIghAuAIQBOANgQAlQgCAFgPAWQgKAPAEAEQACACBHgaQBLgbAPAAQAnAAAdAcQAcAcAAAnQAAAogcAcIgTAVQgLANgCABQgqASgCAPQgBAMAXAOIAsAXQAYAPAAANQAAAlgFAQQgGAWgVAVIg7A8QgjAigaAOQgFADgGAAQgYAAgmgtg");
	var mask_2_graphics_5 = new cjs.Graphics().p("ALmMHQgvACiJgKQiJgJBWg8QBVg7AFg5QAEg4iPgSQiPgSALhPQAKhQA4guQAZgUBdA1QgYhhAwgWQBVgnA2AJQBcAQgTArQgDAGgRAaQgMARAFAGQACACBUgfQBYggASAAQAuAAAhAhQAhAhAAAuQAAAvghAhIgWAZQgMAOgDACQgxAVgCASQgCAOAbAQIA0AcQAcARAAAQQAAAqgFAUQgIAZgZAZIhFBHQgpAogeARQgGADgHAAQgdAAgtg1g");
	var mask_2_graphics_6 = new cjs.Graphics().p("ALWMXQg3ACicgLQiegLBjhEQBhhEAGhBQAFhCikgUQilgUAMhbQAMhcBBg1QAcgXBrA9QgchvA4gaQBhgtA/ALQBpASgWAyQgDAHgUAeQgOATAGAGQACADBhgjQBlglAUAAQA1AAAmAmQAmAmAAA1QAAA1gmAmIgZAdQgOAQgDACQg4AYgDAVQgCAQAfASIA7AgQAhAUAAASQAAAxgGAWQgJAegcAcIhQBRQgvAvgjATQgHAEgIAAQghAAgzg9g");
	var mask_2_graphics_7 = new cjs.Graphics().p("ALGMnQg+ACixgMQiygNBvhNQBvhNAGhJQAGhKi6gWQi5gXAOhnQAMhoBKg8QAggaB5BFQggh9A/gdQBugzBGAMQB3AUgZA5QgDAIgXAhQgQAWAHAHQADADBtgnQBygqAXAAQA8AAArArQArArAAA7QAAA9grArIgdAgQgQATgDABQhAAcgDAXQgDASAkAVQAuAYAVAMQAlAWAAAVQAAA3gHAZQgKAhggAhIhbBbQg0A1gnAVQgIAEgKAAQglAAg5hEg");
	var mask_2_graphics_8 = new cjs.Graphics().p("AK1M3QhEACjFgOQjGgOB8hVQB7hWAHhSQAGhSjOgZQjPgZAPhzQAPh0BRhCQAkgdCGBMQgjiLBGgfQB6g5BPAOQCEAWgbA+QgEAJgaAmQgRAYAHAIQADADB6gsQB/gvAZAAQBDAAAwAwQAvAwAABCQAABEgvAvIggAlQgSAUgDACQhHAegEAaQgDAUAoAYQAzAaAXAOQApAZAAAXQAAA9gIAcQgKAlgkAkIhlBmQg6A6gsAYQgJAFgKAAQgpAAhBhMg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AKlNGQhLADjZgQQjagPCIheQCIheAHhaQAHhajjgcQjigcAQh/QAPh/BahJQAnggCVBUQgniYBMgjQCHg/BXAPQCRAZgeBFQgEAKgcAoQgTAbAIAJQADADCGgwQCMgyAcAAQBJAAA1AzQA0A1AABJQAABKg0A0IgjAoQgUAXgDACQhPAhgEAdQgDAWAsAaQA3AdAaAPQAuAbAAAaQAABDgJAfQgLAogoAoIhvBwQhABBgwAaQgKAFgLAAQguAAhHhUg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AKVNWQhSACjsgQQjugRCUhnQCUhmAIhiQAIhjj4geQj3gfATiKQARiKBhhRQArghChBbQgqimBTgnQCThEBfAQQCfAbghBLQgFAMgfAsQgUAdAJAJQADADCSgzQCZg4AeAAQBQAAA5A5QA6A5AABQQAABQg6A6IglArQgWAZgEACQhWAlgEAfQgDAYAvAcQA9AgAcAQQAyAeAAAcQAABKgJAhQgNAsgrArIh5B6QhHBHg0AcQgLAGgMAAQgxAAhOhbg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AKFNlQhYADkBgSQkBgSChhvQCghwAJhqQAIhrkMggQkMghAUiWQATiWBqhWQAtglCvBjQgui0BbgqQCfhKBmASQCsAdgkBRQgFAMghAxQgWAfAJALQAEADCeg4QCmg9AgAAQBXAAA+A+QA+A+AABWQAABXg+A+IgpAvQgXAbgFACQhcAogFAiQgDAaAzAeQBCAjAeASQA2AgAAAeQAABQgKAkQgOAvgvAvIiCCFQhNBMg4AfQgMAGgNAAQg2AAhUhjg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AJ2N0QhgADkUgTQkTgTCsh4QCsh4AJhyQAJhzkggjQkhgkAWigQAUihByhdQAygoC7BrQgxjDBhgtQCshPBuATQC5AfgnBYQgGANgjA0QgYAiAKALQAEAECqg9QCyhBAkAAQBdAABDBCQBCBDAABdQAABdhCBDIgtAzQgZAdgEACQhkArgFAkQgEAcA4AhQBGAlAhATQA6AjAAAgQAABWgLAmQgPA0gyAzIiNCOQhSBSg9AhQgMAGgPAAQg5AAhahqg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AJmODQhmAEkngVQkngVC4iAQC4iAAKh6QAKh7k1gmQk1gmAYisQAVirB6hkQA2grDIByQg1jQBogwQC4hVB1AUQDGAigpBeQgGANgmA4QgaAkALANQAFAEC1hCQC/hFAmAAQBkAABHBHQBHBIAABjQAABkhHBHIgvA2QgbAfgFADQhrAugFAmQgEAeA7AkQBMAnAjAVQA+AlAAAiQAABcgMApQgQA3g2A3IiWCYQhYBYhBAjQgNAHgQAAQg9AAhhhyg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AJXOSQhtAEk6gWQk6gWDEiJQDDiIALiCQALiDlIgoQlKgpAZi3QAXi3CChqQA5guDVB6Qg4jdBvg0QDDhaB9AWQDTAjgsBkQgHAPgoA7QgbAnAMANQAEAEDBhFQDMhLAoAAQBqAABMBMQBMBMAABrQAABqhMBMIgyA5QgdAhgFADQhyAxgFApQgFAgA/AlQBRArAmAVQBCAoAAAkQAABigNAsQgRA7g5A6IihCiQhdBdhGAmQgOAHgQAAQhCAAhmh5g");
	var mask_2_graphics_15 = new cjs.Graphics().p("AJHOhQhzAElNgXQlNgYDPiQQDQiRAMiKQALiLlcgqQlegrAbjCQAYjDCKhwQA8gxDiCBQg6jrB0g2QDPhgCFAXQDgAmgvBqQgHAPgrBAQgdAoANAOQAFAFDNhKQDXhPArAAQBxAABQBRQBRBRAABwQAAByhRBPQgOAQgnAuQgeAigGADQh5A0gFAsQgFAiBDAnQBVAtAoAXQBGAqAAAnQAABogOAuQgRA/g9A9IiqCsQhjBjhKAnQgPAIgRAAQhGAAhtiAg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AI4OwQh6AElggZQlggYDdiZQDaiZANiSQALiSlvguQlygtAcjNQAajNCRh3QBAgzDwCIQg/j4B8g6QDahlCNAYQDrAogxBwQgHARgtBCQgfArAOAPQAFAFDYhOQDkhTAtAAQB3AABVBVQBVBVAAB3QAAB4hVBUQgPARgpAwQggAlgGADQiAA2gGAvQgFAjBHAqQBaAwAqAYQBKAsAAApQAABugOAxQgTBChABBIi0C1QhoBphOAqQgQAIgSAAQhKAAhziHg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AIpO+QiBAFlygaQlzgaDpihQDmihANiZQAMibmDgvQmFgwAdjXQAbjZCZh9QBDg2D9CPQhCkFCDg9QDlhrCUAaQD4AqgzB2QgIARgvBHQghAtAOAPQAGAGDjhTQDwhXAwAAQB9AABaBaQBZBZAAB+QAAB+hZBaQgQARgsAyQghAngHADQiGA5gGAxQgFAlBKAtQBfAxAsAaQBOAvAAArQAAB0gPAzQgTBGhEBEIi9C/QhvBuhSAsQgQAJgTAAQhOAAh5iPg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AIaPNQiHAEmFgbQmFgbD0ipQDxipAOihQAMiimWgyQmYgyAfjiQAcjkChiDQBGg5EKCXQhGkTCKg/QDwhxCcAcQEFAsg3B7QgIATgyBJQgiAwAPAQQAGAGDvhXQD8hcAyAAQCDAABeBfQBfBeAACDQAACFhfBeQgRASgtA1QgjAogHAEQiNA8gGAzQgGAoBOAuQBkA0AuAcQBSAwAAAuQAAB5gQA2QgUBJhIBIIjGDIQh0B0hWAuQgRAKgVAAQhRAAh/iWg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AILPbQiNAFmXgdQmYgcD/ixQD9ixAPipQANipmqg1Qmrg0AgjtQAdjuCpiKQBKg7EWCdQhJkfCQhCQD8h2CjAcQERAvg5CBQgJATg0BNQgjAyAPARQAGAGD7haQEHhhA0AAQCKAABjBjQBiBjAACJQAACLhiBjQgSATgwA4QgkAqgHADQiUA/gHA1QgGAqBSAxQBpA2AwAdQBWAzAAAvQAACAgRA5QgVBMhLBKIjQDTQh5B5haAxQgSAJgWAAQhVAAiFidg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AH8PpQiTAFmpgdQmrgeELi5QEIi5APiwQAOiym8g2Qm/g3Ahj3QAfj5CxiQQBMg+EjClQhMktCWhFQEIh7CqAeQEdAwg8CIQgIATg3BRQglA0AQASQAGAGEGhfQEUhkA2AAQCQAABnBnQBnBnAACQQAACRhnBnQgTAUgxA6QgnAtgHADQiaBBgHA4QgHAsBWAyQBtA6AzAdQBZA2AAAxQAACFgRA8QgWBPhOBOIjaDcQh+B+heAzQgTAKgXAAQhZAAiLikg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AHuP4QiaAFm7gfQm9gfEWjBQEUjBAPi3QAPi5nQg5QnRg5AjkCQAgkEC4iWQBQhBEuCsQhOk5CchIQETiACxAfQEpAyg+CNQgJAVg5BUQgmA2AQATQAHAGERhiQEfhpA5AAQCWAABrBrQBsBsAACWQAACXhsBrQgTAVg0A9QgoAugIAEQigBEgIA6QgGAtBZA1QByA8A1AfQBdA4AAAzQAACLgSA+QgYBThRBRQhgBgiCCFQiECEhjA1QgTALgYAAQhcAAiRirg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AHfQGQigAFnNggQnPghEijIQEgjJAQi/QAOjAnig7Qnlg8AkkMQAikOC/icQBUhEE7CzQhTlFCjhMQEeiFC4AgQE2A1hBCTQgJAVg7BYQgpA4ASATQAGAHEchnQErhtA7AAQCdAABvBwQBwBwAACcQAACdhwBwQgUAWg2A/QgqAwgIAEQimBHgJA8QgGAvBdA3QB2A+A3AhQBhA6AAA1QAACQgTBBQgYBWhVBVQhjBjiICLQiKCJhmA4QgUALgYAAQhhAAiXiyg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AHRQUQinAFneghQnhgiEtjQQErjQARjHQAPjIn2g9Qn3g+AmkWQAjkZDGiiQBXhGFHC6QhVlSCphPQEoiKDAAhQFBA3hDCYQgJAXg+BaQgqA7ASAUQAHAHEnhqQE2hyA+AAQCiAAB0B0QB0B0AACiQAACkh0B0QgVAWg4BCQgrAygJAFQitBKgIA9QgHAxBgA6QB7BAA6AiQBkA8AAA4QAACVgTBDQgaBahYBYQhnBniNCQQiPCPhqA5QgVALgZAAQhlAAici4g");
	var mask_2_graphics_24 = new cjs.Graphics().p("AHCQhQisAGnwgjQnygiE3jYQE2jYASjOQAQjPoJhAQoJhAAnkgQAkkkDOioQBahIFTDAQhZleCwhRQEziQDHAjQFNA5hFCdQgLAYg/BeQgsA9ATAUQAHAHEyhuQFCh1A/AAQCoAAB5B4QB4B4AACoQAACqh4B4QgWAXg6BEQgtA1gJAEQizBNgJBAQgHAzBkA7QB/BDA8AiQBoA/AAA6QAACbgUBFQgaBdhcBbQhrBsiSCVQiUCUhuA7QgWAMgaAAQhoAAijjAg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AG0QvQiyAGoCgkQoEgkFDjfQFBjgASjVQAQjWoahCQochBAoksQAmkuDViuQBdhLFfDIQhclrC2hUQE/iVDNAkQFZA7hICjQgLAYhCBiQgtA/AUAVQAHAHE9hyQFNh5BCAAQCuAAB8B8QB9B9AACuQAACvh9B9QgWAYg8BGQgvA2gJAFQi6BPgJBDQgHA0BnA+QCEBFA+AkQBsBAAAA8QAAChgVBIQgbBghfBeQhvBviXCbQiZCZhyA9QgXAMgbAAQhrAAipjGg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AGmQ9Qi4AGoTglQoVgmFNjnQFMjnASjcQARjeoshEQouhDAqk2QAmk4DcizQBhhOFqDOQhel3C7hXQFLiZDTAlQFlA8hLCpQgLAZhEBlQguBBAUAWQAIAIFHh2QFYh+BEAAQC0AACBCBQCACAAAC0QAAC2iACAQgYAZg+BJQgwA4gJAFQjABSgKBFQgHA2BrA/QCIBIBAAlQBvBCAAA/QAAClgVBLQgcBjhiBiQhzByicCgQieCeh2BAQgYAMgcABQhvAAiujNg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AGYRcQi+AGokgmQongmFZjvQFWjuATjkQASjlo/hGQpAhFArlAQAolCDki6QBjhQF2DVQhhmDDBhaQFVieDbAmQFwA+hNCvQgLAahHBoQgwBDAVAWQAIAIFSh5QFjiCBGAAQC6AACFCFQCFCFAAC5QAAC7iFCFQgYAahABLQgyA6gJAFQjHBUgJBIQgIA3BuBCQCNBKBBAmQB0BFAABAQAACrgXBNQgdBmhkBlQh3B3ihClQikCjh5BBQgZANgcAAQhzAAi0jTg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AGLR/QjFAGo1gnQo3goFij2QFij2ATjqQASjspQhJQpShHAtlKQAplMDqi/QBmhTGDDcQhlmQDIhcQFfijDhAnQF8BAhQC0QgLAbhJBrQgxBFAVAXQAIAJFdh+QFuiFBJAAQC/AACJCJQCJCIAADAQAADBiJCJQgZAahCBOQgzA7gKAFQjMBYgKBKQgJA5ByBDQCRBMBEAoQB3BHAABCQAACwgXBQQgeBphoBoQh6B6inCqQioCoh9BEQgaAOgdAAQh2AAi5jag");
	var mask_2_graphics_29 = new cjs.Graphics().p("AF9ShQjKAHpGgpQpJgpFuj9QFrj9AVjyQASjzpihKQpjhKAulUQAqlWDxjFQBqhVGNDiQhnmbDNhfQFqioDoApQGHBChSC5QgMAbhKBvQgzBHAWAYQAIAIFniBQF5iJBLAAQDFAACNCNQCNCNAADFQAADHiNCNQgaAbhEBQQg0A9gKAFQjTBagKBMQgJA7B1BGQCWBOBGApQB6BJAABEQAAC1gYBSQgeBthrBrQh+B+isCvQitCtiBBGQgaANgfAAQh6AAi+jgg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AFvTDQjQAHpWgqQpZgqF3kFQF2kEAVj4QAUj6p0hNQp1hMAvleQAslfD4jLQBshXGZDoQhqmnDThiQF1itDuAqQGSBFhUC+QgMAchNByQg0BJAWAZQAJAIFxiFQGEiNBNAAQDLAACRCRQCRCRAADLQAADMiRCRQgbAchFBTQg3A+gKAGQjZBcgKBPQgJA8B4BIQCaBQBIAqQB+BLAABGQAAC7gZBUQgfBwhuBuQiCCCiwC0QiyCyiFBIQgbAOgfAAQh+AAjEjng");
	var mask_2_graphics_31 = new cjs.Graphics().p("AFiTlQjWAHpngrQpqgsGCkLQGBkMAVj/QAUkBqFhPQqGhOAwlnQAtlpD/jRQBvhZGlDvQhumzDahlQF+iyD1AsQGdBGhWDDQgMAdhPB1Qg2BLAXAZQAJAJF7iIQGPiSBPAAQDQAACVCWQCVCVAADQQAADSiVCVQgbAdhIBUQg3BBgLAFQjfBggLBRQgIA9B7BKQCfBTBJArQCCBNAABIQAADAgaBWQggBzhxBxQiFCFi1C5Qi4C4iIBJQgcAPggAAQiBAAjJjtg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AFVUGQjcAHp3gsQp7gsGNkTQGKkTAXkGQAUkHqWhSQqYhQAylxQAulyEGjWQByhcGwD1Qhxm+DfhoQGJi2D8AsQGoBIhZDJQgNAdhRB4Qg3BOAYAaQAJAJGFiMQGaiWBRAAQDWAACZCZQCZCZAADWQAADYiZCZQgcAehKBWQg5BDgLAFQjlBigLBTQgJBAB/BLQCjBVBLAsQCFBQAABJQAADGgaBYQghB2h0B0QiJCJi6C+Qi8C8iMBMQgcAPghAAQiFAAjOj0g");
	var mask_2_graphics_33 = new cjs.Graphics().p("AFHUnQjhAIqHguQqLgtGXkaQGUkaAXkNQAVkOqnhTQqphTAzl6QAvl8ENjcQB1heG7D7Qh0nJDlhqQGTi7ECAtQGzBKhaDOQgOAehTB7Qg5BQAZAaQAJAJGPiPQGkiaBUABQDbgBCdCdQCdCeAADbQAADdidCdQgcAfhMBYQg7BFgLAFQjrBkgLBWQgJBBCCBNQCnBXBNAuQCIBRAABMQAADKgaBbQgiB5h3B3QiMCMi/DDQjBDBiQBOQgdAPgiAAQiHAAjVj6g");
	var mask_2_graphics_34 = new cjs.Graphics().p("AFMVIQjmAHqYguQqbgvGhkgQGekhAYkUQAVkVq4hVQq6hUA1mEQAwmGETjhQB5hhHFECQh2nVDqhsQGdjAEKAuQG9BMhdDTQgOAfhVB+Qg6BSAZAbQAKAJGZiTQGuidBVAAQDhAAChChQChChAADhQAADiihChQgdAfhNBcQg9BFgLAGQjxBngLBXQgKBDCGBPQCqBaBQAuQCMBUAABNQAADPgcBeQgiB8h7B6QiPCPjEDIQjGDGiTBPQgeAQgiAAQiLAAjakAg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AFUVoQjsAIqogwQqrgvGrkoQGpkoAYkaQAWkcrJhXQrLhWA2mNQAxmPEajnQB7hjHREIQh5ngDwhvQGnjFEQAwQHHBNhfDZQgOAfhXCBQg8BUAaAcQAKAJGjiWQG5ihBXAAQDmAAClClQClCkAADnQAADoilClQgeAfhPBeQg+BHgMAGQj2BpgMBaQgKBECJBSQCvBbBSAwQCOBVAABPQAADVgbBfQgkB/h9B9QiTCTjJDMQjKDLiXBRQgeARgkAAQiOAAjfkHg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AFcWIQjxAIq4gwQq7gxG1kvQGykuAZkhQAWkirZhaQrbhYA3mWQAymZEhjrQB+hmHbEOQh8nrD2hyQGxjJEWAxQHSBPhhDdQgPAhhZCEQg9BVAaAdQALAKGsibQHDikBZAAQDsAACpCoQCoCpAADsQAADtioCpQgfAghRBgQg/BJgMAGQj8BsgMBbQgKBGCMBUQCzBdBTAxQCSBXAABRQAADagcBhQglCCiACAQiWCXjNDRQjQDPiaBTQgfARgkAAQiSAAjkkNg");
	var mask_2_graphics_157 = new cjs.Graphics().p("AFcWIQjxAIq4gwQq7gxG1kvQGykuAZkhQAWkirZhaQrbhYA3mWQAymZEhjrQB+hmHbEOQh8nrD2hyQGxjJEWAxQHSBPhhDdQgPAhhZCEQg9BVAaAdQALAKGsibQHDikBZAAQDsAACpCoQCoCpAADsQAADtioCpQgfAghRBgQg/BJgMAGQj8BsgMBbQgKBGCMBUQCzBdBTAxQCSBXAABRQAADagcBhQglCCiACAQiWCXjNDRQjQDPiaBTQgfARgkAAQiSAAjkkNg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_2_graphics_1,x:92.0008,y:73.1147}).wait(1).to({graphics:mask_2_graphics_2,x:94.6062,y:75.5583}).wait(1).to({graphics:mask_2_graphics_3,x:97.1929,y:77.9844}).wait(1).to({graphics:mask_2_graphics_4,x:99.7609,y:80.393}).wait(1).to({graphics:mask_2_graphics_5,x:102.3102,y:82.7841}).wait(1).to({graphics:mask_2_graphics_6,x:104.8408,y:85.1576}).wait(1).to({graphics:mask_2_graphics_7,x:107.3528,y:87.5136}).wait(1).to({graphics:mask_2_graphics_8,x:109.8461,y:89.8521}).wait(1).to({graphics:mask_2_graphics_9,x:112.3207,y:92.1731}).wait(1).to({graphics:mask_2_graphics_10,x:114.7767,y:94.4766}).wait(1).to({graphics:mask_2_graphics_11,x:117.214,y:96.7626}).wait(1).to({graphics:mask_2_graphics_12,x:119.6325,y:99.031}).wait(1).to({graphics:mask_2_graphics_13,x:122.0325,y:101.2819}).wait(1).to({graphics:mask_2_graphics_14,x:124.4137,y:103.5153}).wait(1).to({graphics:mask_2_graphics_15,x:126.7763,y:105.7312}).wait(1).to({graphics:mask_2_graphics_16,x:129.1202,y:107.9296}).wait(1).to({graphics:mask_2_graphics_17,x:131.4454,y:110.1104}).wait(1).to({graphics:mask_2_graphics_18,x:133.7519,y:112.2738}).wait(1).to({graphics:mask_2_graphics_19,x:136.0398,y:114.4196}).wait(1).to({graphics:mask_2_graphics_20,x:138.3089,y:116.5479}).wait(1).to({graphics:mask_2_graphics_21,x:140.5594,y:118.6587}).wait(1).to({graphics:mask_2_graphics_22,x:142.7913,y:120.752}).wait(1).to({graphics:mask_2_graphics_23,x:145.0044,y:122.8277}).wait(1).to({graphics:mask_2_graphics_24,x:147.1989,y:124.886}).wait(1).to({graphics:mask_2_graphics_25,x:149.3747,y:126.9267}).wait(1).to({graphics:mask_2_graphics_26,x:151.5318,y:128.9499}).wait(1).to({graphics:mask_2_graphics_27,x:153.6703,y:129.166}).wait(1).to({graphics:mask_2_graphics_28,x:155.79,y:129.0268}).wait(1).to({graphics:mask_2_graphics_29,x:157.8911,y:128.8887}).wait(1).to({graphics:mask_2_graphics_30,x:159.9736,y:128.7519}).wait(1).to({graphics:mask_2_graphics_31,x:162.0373,y:128.6164}).wait(1).to({graphics:mask_2_graphics_32,x:164.0824,y:128.482}).wait(1).to({graphics:mask_2_graphics_33,x:166.1088,y:128.3489}).wait(1).to({graphics:mask_2_graphics_34,x:166.3247,y:128.217}).wait(1).to({graphics:mask_2_graphics_35,x:166.2221,y:128.0863}).wait(1).to({graphics:mask_2_graphics_36,x:168.3549,y:130.3945}).wait(121).to({graphics:mask_2_graphics_157,x:168.3549,y:130.3945}).wait(1).to({graphics:null,x:0,y:0}).wait(32));

	// Layer_1
	this.instance_2 = new lib.germs_group();
	this.instance_2.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(156).to({_off:true},1).wait(32));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-310,0,943,305);


// stage content:
(lib.LysolColdFlu_LDS_728x90_en = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var self = this;
		//this.btnColor;
		////this.downText = this.cta.cta.textDown;
		////this.upText = this.cta.cta.textUp;
		////this.textRestingYPos = 17;
		//this.ctaTextOffset = 30;
		
		////self.upText.y = this.textRestingYPos + this.ctaTextOffset;
		////self.downText.y = this.textRestingYPos;
		
		//this.setBtnColor = function(p_color) {
		//	switch (p_color) {
		//		case "white":
		//			self.cta.cta.arrow.gotoAndPlay("dark-green");
		//			//self.cta.cta.textDown.gotoAndPlay("dark-green");
		//			self.cta.cta.bg.gotoAndPlay("white");
		//			self.btnColor = "white";
		//			break;
		//		case "regular-green":
		//			self.cta.cta.arrow.gotoAndPlay("white");
		//			//self.cta.cta.textDown.gotoAndPlay("white");
		//			self.cta.cta.bg.gotoAndPlay("regular-green");
		//			self.btnColor = "regular-green";
		//			break;	
		//	}
		//}
		//this.setRolloverBtnColor = function() {
		//	if (self.btnColor == "regular-green") {
		//		setTimeout(function() {
		//			self.cta.cta.arrow.gotoAndPlay("dark-green");
		//		}, 150);
		//	}	
		//}
		//this.setRolloutBtnColor = function() {
		//	if (self.btnColor == "regular-green") {
		//		setTimeout(function() {
		//			self.cta.cta.arrow.gotoAndPlay("white");
		//		}, 150);
		//	}
		//}
		
		//// Set initial button color
		//setTimeout(function() {
		//	self.setBtnColor("regular-green");
		//}, 50);
		
		// Clicktag =======================
		
		this.clicktag.addEventListener('click', handleClick);
		//this.clicktag.addEventListener('mouseover', handleMouseOver);
		//this.clicktag.addEventListener('mouseout', handleMouseOut);
		
		function handleClick() {
		    window.ctaClick();
		}
		//function handleMouseOver() {
		//	//var landingY = self.textRestingYPos;
		//	self.cta.gotoAndPlay("over"); 
		//	self.cta.cta.gotoAndPlay("over");
		//	self.setRolloverBtnColor();
		//	//self.downText.y = landingY;
		//	//self.upText.y = landingY-self.ctaTextOffset;
		//	//createjs.Tween.get(self.downText, {override:true}).to({y:landingY+self.ctaTextOffset}, 200, createjs.Ease.quintIn);
		//	//createjs.Tween.get(self.upText, {override:true}).wait(200).to({y:landingY}, 300, createjs.Ease.quintOut);
		//}
		//function handleMouseOut() {
		//	//var landingY = self.textRestingYPos;
		//	self.cta.gotoAndPlay("out");
		//	self.cta.cta.gotoAndPlay("out");
		//	self.setRolloutBtnColor();
		//	//self.downText.y = landingY+self.ctaTextOffset;
		//	//self.upText.y = landingY;
		//	//createjs.Tween.get(self.downText, {override:true}).wait(200).to({y:landingY}, 300, createjs.Ease.quintOut);
		//	//createjs.Tween.get(self.upText, {override:true}).to({y:landingY-self.ctaTextOffset}, 200, createjs.Ease.quintIn);
		//}
		//
	}
	this.frame_372 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(372).call(this.frame_372).wait(68));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Eg43gHBMBxvAAAIAAODMhxvAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(440));

	// ClickTag
	this.clicktag = new lib.click();
	this.clicktag.setTransform(364.25,45.1,2.4266,0.3599,0,0,0,0.1,0.3);
	new cjs.ButtonHelper(this.clicktag, 0, 1, 2, false, new lib.click(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clicktag).to({_off:true},373).wait(67));

	// what_it_takes
	this.instance = new lib.whatittakes();
	this.instance.setTransform(665.5,44,1,1,0,0,0,32.5,11);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(344).to({_off:false},0).to({alpha:1},9,cjs.Ease.get(1)).to({_off:true},20).wait(67));

	// product
	this.instance_1 = new lib.product_1();
	this.instance_1.setTransform(807.5,68.45,1,1,0,0,0,35.5,54.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(337).to({_off:false},0).to({x:607.5},9,cjs.Ease.get(1)).to({_off:true},27).wait(67));

	// bg_blue
	this.instance_2 = new lib.bg_blue();
	this.instance_2.setTransform(780,125,1,1,0,0,0,52,125);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(330).to({_off:false},0).to({x:595},9,cjs.Ease.get(1)).to({_off:true},34).wait(67));

	// copy_04
	this.instance_3 = new lib.copy_04();
	this.instance_3.setTransform(86.1,81.8,1,1,0,0,0,61.1,12);
	this.instance_3.alpha = 0;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CCCCCC").ss(1,1,1).p("Eg43gHBMBxvAAAIAAODMhxvAAAg");
	this.shape_1.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3,p:{alpha:0}}]},323).to({state:[{t:this.shape_1},{t:this.instance_3,p:{alpha:1}}]},9).to({state:[]},41).wait(67));

	// btn_cta
	this.instance_4 = new lib.btn_cta();
	this.instance_4.setTransform(480.05,45.1,0.8,0.8,0,0,0,61.1,20.6);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(316).to({_off:false},0).to({x:464.05,alpha:1},9,cjs.Ease.get(1)).to({_off:true},48).wait(67));

	// copy_03
	this.instance_5 = new lib.copy_03();
	this.instance_5.setTransform(125.7,52.25,1,1,0,0,0,82,27.3);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(310).to({_off:false},0).to({x:105.7,alpha:1},9,cjs.Ease.get(1)).to({_off:true},54).wait(67));

	// copy_02
	this.instance_6 = new lib.copy_02();
	this.instance_6.setTransform(324.3,35.45,1,1,0,0,0,122.8,27.7);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(257).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).to({_off:true},38).wait(130));

	// logo
	this.instance_7 = new lib.logo_1();
	this.instance_7.setTransform(685.5,47,1,1,0,0,0,24.5,23);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(163).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).to({_off:true},132).wait(130));

	// bg_light_blue
	this.instance_8 = new lib.bg_lightblue();
	this.instance_8.setTransform(98,35,1,1,0,0,0,98,125);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(248).to({_off:false},0).to({y:125},9,cjs.Ease.get(1)).to({_off:true},116).wait(67));

	// hand
	this.instance_9 = new lib.hand_spray_1("single",0);
	this.instance_9.setTransform(12.9,225.05,1,1,-22.7187,0,0,-0.1,112);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(178).to({_off:false},0).to({regX:0,rotation:0,x:110,y:125},4,cjs.Ease.get(1)).wait(3).to({mode:"synched"},0).to({regX:0.1,rotation:4.9513,x:105.95,startPosition:12},20,cjs.Ease.get(1)).to({regX:-0.1,rotation:-7.0392,x:104.8,y:135,startPosition:38},20,cjs.Ease.get(1)).to({regX:0,rotation:0,x:110,y:125,mode:"single",startPosition:0},23,cjs.Ease.get(1)).to({y:205},9,cjs.Ease.get(1)).to({_off:true},1).wait(182));

	// spray
	this.instance_10 = new lib.spray_mist("synched",0);
	this.instance_10.setTransform(260,65,0.6263,0.6263,0,0,0,150,150.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(185).to({_off:false},0).to({regX:149.8,regY:149.8,scaleX:1.486,scaleY:1.486,x:259.9,y:64.65,alpha:0.2813},40,cjs.Ease.get(1)).to({scaleX:2.1808,scaleY:2.1808,x:260,y:64.75,alpha:0},10).to({_off:true},4).wait(201));

	// ice_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_33 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_34 = new cjs.Graphics().p("A6xCTIAAklMA1jAAAIAAElg");
	var mask_graphics_35 = new cjs.Graphics().p("A6xC1IAAlpMA1jAAAIAAFpg");
	var mask_graphics_36 = new cjs.Graphics().p("A6xDYIAAmvMA1jAAAIAAGvg");
	var mask_graphics_37 = new cjs.Graphics().p("A6xD7IAAn1MA1jAAAIAAH1g");
	var mask_graphics_38 = new cjs.Graphics().p("A6xEeIAAo7MA1jAAAIAAI7g");
	var mask_graphics_39 = new cjs.Graphics().p("A6xFAIAAp/MA1jAAAIAAJ/g");
	var mask_graphics_40 = new cjs.Graphics().p("A6xFjIAArGMA1jAAAIAALGg");
	var mask_graphics_41 = new cjs.Graphics().p("A6xGGIAAsLMA1jAAAIAAMLg");
	var mask_graphics_42 = new cjs.Graphics().p("A6xGpIAAtRMA1jAAAIAANRg");
	var mask_graphics_43 = new cjs.Graphics().p("A6xHLIAAuWMA1jAAAIAAOWg");
	var mask_graphics_44 = new cjs.Graphics().p("A6xHvIAAvcMA1jAAAIAAPcg");
	var mask_graphics_45 = new cjs.Graphics().p("A6xIRIAAwhMA1jAAAIAAQhg");
	var mask_graphics_46 = new cjs.Graphics().p("A6xI0IAAxnMA1jAAAIAARng");
	var mask_graphics_47 = new cjs.Graphics().p("A6xJXIAAytMA1jAAAIAAStg");
	var mask_graphics_48 = new cjs.Graphics().p("A6xJ6IAAzzMA1jAAAIAATzg");
	var mask_graphics_49 = new cjs.Graphics().p("A6xKdIAA05MA1jAAAIAAU5g");
	var mask_graphics_50 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_51 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_52 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_53 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_54 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_55 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_56 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_57 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_58 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_59 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_60 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_61 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_62 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_63 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_64 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_65 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_66 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_67 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_68 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_69 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_70 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_71 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_72 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_73 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_74 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_75 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_76 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_77 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_78 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_79 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_80 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_81 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_82 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_83 = new cjs.Graphics().p("A6xK/IAA19MA1jAAAIAAV9g");
	var mask_graphics_84 = new cjs.Graphics().p("A6xJ1IAAzpMA1jAAAIAATpg");
	var mask_graphics_85 = new cjs.Graphics().p("A6xIsIAAxXMA1jAAAIAARXg");
	var mask_graphics_86 = new cjs.Graphics().p("A6xHhIAAvBMA1jAAAIAAPBg");
	var mask_graphics_87 = new cjs.Graphics().p("A6xGYIAAsvMA1jAAAIAAMvg");
	var mask_graphics_88 = new cjs.Graphics().p("A6xFOIAAqaMA1jAAAIAAKag");
	var mask_graphics_89 = new cjs.Graphics().p("A6xEEIAAoHMA1jAAAIAAIHg");
	var mask_graphics_90 = new cjs.Graphics().p("A6xC6IAAlyMA1jAAAIAAFyg");
	var mask_graphics_91 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_92 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_93 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_94 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_95 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_96 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_97 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_98 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_99 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_100 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_101 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_102 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_103 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_104 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_105 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_106 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_107 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_108 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_109 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_110 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_111 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_112 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_113 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_114 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_115 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_116 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_117 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_118 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_119 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_120 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_121 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_122 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_123 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_124 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_125 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_126 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_127 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_128 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_129 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_130 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_131 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_132 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_133 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_134 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_135 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_136 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_137 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_138 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_139 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_140 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_141 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_142 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_143 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_144 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_145 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_146 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_147 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_148 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_149 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_150 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_151 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_152 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_153 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_154 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_155 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_156 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_157 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_158 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_159 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_160 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_161 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_162 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_163 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_164 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_165 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_166 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_167 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_168 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_169 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_170 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_171 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_172 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_173 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_174 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_175 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_176 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_177 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_178 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_179 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_180 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_181 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_182 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_183 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_184 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_185 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_186 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_187 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_188 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_189 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_190 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_191 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_192 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_193 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_194 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_195 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_196 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_197 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_198 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_199 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_200 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_201 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_202 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_203 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_204 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_205 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_206 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_207 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_208 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_209 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_210 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_211 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_212 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_213 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_214 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_215 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_216 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_217 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_218 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_219 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_220 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_221 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_222 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_223 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_224 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_225 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_226 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_227 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_228 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_229 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_230 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_231 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_232 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_233 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_234 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_235 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_236 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_237 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_238 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_239 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_240 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_241 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_242 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_243 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_244 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_245 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_246 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_247 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_248 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_249 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_250 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_251 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_252 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_253 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_254 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_255 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_256 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_257 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_258 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_259 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_260 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_261 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_262 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_263 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_264 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_265 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_266 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_267 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_268 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_269 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_270 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_271 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_272 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_273 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_274 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_275 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_276 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_277 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_278 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_279 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_280 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_281 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_282 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_283 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_284 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_285 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_286 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_287 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_288 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_289 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_290 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_291 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_292 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_293 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_294 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_295 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_296 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_297 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_298 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_299 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_300 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_301 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_302 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_303 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_304 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_305 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_306 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_307 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_308 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_309 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_310 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_311 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_312 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_313 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_314 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_315 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_316 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_317 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_318 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_319 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_320 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_321 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_322 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_323 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_324 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_325 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_326 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_327 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_328 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_329 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_330 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_331 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_332 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_333 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_334 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_335 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_336 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_337 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_338 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_339 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_340 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_341 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_342 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_343 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_344 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_345 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_346 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_347 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_348 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_349 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_350 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_351 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_352 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_353 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_354 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_355 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_356 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_357 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_358 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_359 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_360 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_361 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_362 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_363 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_364 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_365 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_366 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_367 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_368 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_369 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_370 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_371 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");
	var mask_graphics_372 = new cjs.Graphics().p("A6xBwIAAjfMA1jAAAIAADfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(33).to({graphics:mask_graphics_33,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_34,x:334.8,y:7.85}).wait(1).to({graphics:mask_graphics_35,x:334.8,y:11.475}).wait(1).to({graphics:mask_graphics_36,x:334.8,y:15.125}).wait(1).to({graphics:mask_graphics_37,x:334.8,y:18.75}).wait(1).to({graphics:mask_graphics_38,x:334.8,y:22.375}).wait(1).to({graphics:mask_graphics_39,x:334.8,y:26}).wait(1).to({graphics:mask_graphics_40,x:334.8,y:29.65}).wait(1).to({graphics:mask_graphics_41,x:334.8,y:33.275}).wait(1).to({graphics:mask_graphics_42,x:334.8,y:36.925}).wait(1).to({graphics:mask_graphics_43,x:334.8,y:40.55}).wait(1).to({graphics:mask_graphics_44,x:334.8,y:44.2}).wait(1).to({graphics:mask_graphics_45,x:334.8,y:47.825}).wait(1).to({graphics:mask_graphics_46,x:334.8,y:51.45}).wait(1).to({graphics:mask_graphics_47,x:334.8,y:55.075}).wait(1).to({graphics:mask_graphics_48,x:334.8,y:58.725}).wait(1).to({graphics:mask_graphics_49,x:334.8,y:62.35}).wait(1).to({graphics:mask_graphics_50,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_51,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_52,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_53,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_54,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_55,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_56,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_57,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_58,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_59,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_60,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_61,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_62,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_63,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_64,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_65,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_66,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_67,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_68,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_69,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_70,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_71,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_72,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_73,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_74,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_75,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_76,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_77,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_78,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_79,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_80,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_81,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_82,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_83,x:334.8,y:65.975}).wait(1).to({graphics:mask_graphics_84,x:334.8,y:58.275}).wait(1).to({graphics:mask_graphics_85,x:334.8,y:50.55}).wait(1).to({graphics:mask_graphics_86,x:334.8,y:42.825}).wait(1).to({graphics:mask_graphics_87,x:334.8,y:35.1}).wait(1).to({graphics:mask_graphics_88,x:334.8,y:27.4}).wait(1).to({graphics:mask_graphics_89,x:334.8,y:19.675}).wait(1).to({graphics:mask_graphics_90,x:334.8,y:11.95}).wait(1).to({graphics:mask_graphics_91,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_92,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_93,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_94,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_95,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_96,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_97,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_98,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_99,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_100,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_101,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_102,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_103,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_104,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_105,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_106,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_107,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_108,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_109,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_110,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_111,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_112,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_113,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_114,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_115,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_116,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_117,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_118,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_119,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_120,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_121,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_122,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_123,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_124,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_125,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_126,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_127,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_128,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_129,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_130,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_131,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_132,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_133,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_134,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_135,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_136,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_137,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_138,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_139,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_140,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_141,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_142,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_143,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_144,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_145,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_146,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_147,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_148,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_149,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_150,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_151,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_152,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_153,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_154,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_155,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_156,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_157,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_158,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_159,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_160,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_161,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_162,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_163,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_164,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_165,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_166,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_167,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_168,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_169,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_170,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_171,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_172,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_173,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_174,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_175,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_176,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_177,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_178,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_179,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_180,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_181,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_182,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_183,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_184,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_185,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_186,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_187,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_188,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_189,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_190,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_191,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_192,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_193,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_194,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_195,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_196,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_197,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_198,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_199,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_200,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_201,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_202,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_203,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_204,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_205,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_206,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_207,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_208,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_209,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_210,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_211,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_212,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_213,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_214,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_215,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_216,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_217,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_218,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_219,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_220,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_221,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_222,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_223,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_224,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_225,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_226,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_227,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_228,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_229,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_230,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_231,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_232,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_233,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_234,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_235,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_236,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_237,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_238,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_239,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_240,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_241,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_242,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_243,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_244,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_245,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_246,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_247,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_248,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_249,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_250,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_251,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_252,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_253,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_254,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_255,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_256,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_257,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_258,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_259,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_260,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_261,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_262,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_263,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_264,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_265,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_266,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_267,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_268,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_269,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_270,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_271,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_272,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_273,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_274,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_275,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_276,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_277,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_278,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_279,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_280,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_281,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_282,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_283,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_284,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_285,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_286,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_287,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_288,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_289,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_290,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_291,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_292,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_293,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_294,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_295,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_296,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_297,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_298,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_299,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_300,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_301,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_302,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_303,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_304,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_305,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_306,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_307,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_308,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_309,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_310,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_311,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_312,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_313,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_314,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_315,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_316,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_317,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_318,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_319,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_320,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_321,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_322,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_323,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_324,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_325,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_326,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_327,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_328,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_329,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_330,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_331,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_332,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_333,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_334,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_335,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_336,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_337,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_338,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_339,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_340,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_341,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_342,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_343,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_344,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_345,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_346,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_347,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_348,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_349,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_350,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_351,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_352,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_353,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_354,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_355,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_356,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_357,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_358,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_359,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_360,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_361,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_362,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_363,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_364,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_365,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_366,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_367,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_368,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_369,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_370,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_371,x:334.8,y:4.225}).wait(1).to({graphics:mask_graphics_372,x:334.8,y:4.225}).wait(68));

	// ice
	this.instance_11 = new lib.ice_1();
	this.instance_11.setTransform(378,45,1,1,0,0,0,150,125);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(33).to({_off:false},0).wait(50).to({regX:150.1,scaleX:0.72,scaleY:0.72,x:246.05,y:29,alpha:0},8).to({_off:true},282).wait(67));

	// cold_ice
	this.instance_12 = new lib.text_cold_1();
	this.instance_12.setTransform(373,43.05,1.0867,1.0867,0,0,0,150,125);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({alpha:1},8).wait(42).to({regX:150.1,regY:125.1,scaleX:0.6155,scaleY:0.6155,x:247.15,y:30.1,alpha:0},8).to({_off:true},2).wait(347));

	// text_cold1
	this.instance_13 = new lib.copy_01();
	this.instance_13.setTransform(338.25,38.6,1.0961,1.096,0,0,0,84.4,26.2);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(24).to({_off:false},0).to({alpha:1},9).wait(50).to({regX:84.3,scaleX:0.6324,scaleY:0.6323,x:226.45,y:28.25},8).to({_off:true},282).wait(67));

	// text_cold2
	this.instance_14 = new lib.text_andFluSeason();
	this.instance_14.setTransform(460,30.95,1,1,0,0,0,102.2,20.2);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(93).to({_off:false},0).to({alpha:1},4).to({_off:true},276).wait(67));

	// text_cold3
	this.instance_15 = new lib.text_cold3();
	this.instance_15.setTransform(70,66.95,1,1,0,0,0,69,20.2);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(93).to({_off:false},0).to({alpha:1},4).to({_off:true},276).wait(67));

	// germs
	this.instance_16 = new lib.germs("synched",0,false);
	this.instance_16.setTransform(200,-90);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(94).to({_off:false},0).wait(105).to({startPosition:105},0).to({alpha:0,startPosition:138},33).to({_off:true},20).wait(188));

	// white_box
	this.instance_17 = new lib.whitebox();
	this.instance_17.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(16).to({_off:false},0).to({alpha:0.4688},8).wait(39).to({alpha:1},31,cjs.Ease.get(1)).to({_off:true},279).wait(67));

	// logo
	this.instance_18 = new lib.logo_1();
	this.instance_18.setTransform(684.5,44,1,1,0,0,0,24.5,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(16).to({alpha:0},8,cjs.Ease.get(1)).to({_off:true},1).wait(415));

	// Layer_1
	this.instance_19 = new lib.frost();
	this.instance_19.setTransform(150,126,1,1,0,0,0,150,125);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(26).to({_off:false},0).to({alpha:1},7).to({_off:true},340).wait(67));

	// boy
	this.instance_20 = new lib.girl();
	this.instance_20.setTransform(169.4,144.7,0.9999,0.9999,-0.0009,0,0,169.4,144.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(63).to({alpha:0.0508},31,cjs.Ease.get(1)).to({_off:true},279).wait(67));

	// BG
	this.instance_21 = new lib.whitebox();
	this.instance_21.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({_off:true},373).wait(67));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(254,-160.2,674,443.5);
// library properties:
lib.properties = {
	id: '3CE4C820892743FB9D5BF0281A417E72',
	width: 728,
	height: 90,
	fps: 30,
	color: "#339999",
	opacity: 1.00,
	manifest: [
		{src:"images/boy.jpg?1574352553764", id:"boy"},
		{src:"images/boy_frost.jpg?1574352553764", id:"boy_frost"},
		{src:"images/germs_sm.png?1574352553764", id:"germs_sm"},
		{src:"images/hand_spray.png?1574352553764", id:"hand_spray"},
		{src:"images/ice.png?1574352553765", id:"ice"},
		{src:"images/logo.png?1574352553765", id:"logo"},
		{src:"images/product.png?1574352553765", id:"product"},
		{src:"images/spray_01.png?1574352553765", id:"spray_01"},
		{src:"images/spray_02.png?1574352553765", id:"spray_02"},
		{src:"images/text_cold.png?1574352553765", id:"text_cold"},
		{src:"images/whatittaketoprotect.png?1574352553765", id:"whatittaketoprotect"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3CE4C820892743FB9D5BF0281A417E72'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;