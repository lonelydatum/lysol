(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.boy = function() {
	this.initialize(img.boy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.boy_frost = function() {
	this.initialize(img.boy_frost);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.germs_sm = function() {
	this.initialize(img.germs_sm);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,150,125);


(lib.hand_spray = function() {
	this.initialize(img.hand_spray);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,87,172);


(lib.ice = function() {
	this.initialize(img.ice);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,49,46);


(lib.product = function() {
	this.initialize(img.product);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,71,109);


(lib.spray_01 = function() {
	this.initialize(img.spray_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,141,93);


(lib.spray_02 = function() {
	this.initialize(img.spray_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);


(lib.text_cold = function() {
	this.initialize(img.text_cold);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.whatittaketoprotect = function() {
	this.initialize(img.whatittaketoprotect);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,65,22);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whitebox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebox, new cjs.Rectangle(0,0,300,250), null);


(lib.whatittakes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.whatittaketoprotect();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whatittakes, new cjs.Rectangle(0,0,65,22), null);


(lib.text_cold3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape.setTransform(264.725,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AAtBjIgtiWIAAAAIgtCWIghAAIg6jEIAnAAIAlCNIAAAAIAsiNIAiAAIArCNIABAAIAniNIAjAAIg5DEg");
	this.shape_1.setTransform(240,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgHgTAAgXQAAgXAHgTQAIgTAOgOQANgNAUgIQASgHAXAAQAWgBATAIQAUAHAOANQAOAOAHATQAJATgBAXQABAXgJATQgHATgOAOQgOANgUAIQgTAIgWAAQgXAAgSgIgAgbhBQgNAFgIAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAIAKANAFQAMAGAPAAQAPAAANgGQAMgFAJgKQAJgKAFgNQAEgNAAgPQAAgPgEgNQgFgMgJgKQgJgKgMgFQgNgFgPAAQgPAAgMAFg");
	this.shape_2.setTransform(214.75,19.1984);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_3.setTransform(195.175,19.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AhDBjIAAjEICCAAIAAAfIhfAAIAAAxIBaAAIAAAeIhaAAIAAA2IBkAAIAAAgg");
	this.shape_4.setTransform(179.175,19.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_5.setTransform(162.225,19.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_6.setTransform(146.275,19.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgIgTABgXQgBgXAIgTQAIgTAOgOQANgNAUgIQATgHAWAAQAWgBAUAIQATAHAOANQANAOAIATQAJATAAAXQAAAXgJATQgIATgNAOQgOANgTAIQgUAIgWAAQgWAAgTgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQANAGAOAAQAPAAAMgGQANgFAJgKQAJgKAFgNQAEgNABgPQgBgPgEgNQgFgMgJgKQgJgKgNgFQgMgFgPAAQgOAAgNAFg");
	this.shape_7.setTransform(126.7,19.1984);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_8.setTransform(108.825,19.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AAgBjIgthUIgZAAIAABUIgjAAIAAjEIBEAAQANgBAOADQANADAKAGQAKAGAGALQAHALAAARQAAAVgMAPQgMAOgWACIA0BYgAgmgOIAbAAIAOgBQAIgBAGgCQAGgCAEgGQAEgGAAgJQAAgJgEgFQgDgGgGgCQgGgDgHgBIgNgBIgeAAg");
	this.shape_9.setTransform(92.825,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AA8BjIgSgtIhVAAIgRAtIgoAAIBWjEIAdAAIBVDEgAAeAXIgehPIgeBPIA8AAg");
	this.shape_10.setTransform(73.15,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AAuBjIAAhYIhbAAIAABYIgjAAIAAjEIAjAAIAABOIBbAAIAAhOIAjAAIAADEg");
	this.shape_11.setTransform(52.8,19.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgaBgQgTgIgNgNQgOgNgIgTQgIgTAAgXQAAgXAIgTQAIgUAOgNQANgOATgHQATgIAWAAQAUABARAGQARAIAPARIgbATQgLgLgKgEQgKgDgLAAQgPAAgLAEQgNAGgIAJQgJALgFAMQgFANAAAPQAAAOAFAOQAFANAJAKQAIAJANAGQALAFAPABQAMgBAMgFQALgGAKgMIAdAUQgOATgTAIQgTAJgWgBQgWABgTgIg");
	this.shape_12.setTransform(33.475,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_cold3, new cjs.Rectangle(0,0,299.2,40.5), null);


(lib.text_cold_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.text_cold();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_cold_1, new cjs.Rectangle(0,0,300,250), null);


(lib.text_andFluSeason = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape.setTransform(211.075,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgRBjIAAjEIAjAAIAADEg");
	this.shape_1.setTransform(196.15,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape_2.setTransform(173.025,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgqBgQgSgHgOgNQgOgOgIgTQgIgTAAgXQAAgXAIgTQAIgTAOgOQAOgNASgIQAUgHAWAAQAWgBAUAIQATAHAOANQANAOAJATQAHATABAXQgBAXgHATQgJATgNAOQgOANgTAIQgUAIgWAAQgWAAgUgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQAMAGAPAAQAPAAAMgGQANgFAJgKQAJgKAFgNQAFgNAAgPQAAgPgFgNQgFgMgJgKQgJgKgNgFQgMgFgPAAQgPAAgMAFg");
	this.shape_3.setTransform(150.35,19.1984);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_4.setTransform(130.475,19.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AA8BjIgSgtIhVAAIgRAtIgoAAIBWjEIAdAAIBVDEgAAeAXIgehPIgeBPIA8AAg");
	this.shape_5.setTransform(112.75,19.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AhDBjIAAjEICCAAIAAAfIhfAAIAAAxIBaAAIAAAeIhaAAIAAA2IBkAAIAAAgg");
	this.shape_6.setTransform(94.725,19.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_7.setTransform(77.425,19.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgeBfQgPgFgKgKQgLgKgGgOQgGgOAAgTIAAh7IAjAAIAAB6QAAAIACAIQACAHAGAHQAFAHAIAFQAJADALAAQANAAAIgDQAJgFAFgHQAFgHACgHQACgIAAgIIAAh6IAjAAIAAB7QAAATgGAOQgGAOgKAKQgLAKgOAFQgPAGgRAAQgQAAgOgGg");
	this.shape_8.setTransform(51.475,19.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_9.setTransform(35.175,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("Ag+BjIAAjEIB+AAIAAAfIhbAAIAAA0IBVAAIAAAfIhVAAIAABSg");
	this.shape_10.setTransform(19.65,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("Ag0BkQgMgEgKgHQgJgIgFgKQgGgLABgOQAAgLACgIQAEgIAFgIQAHgGAIgFQAHgGAJgDIgJgKIgHgLIgFgLQgBgGgBgHQABgMAEgJQAEgKAJgFQAHgHALgCQAKgEALAAQALAAAJAEQAKACAIAGQAHAGAFAIQAFAKgBALQAAAJgDAIQgDAHgGAHQgFAHgHAEIgOAJIAfAhIAWggIAnAAIgnA4IArAvIgsAAIgUgXQgMAOgOAHQgNAHgTgBQgNAAgMgDgAgnARIgJAGIgHAJQgCAFAAAHQAAAGACAGQADAFAFAEQAEAEAFACQAGACAGAAQALABAJgHIAPgNIgngsgAghhDQgHAFAAAKIACAHIAEAIIAGAGIAHAHIAJgFIAIgHQAEgDABgFQADgEAAgGQAAgIgGgGQgFgEgKAAQgJgBgHAGg");
	this.shape_11.setTransform(-6.95,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_andFluSeason, new cjs.Rectangle(-19,0,242.5,40.5), null);


(lib.spray_mist = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray_02();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.1533,scaleY:1.1533,rotation:180,x:323,y:311},0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0.118)","#FFFFFF","rgba(255,255,255,0)"],[0,0,0,1],0,0,0,0,0,113.3).s().p("AsbMcQlJlKAAnSQAAnRFJlKQFKlJHRAAQHTAAFIFJQFKFKAAHRQAAHSlKFKQlIFJnTAAQnRAAlKlJg");
	this.shape.setTransform(156,154.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-307.5,-189.5,1129.1,765);


(lib.spray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray_01();
	this.instance.setTransform(4.5,0,1,0.8635,3.2113);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,88.1);


(lib.product_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.product();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.product_1, new cjs.Rectangle(0,0,71,109), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(0,0,49,46), null);


(lib.ice_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ice();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ice_1, new cjs.Rectangle(0,0,300,250), null);


(lib.girl = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.boy();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girl, new cjs.Rectangle(0,0,300,250), null);


(lib.germs_group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.germs_sm();
	this.instance.setTransform(-6,127,1,1,0,-90,90);

	this.instance_1 = new lib.germs_sm();
	this.instance_1.setTransform(112,277,1,1,-90);

	this.instance_2 = new lib.germs_sm();
	this.instance_2.setTransform(381,140,1,1,0,0,180);

	this.instance_3 = new lib.germs_sm();
	this.instance_3.setTransform(421,0,1,1,90);

	this.instance_4 = new lib.germs_sm();
	this.instance_4.setTransform(310,0,1,1,90);

	this.instance_5 = new lib.germs_sm();
	this.instance_5.setTransform(40,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.germs_group, new cjs.Rectangle(-6,0,427,277), null);


(lib.frost = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.boy_frost();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.frost, new cjs.Rectangle(0,0,300,250), null);


(lib.copy_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AgCADQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgCg");
	this.shape.setTransform(119.025,18.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_1.setTransform(116.95,15.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_2.setTransform(113.825,17.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgHAdIgFgGIAAAHIgHAAIAAg8IAHAAIAAAdQACgDAEgCQADgCADAAQAFAAADACIAGAEIAEAFQACAEAAAEQAAAEgCAEIgEAGIgFAEQgEACgEAAQgEAAgEgCgAgFgBIgEACQgCACAAADIgBAFIABAGQAAAAAAABQAAAAABABQAAAAAAABQABAAAAABIAEADIAFABIAFgBIAFgDIACgEIABgGIgBgFIgCgFIgFgCIgFgBIgFABg");
	this.shape_3.setTransform(109.275,15.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_4.setTransform(104.625,17.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_5.setTransform(101.65,15.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_6.setTransform(96.325,17.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AAKAeIAAgWQAAgFgCgDQgCgBgEAAIgFABIgDACIgCAEIgBAGIAAASIgGAAIAAg7IAGAAIAAAcIAAAAIACgCIADgCIADgCIADAAIAGABIAFADQACACAAACIABAGIAAAXg");
	this.shape_7.setTransform(91.925,15.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AAAAYIgCgDIgBgEIgBgFIAAgUIgIAAIAAgFIAIAAIAAgLIAGAAIAAALIALAAIAAAFIgLAAIAAASIAAADIAAADIACACIADAAIADAAIADAAIAAAFIgEABIgDABIgGgBg");
	this.shape_8.setTransform(88.275,16.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AAKATIgKgcIAAAAIgJAcIgGAAIgMglIAGAAIAJAcIAKgcIAFAAIAKAcIAJgcIAGAAIgLAlg");
	this.shape_9.setTransform(81.75,17.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgIASIgGgEIgDgGIgCgIQAAgDACgEQABgEACgCIAGgEQAEgCAEAAIAIACIAGAEQACACACAEQACAEAAADQAAAEgCAEIgEAGIgGAEIgIACQgEAAgEgCgAgFgMIgEADIgCAFIgCAEIACAGIACAEIAEADIAFABIAGgBIAEgDIACgEIABgGIgBgEIgCgFIgEgDIgGgBIgFABg");
	this.shape_10.setTransform(76.45,17.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_11.setTransform(73.1,15.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_12.setTransform(71.2,15.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgIASIgGgEIgDgGIgCgIQAAgDACgEQABgEACgCIAGgEQAEgCAEAAIAIACIAGAEQACACACAEQACAEAAADQAAAEgCAEIgEAGIgGAEIgIACQgEAAgEgCgAgFgMIgEADIgCAFIgCAEIACAGIACAEIAEADIAFABIAGgBIADgDIADgEIABgGIgBgEIgDgFIgDgDIgGgBIgFABg");
	this.shape_13.setTransform(67.9,17.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgEAfIAAgfIgIAAIAAgGIAIAAIAAgIIABgGIACgFIADgEIAGgBIADABIACAAIgBAGIgEgBIgDABIgDACIgBAEIAAAEIAAAHIAJAAIAAAGIgJAAIAAAfg");
	this.shape_14.setTransform(64.4,15.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_15.setTransform(58.325,15.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AALATIAAgVQgBgFgCgDQgCgCgEAAIgFABIgDADIgCAEIgBAFIAAASIgGAAIAAgbIAAgFIAAgEIAGAAIAAADIAAADIAAAAIACgDIACgCIAEgCIAEAAIAGABIAEADQACACAAADIACAGIAAAWg");
	this.shape_16.setTransform(53.75,17.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_17.setTransform(49.425,17.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_18.setTransform(42.725,15.975);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_19.setTransform(38.225,17.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_20.setTransform(34.025,17.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgJATIAAgbIgBgFIAAgEIAGAAIAAADIAAADIABAAIABgDIACgCIAEgCIAEAAIABAAIACAAIgBAHIgDgBQgGAAgBAEQgDAEAAAFIAAASg");
	this.shape_21.setTransform(30.625,17.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABgBAAAAIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_22.setTransform(25.075,17.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgOAcIgDgBIABgFIACABIACAAQABAAABAAQABAAAAgBQABAAAAAAQABAAAAgBIADgEIACgIIgQgkIAHAAIALAcIAAAAIAMgcIAGAAIgSAtIgBAEIgCAEIgDACIgGAAg");
	this.shape_23.setTransform(21.5,18.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_24.setTransform(17.425,17.075);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AALATIgLgcIAAAAIgJAcIgGAAIgMglIAGAAIAJAcIAKgcIAFAAIAKAcIAJgcIAHAAIgMAlg");
	this.shape_25.setTransform(12.45,17.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2B3785").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_26.setTransform(8.55,15.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2B3785").s().p("AAUAcIgGgOIgbAAIgGAOIgIAAIAZg3IAGAAIAYA3gAALAIIgLgbIgLAbIAWAAg");
	this.shape_27.setTransform(4.825,16.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B3785").s().p("AgCADQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgCg");
	this.shape_28.setTransform(85.075,9.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_29.setTransform(81.475,7.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_30.setTransform(76.925,8.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2B3785").s().p("AAAAXIgCgCIgBgEIgBgFIAAgTIgIAAIAAgGIAIAAIAAgKIAGAAIAAAKIALAAIAAAGIgLAAIAAARIAAADIAAADIACACIADABIADAAIADgCIAAAGIgEABIgDAAIgGgBg");
	this.shape_31.setTransform(73.275,7.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2B3785").s().p("AgFASIgGgEQgCgCgCgEIgBgIIABgHIAEgGIAGgEIAHgCQAFAAADACQAEABADADIgFAFIgFgEIgFgBIgEABIgEADIgCAFIgBAEIABAFIACAFIAEADIAEABQAHAAADgFIAFAFQgDADgEABIgIACIgHgCg");
	this.shape_32.setTransform(70.125,8.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_33.setTransform(65.875,8.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2B3785").s().p("AgJATIAAgbIgBgFIAAgEIAGAAIAAADIAAADIABAAIABgDIACgCIAEgCIAEAAIABAAIACAAIgBAHIgDgBQgGAAgBAEQgDAEAAAFIAAASg");
	this.shape_34.setTransform(62.475,8.075);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2B3785").s().p("AgCAcIAAgkIAFAAIAAAkgAgCgUQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAIACgBIADABIACADIgCADQAAABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQgBAAAAgBg");
	this.shape_35.setTransform(59.9,7.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_36.setTransform(56.475,7.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2B3785").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_37.setTransform(50.175,8.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2B3785").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_38.setTransform(46.375,8.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2B3785").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_39.setTransform(39.675,7.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_40.setTransform(35.125,8.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2B3785").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_41.setTransform(31.175,8.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2B3785").s().p("AgIASIgEgDQgCgCAAgDIgBgGIAAgWIAFAAIAAAVQABAFACADQACACAEAAIAFgBIADgDQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIABgFIAAgSIAGAAIAAAbIAAAFIAAAEIgFAAIAAgDIAAgDIgBAAIgCADIgDACIgDACIgEAAIgGgBg");
	this.shape_42.setTransform(27.35,8.175);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#2B3785").s().p("AALATIAAgVQAAgFgDgDQgCgCgEAAIgFABIgDADIgCAEIgBAFIAAASIgGAAIAAgbIAAgFIAAgEIAFAAIAAADIAAADIABAAIACgDIADgCIADgCIAEAAIAFABIAFADQACACAAADIABAGIAAAWg");
	this.shape_43.setTransform(20.7,8.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2B3785").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_44.setTransform(16.325,8.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2B3785").s().p("AAKAeIAAgWQAAgFgCgDQgCgBgEAAIgFABIgDACIgCAEIgBAGIAAASIgGAAIAAg7IAGAAIAAAcIAAAAIACgCIADgCIADgCIADAAIAGABIAFADQACACAAACIABAGIAAAXg");
	this.shape_45.setTransform(11.925,6.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2B3785").s().p("AAOAcIgOgvIgNAvIgIAAIgQg3IAHAAIAOAuIANguIAHAAIAOAuIANguIAHAAIgQA3g");
	this.shape_46.setTransform(5.85,7.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_04, new cjs.Rectangle(0,0,122.3,23.9), null);


(lib.copy_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AgGARIgGgEIgEgGIgCgHQABgDABgDIAEgGQADgDADgBIAGgBQAEAAAEABQADABACADIAEAGQACADgBADIgBAHIgEAGIgFAEIgIABIgGgBg");
	this.shape.setTransform(160.25,43.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgXAwQgLgDgGgIIASgTQAEAFAFADQAFACAHAAQAEAAAEgBQAFgCgBgEQAAgDgEgCIgIgEIgMgDQgGgBgGgDQgGgDgEgEQgDgGAAgJQgBgJAEgGQAEgHAFgEQAGgDAIgCQAHgCAGAAQAKAAAKADQAKACAGAIIgSASQgHgIgLAAQgCAAgDABQgFACAAAFQAAAEAFABIAIADIAMADQAGACAGACQAGADADAFQAFAFAAAKQgBAJgEAHQgEAFgHAEQgFAEgIABQgJACgGAAQgKAAgLgDg");
	this.shape_1.setTransform(152.7,40.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AAvAyIAAg4QAAgHgDgFQgEgEgHAAQgFAAgDABQgEACgCADIgDAHIgBAIIAAAzIgdAAIAAgzIAAgGIgCgHIgDgGQgDgCgFAAQgGAAgEACQgDACgCADIgDAIIAAAIIAAAxIgfAAIAAhgIAeAAIAAANIAAAAIAEgGIAGgFIAIgDIAKgCQAKAAAIAEQAHAFAEAJQAFgKAIgEQAHgEALAAQAKAAAGADQAHAEAEAFQAEAGABAIQACAIAAAIIAAA5g");
	this.shape_2.setTransform(139.35,40.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AghAyIAAhgIAeAAIAAAPIAAAAQAEgJAHgEQAGgFAKAAIAFAAIAFABIAAAcIgGgCIgHAAQgIAAgFACQgFACgDAFQgCAEAAAGIgBAMIAAApg");
	this.shape_3.setTransform(127.025,40.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgQAvQgKgEgHgGQgHgHgEgJQgFgKAAgLQAAgKAFgKQAEgKAHgGQAHgHAKgDQAKgEAKAAQALAAAIAEQAJADAGAHQAGAGADAKQADAKAAAKIAAAJIhFAAQACAJAGAFQAGAFAIAAQAHAAAFgDQAGgEADgEIAVAOQgHAKgLAFQgLAFgMAAQgKAAgKgEgAgGgbQgEABgDADIgEAGIgCAHIAnAAQAAgHgFgGQgFgGgIABQgEAAgEABg");
	this.shape_4.setTransform(116.825,40.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgcBHQgNgDgKgIIAQgZQAHAGAIADQAIADAJAAQANAAAGgGQAHgHAAgKIAAgKIgBAAQgFAHgHADQgIADgGAAQgLAAgJgEQgIgDgHgHQgGgHgDgIQgEgJAAgLQAAgKADgJQADgJAGgHQAGgHAIgFQAIgEALAAQAGAAAEACIAKADIAHAFIAFAFIAAAAIAAgMIAcAAIAABYQAAAbgOAOQgOAPgbAAQgNAAgNgDgAgHgsQgFACgDADQgDADgCAEQgCAFAAAFQAAAEACAFQACAEADADQADAEAFACQAEABAEAAQAFAAAFgBQAEgCADgEQAEgDABgEQACgFAAgEQAAgFgCgFQgBgEgEgDQgDgDgEgCQgFgCgFAAQgEAAgEACg");
	this.shape_5.setTransform(104.475,42.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgcAuQgHgDgEgHQgEgGgBgIQgCgJAAgJIAAg1IAeAAIAAAwIABAHQAAAFABAEQACADADADQADACAGAAQAFAAADgCQAEgCACgDQACgEAAgEIABgJIAAgwIAeAAIAABgIgdAAIAAgNIAAAAIgEAGIgGAFIgIADQgEACgGAAQgLAAgHgEg");
	this.shape_6.setTransform(86.875,40.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_7.setTransform(78.55,37.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgRBNIAAhJIgUAAIAAgXIAUAAIAAgSQAAgIACgHQABgHAEgFQAEgGAHgDQAHgDAMAAIAJABIAJABIgCAZIgEgBIgFgBQgIAAgDADQgEAEAAAJIAAAQIAWAAIAAAXIgWAAIAABJg");
	this.shape_8.setTransform(72.425,37.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AgnBIQgIgDgIgFQgGgFgFgIQgEgIAAgLQAAgHACgGQADgGAEgFQAEgFAFgDIAMgGIgHgHIgEgHIgEgIIgBgJQAAgKAEgHQADgHAHgEQAGgEAIgCQAIgCAIAAQAJAAAGACQAHACAGAEQAGAEADAHQAEAGAAAJQAAAHgCAFQgDAGgDAEIgIAJIgKAGIASATIANgSIAjAAIgeAmIAgAiIgnAAIgLgOQgJAJgKAEQgJAEgNAAQgJAAgKgCgAgcAOIgEAEIgFAGIgBAHQAAAEACADIAEAFIAGAEIAHABQAHAAAGgDIAJgHIgZgcgAgWguQgDAEAAAGIABAFIACAFIAEAEIAEAEIAGgEIAEgEIAEgFIABgGQAAgGgDgDQgEgDgGAAQgGAAgEADg");
	this.shape_9.setTransform(55.45,38.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgYBJQgIgEgHgGQgGgHgDgJQgEgKAAgLQAAgKADgJQADgIAGgIQAGgHAIgEQAIgEALAAQAIAAAIADQAIACAFAHIABAAIAAhAIAeAAIAACWIgcAAIAAgNIAAAAIgFAGIgHAFIgIADQgFACgEAAQgLAAgJgEgAgPAIQgHAHAAALQAAALAHAGQAGAHAKAAQAMAAAGgHQAGgGAAgLQAAgLgGgHQgGgHgMAAQgKAAgGAHg");
	this.shape_10.setTransform(34.975,37.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_11.setTransform(26.4,37.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgUAvQgKgEgHgGQgIgHgEgJQgEgKAAgLQAAgKAEgKQAEgKAIgGQAHgHAKgDQAKgEAKAAQALAAAKAEQAKADAHAHQAIAGAEAKQAEAKAAAKQAAALgEAKQgEAJgIAHQgHAGgKAEQgKAEgLAAQgKAAgKgEgAgRgRQgGAHAAAKQAAALAGAHQAHAGAKABQAMgBAFgGQAHgHAAgLQAAgKgHgHQgFgGgMgBQgKABgHAGg");
	this.shape_12.setTransform(17.7,40.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgKAvQgKgEgHgGQgIgHgEgJQgEgKAAgLQAAgKAEgKQAEgKAIgGQAHgHAKgDQAKgEAKAAQAIAAAKADQAJADAHAHIgTAVQgDgDgEgDQgEgCgEAAQgLABgGAGQgGAHAAAKQAAALAGAHQAGAGALABQAFAAADgDIAHgFIATAVQgHAHgJADQgKADgIAAQgKAAgKgEg");
	this.shape_13.setTransform(7.175,40.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgRBNIAAhJIgUAAIAAgXIAUAAIAAgSQAAgIACgHQABgHAEgFQAEgGAHgDQAHgDAMAAIAJABIAJABIgCAZIgEgBIgFgBQgIAAgDADQgEAEAAAJIAAAQIAWAAIAAAXIgWAAIAABJg");
	this.shape_14.setTransform(125.525,14.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgUAvQgKgEgIgGQgGgGgFgKQgEgKAAgLQAAgKAEgKQAFgJAGgHQAIgHAKgDQAKgEAKAAQALAAAKAEQAKADAIAHQAGAHAFAJQAEAKAAAKQAAALgEAKQgFAKgGAGQgIAGgKAEQgKAEgLAAQgKAAgKgEgAgRgRQgGAHAAAKQAAALAGAGQAHAIAKAAQAMAAAFgIQAHgGAAgLQAAgKgHgHQgFgHgMAAQgKAAgHAHg");
	this.shape_15.setTransform(115.55,17.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AAAAMIgKANIgKgHIALgOIgSgGIAFgLIARAFIAAgSIAMAAIAAASIARgFIAEAMIgRAFIAKAOIgKAIg");
	this.shape_16.setTransform(100.425,8.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AgwBFIBQiRIARAJIhSCQgAAjBGQgHgDgGgFQgFgGgDgHQgDgHAAgJQAAgIADgHQADgHAFgGQAGgFAHgCQAHgDAIAAQAIAAAIADQAHACAFAFQAFAGAEAHQADAHAAAIQAAAJgDAHQgEAHgFAGQgFAFgHADQgIADgIAAQgIAAgHgDgAAlAUQgGAFAAAIQAAAJAGAFQAFAGAIAAQAIAAAGgGQAFgFAAgJQAAgIgFgFQgGgGgIAAQgIAAgFAGgAhBADQgHgDgFgFQgGgFgDgHQgDgHAAgJQAAgIADgHQADgHAGgGQAFgFAHgDQAHgDAJAAQAIAAAHADQAHADAGAFQAFAGADAHQADAHAAAIQAAAJgDAHQgDAHgFAFQgGAFgHADQgHADgIAAQgJAAgHgDgAg/guQgFAFAAAIQAAAIAFAGQAGAGAIAAQAIAAAFgGQAGgGAAgIQAAgIgGgFQgFgGgIAAQgIAAgGAGg");
	this.shape_17.setTransform(88.275,14.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AgfBIIAggzIgEABIgFABQgKAAgIgEQgIgEgGgGQgGgFgDgJQgDgIAAgKQAAgKAEgKQAEgIAHgHQAHgGAKgEQAKgDAKAAQALAAAKADQAJAEAHAGQAHAHAFAIQAEAKAAAKQAAAIgCAHIgDAKIgGALIgGALIgfAwgAgQglQgGAGAAAKQAAAKAGAFQAHAGAJAAQAKAAAGgGQAHgFAAgKQAAgKgHgGQgGgGgKgBQgJABgHAGg");
	this.shape_18.setTransform(73.375,14.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgGARIgGgEIgEgGIgBgHQAAgDABgDIAEgGQADgDADgBIAGgBQAEAAADABQADABADADIAEAGQACADAAADIgCAHIgEAGIgGAEIgHABIgGgBg");
	this.shape_19.setTransform(64.45,20.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AgfBIIAggzIgEABIgFABQgKAAgIgEQgIgEgGgGQgGgFgDgJQgDgIAAgKQAAgKAEgKQAEgIAHgHQAHgGAKgEQAKgDAKAAQALAAAKADQAJAEAHAGQAHAHAFAIQAEAKAAAKQAAAIgCAHIgDAKIgGALIgGALIgfAwgAgQglQgGAGAAAKQAAAKAGAFQAHAGAJAAQAKAAAGgGQAHgFAAgKQAAgKgHgGQgGgGgKgBQgJABgHAGg");
	this.shape_20.setTransform(55.675,14.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgfBIIAggzIgEABIgFABQgKAAgIgEQgIgEgGgGQgGgFgDgJQgDgIAAgKQAAgKAEgKQAEgIAHgHQAHgGAKgEQAKgDAKAAQALAAAKADQAJAEAHAGQAHAHAFAIQAEAKAAAKQAAAIgCAHIgDAKIgGALIgGALIgfAwgAgQglQgGAGAAAKQAAAKAGAFQAHAGAJAAQAKAAAGgGQAHgFAAgKQAAgKgHgGQgGgGgKgBQgJABgHAGg");
	this.shape_21.setTransform(43.875,14.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_22.setTransform(29.4,14.45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgOBLIAAiVIAdAAIAACVg");
	this.shape_23.setTransform(24.2,14.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgOBIIAAhfIAdAAIAABfgAgMgqQgEgFAAgIQAAgGAEgFQAGgFAGgBQAHABAGAFQAEAFABAGQgBAIgEAFQgGAFgHAAQgGAAgGgFg");
	this.shape_24.setTransform(19,14.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AAXBHIg5hDIAABDIgfAAIAAiNIAfAAIAAA7IA2g7IApAAIg+BCIBDBLg");
	this.shape_25.setTransform(10.175,14.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_03, new cjs.Rectangle(0,0,165.4,54.6), null);


(lib.copy_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AASA0IAAgyIgBgIQAAgFgCgEQgBgEgDgCQgEgDgGAAQgFAAgEADQgDACgCADQgCAEgBAFIgBAIIAAAzIgfAAIAAhlIAeAAIAAAOIABAAIAEgGIAGgFIAIgEQAFgBAFAAQAMAAAIADQAHAEAEAHQAEAGACAJQABAJAAAKIAAA3g");
	this.shape.setTransform(223.075,40.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgVAyQgLgEgHgHQgIgHgEgKQgFgKAAgMQAAgLAFgKQAEgKAIgHQAHgHALgEQAKgEALABQAMgBAKAEQAKAEAIAHQAIAHAEAKQAFAKAAALQAAAMgFAKQgEAKgIAHQgIAHgKAEQgKAEgMAAQgLAAgKgEgAgSgRQgGAGAAALQAAALAGAIQAHAHALAAQAMAAAGgHQAHgIAAgLQAAgLgHgGQgGgIgMAAQgLAAgHAIg");
	this.shape_1.setTransform(210.575,40.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgYAyQgLgCgIgJIATgUQAFAFAFADQAGADAHAAQAFgBAEgBQAEgCAAgEQAAgEgDgCIgJgDIgOgDQgGgCgGgDQgGgDgEgFQgEgGAAgJQAAgJAEgGQADgHAHgEQAFgFAIgBQAIgCAHAAQAKAAAKACQALADAGAIIgTATQgHgJgLAAQgDAAgEADQgDABAAAEQAAAFADACIAJACIANAEQAHABAGADQAGAEAEAEQAEAHAAAJQAAAKgFAGQgEAGgGAFQgIAEgIABQgIACgIAAQgKgBgLgDg");
	this.shape_2.setTransform(199.2,40.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgaAzQgGgCgFgDQgFgFgDgFQgDgGAAgIQAAgJAEgGQADgGAFgDQAGgEAHgCQAHgDAIgBIAOgBIAOAAQAAgJgGgEQgGgFgIAAQgHAAgGADQgHADgFAGIgRgRQAKgJALgEQAMgDALAAQAOgBAKAEQAIADAFAHQAGAHACAJQACALAAAMIAAAzIgdAAIAAgNQgGAIgIAEQgIAEgJAAQgHgBgIgCgAgGAJQgFABgDADQgDADAAAFQAAAGAEADQAFACAGAAIAHgBIAIgDIAFgHQACgDAAgFIAAgHIgIAAIgJAAg");
	this.shape_3.setTransform(188.5,40.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgRAyQgKgEgIgHQgHgHgFgKQgEgKAAgMQAAgLAEgKQAFgKAHgHQAIgHAKgEQALgEAKABQALgBAJAEQAJAEAGAHQAHAHADAKQADAKAAALIAAAKIhIAAQACAJAGAFQAHAFAIABQAIgBAFgDQAFgEAEgFIAXAQQgIAKgMAFQgLAGgNAAQgKAAgLgEgAgHgcIgHAEIgEAGQgCADAAAEIApAAQAAgHgFgGQgGgGgJAAQgEAAgEACg");
	this.shape_4.setTransform(176.875,40.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgYAyQgLgCgHgJIASgUQAFAFAFADQAGADAHAAQAFgBAEgBQAEgCAAgEQAAgEgDgCIgJgDIgOgDQgGgCgGgDQgGgDgEgFQgEgGAAgJQAAgJAEgGQADgHAHgEQAFgFAIgBQAIgCAHAAQAKAAAKACQALADAGAIIgTATQgHgJgLAAQgDAAgEADQgDABAAAEQAAAFADACIAJACIANAEQAHABAGADQAGAEAEAEQAEAHAAAJQAAAKgFAGQgEAGgHAFQgHAEgIABQgIACgIAAQgKgBgLgDg");
	this.shape_5.setTransform(165.9,40.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgeAxQgHgEgEgHQgEgGgCgJQgBgJAAgKIAAg3IAfAAIAAAyIABAIIACAJQABAEADACQAEADAGAAQAFAAAEgDQADgCACgEIADgIIABgJIAAgyIAfAAIAABlIgeAAIAAgOIgFAGIgGAFIgIAEQgFABgFAAQgMAAgIgDg");
	this.shape_6.setTransform(148.625,40.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgPBPIAAidIAfAAIAACdg");
	this.shape_7.setTransform(139.775,37.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgSBRIAAhNIgVAAIAAgYIAVAAIAAgSQAAgJACgHQABgIAEgFQAFgGAGgDQAIgEANAAIAKABIAJABIgCAbIgFgCIgFAAQgIAAgDADQgEADAAALIAAAQIAXAAIAAAYIgXAAIAABNg");
	this.shape_8.setTransform(133.275,37.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AgpBLQgJgCgHgGQgIgGgFgIQgDgIAAgLQgBgIADgGQACgGAFgGIAKgIQAFgEAHgCIgHgIIgFgHIgDgJIgCgJQABgLAEgHQADgHAGgEQAHgFAJgCQAIgCAJAAQAIAAAHACQAIACAGAFQAGAEAEAHQADAHAAAJQAAAHgCAGIgGAKIgJAJIgLAHIATATIAPgSIAlAAIgfAoIAgAjIgoAAIgNgOQgIAKgLAEQgKAEgNAAQgKAAgKgDgAgdAPIgGAEIgDAGQgBADAAAEQAAAEABAEIAEAFQADADAEABQADABAFAAQAGAAAGgDQAFgDAEgFIgZgcgAgXgwQgEAEAAAGIABAFIADAFIAFAFIADAEIAGgEIAGgEIADgGQABgCAAgEQAAgGgDgEQgEgDgGAAQgHAAgEAEg");
	this.shape_9.setTransform(115.25,38.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgZBMQgJgDgHgHQgGgIgEgJQgDgKAAgLQAAgLADgKQADgIAGgIQAGgIAJgEQAIgFALABQAJAAAJACQAIADAGAIIAAhDIAfAAIAACdIgdAAIAAgNIgFAFIgHAFIgJAEQgFACgEAAQgMgBgJgEgAgQAJQgHAGAAAMQAAALAHAIQAGAHALAAQAMAAAHgHQAGgIAAgLQAAgMgGgGQgHgIgMAAQgLAAgGAIg");
	this.shape_10.setTransform(93.575,37.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgPBPIAAidIAfAAIAACdg");
	this.shape_11.setTransform(84.475,37.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgVAyQgLgEgHgHQgIgHgEgKQgFgKAAgMQAAgLAFgKQAEgKAIgHQAHgHALgEQAKgEALABQAMgBAKAEQAKAEAIAHQAIAHAEAKQAFAKAAALQAAAMgFAKQgEAKgIAHQgIAHgKAEQgKAEgMAAQgLAAgKgEgAgSgRQgGAGAAALQAAALAGAIQAHAHALAAQAMAAAGgHQAHgIAAgLQAAgLgHgGQgGgIgMAAQgLAAgHAIg");
	this.shape_12.setTransform(75.275,40.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgLAyQgLgEgHgHQgIgHgEgKQgFgKABgMQgBgLAFgKQAEgKAIgHQAHgHALgEQAKgEALABQAJAAAKACQAKADAIAIIgVAWQgDgDgEgDQgEgCgFAAQgLAAgGAIQgHAGAAALQAAALAHAIQAGAHALAAQAGAAADgDIAHgFIAVAWQgIAHgKADQgKADgJABQgLAAgKgEg");
	this.shape_13.setTransform(64.1,40.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgYAyQgLgCgIgJIATgUQAFAFAGADQAFADAHAAQAEgBAFgBQAEgCAAgEQAAgEgEgCIgIgDIgNgDQgHgCgGgDQgGgDgEgFQgEgGAAgJQAAgJAEgGQAEgHAFgEQAHgFAHgBQAIgCAHAAQAKAAALACQAJADAIAIIgUATQgGgJgMAAQgDAAgDADQgFABAAAEQAAAFAFACIAJACIAMAEQAHABAGADQAGAEAEAEQADAHABAJQgBAKgDAGQgFAGgHAFQgGAEgJABQgIACgHAAQgLgBgLgDg");
	this.shape_14.setTransform(47.4,40.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgPBMIAAhlIAfAAIAABlgAgMgsQgFgFAAgIQAAgHAFgGQAGgFAGAAQAIAAAFAFQAFAGAAAHQAAAIgFAFQgFAFgIAAQgGAAgGgFg");
	this.shape_15.setTransform(39.725,38.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AASBPIAAgyIgBgJQAAgFgCgEQgBgEgDgCQgEgDgGAAQgFAAgEADQgDACgCADQgCAEgBAFIgBAJIAAAzIgfAAIAAidIAfAAIAABGIABAAIADgGIAGgFIAIgEQAFgBAFAAQAMAAAIADQAHAEAEAHQAEAGACAIQABAJAAAKIAAA4g");
	this.shape_16.setTransform(30.875,37.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AADBCQgGgCgFgDQgFgEgCgGQgDgGAAgJIAAgvIgVAAIAAgZIAVAAIAAgeIAeAAIAAAeIAcAAIAAAZIgcAAIAAAhIABAIQAAADACADQABACADABQADACAFAAIAHAAQAEgBACgCIAAAaIgLADIgLABQgIAAgHgCg");
	this.shape_17.setTransform(20.325,39.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AgYAyQgLgDgIgHIATgWQAFAGAFACQAGAEAHAAQAFAAAEgCQAEgBAAgFQAAgDgDgDIgJgDIgOgDQgGgCgGgDQgGgDgEgFQgEgGAAgJQAAgJAEgGQAEgHAGgFQAFgDAIgCQAIgCAHgBQAKABAKADQALADAGAHIgTATQgGgJgMAAQgDAAgEACQgDACAAAFQAAAEADACIAJACIANADQAHACAGAEQAGACAEAGQADAFABAKQAAAKgFAGQgEAGgHAFQgGAEgJABQgIABgHAAQgLAAgLgDg");
	this.shape_18.setTransform(238.45,17.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgRAyQgKgEgIgHQgHgHgFgKQgEgKAAgMQAAgLAEgKQAFgKAHgHQAIgHAKgEQALgEAKAAQALAAAJAEQAJAEAGAHQAHAHADAKQADAKAAALIAAAKIhIAAQACAJAGAFQAHAGAIAAQAIAAAFgEQAFgDAEgGIAXAQQgIAKgMAFQgLAGgNgBQgKABgLgEgAgHgcIgHAEIgEAGQgCAEAAADIApAAQAAgHgFgGQgGgGgJAAQgEAAgEACg");
	this.shape_19.setTransform(227.475,17.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AASA0IAAgyIgBgIQAAgFgCgEQgBgEgDgCQgEgDgGAAQgFAAgEADQgDACgCADQgCAEgBAFIgBAIIAAAzIgfAAIAAhlIAeAAIAAAOIABAAIAEgGIAGgFIAIgEQAFgBAFAAQAMAAAIADQAHAEAEAHQAEAGACAJQABAJAAAKIAAA3g");
	this.shape_20.setTransform(215.325,17.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgVAyQgLgEgHgHQgIgHgEgKQgFgKAAgMQAAgLAFgKQAEgKAIgHQAHgHALgEQAKgEALAAQAMAAAKAEQAKAEAIAHQAIAHAEAKQAFAKAAALQAAAMgFAKQgEAKgIAHQgIAHgKAEQgKAEgMgBQgLABgKgEgAgSgSQgGAIAAAKQAAAMAGAGQAHAIALAAQAMAAAGgIQAHgGAAgMQAAgKgHgIQgGgHgMAAQgLAAgHAHg");
	this.shape_21.setTransform(202.825,17.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgZBNQgJgEgHgHQgGgIgEgJQgDgJAAgMQAAgLADgKQADgJAGgHQAGgHAJgFQAIgFALAAQAJABAJADQAIADAGAHIAAhEIAfAAIAACeIgdAAIAAgNIgFAFIgHAFIgJAEQgFABgEAAQgMAAgJgDgAgQAIQgHAIAAALQAAAMAHAGQAGAIALAAQAMAAAHgIQAGgGAAgMQAAgLgGgIQgHgHgMAAQgLAAgGAHg");
	this.shape_22.setTransform(183.075,15.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgRAyQgKgEgIgHQgHgHgFgKQgEgKAAgMQAAgLAEgKQAFgKAHgHQAIgHAKgEQALgEAKAAQALAAAJAEQAJAEAGAHQAHAHADAKQADAKAAALIAAAKIhIAAQACAJAGAFQAHAGAIAAQAIAAAFgEQAFgDAEgGIAXAQQgIAKgMAFQgLAGgNgBQgKABgLgEgAgHgcIgHAEIgEAGQgCAEAAADIApAAQAAgHgFgGQgGgGgJAAQgEAAgEACg");
	this.shape_23.setTransform(170.675,17.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgPAzIgqhlIAiAAIAZBEIAYhEIAgAAIgpBlg");
	this.shape_24.setTransform(158.75,17.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AgVAyQgLgEgHgHQgIgHgEgKQgFgKAAgMQAAgLAFgKQAEgKAIgHQAHgHALgEQAKgEALAAQAMAAAKAEQAKAEAIAHQAIAHAEAKQAFAKAAALQAAAMgFAKQgEAKgIAHQgIAHgKAEQgKAEgMgBQgLABgKgEgAgSgSQgGAIAAAKQAAAMAGAGQAHAIALAAQAMAAAGgIQAHgGAAgMQAAgKgHgIQgGgHgMAAQgLAAgHAHg");
	this.shape_25.setTransform(146.425,17.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2B3785").s().p("AgPBPIAAidIAfAAIAACdg");
	this.shape_26.setTransform(137.175,15.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2B3785").s().p("AgjA0IAAhlIAgAAIAAARIAAAAQAEgKAHgFQAHgEALAAIAFAAIAFABIAAAcIgHgBIgGgBQgKAAgFADQgFACgDAFQgCAEAAAHIgBANIAAAqg");
	this.shape_27.setTransform(124.25,17.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B3785").s().p("AgeAxQgHgEgEgHQgEgGgCgJQgBgJAAgKIAAg3IAfAAIAAAyIABAIIACAJQABAEADACQAEADAGAAQAFAAAEgDQADgCACgEIADgIIABgJIAAgyIAfAAIAABlIgeAAIAAgOIgFAGIgGAFIgIAEQgFABgFAAQgMAAgIgDg");
	this.shape_28.setTransform(113.425,18.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2B3785").s().p("AgVAyQgLgEgHgHQgIgHgEgKQgFgKAAgMQAAgLAFgKQAEgKAIgHQAHgHALgEQAKgEALAAQAMAAAKAEQAKAEAIAHQAIAHAEAKQAFAKAAALQAAAMgFAKQgEAKgIAHQgIAHgKAEQgKAEgMgBQgLABgKgEgAgSgSQgGAIAAAKQAAAMAGAGQAHAIALAAQAMAAAGgIQAHgGAAgMQAAgKgHgIQgGgHgMAAQgLAAgHAHg");
	this.shape_29.setTransform(100.925,17.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2B3785").s().p("Ag2BIIAEgZQAHADAIAAIAIgBIAGgEIAEgFIADgHIACgGIgthmIAiAAIAaBDIAAAAIAXhDIAgAAIguB1IgGAPQgDAGgEAEQgEAFgHACQgHACgMAAQgMAAgLgEg");
	this.shape_30.setTransform(88.575,20.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2B3785").s().p("AADBCQgGgCgFgDQgFgEgCgGQgDgGAAgIIAAgwIgVAAIAAgZIAVAAIAAgfIAeAAIAAAfIAcAAIAAAZIgcAAIAAAhIABAIQAAADACADQABADADAAQADACAFAAIAHgBQAEAAACgCIAAAaIgLADIgLAAQgIAAgHgBg");
	this.shape_31.setTransform(71.925,16.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2B3785").s().p("AgLAyQgLgEgHgHQgHgHgFgKQgFgKAAgMQAAgLAFgKQAFgKAHgHQAHgHALgEQALgEAKAAQAJABAKADQAKADAIAHIgWAWQgBgDgFgCQgEgDgFAAQgLAAgGAHQgHAIAAAKQAAAMAHAGQAGAIALAAQAGAAADgCIAGgGIAWAWQgIAIgKACQgKADgJAAQgKABgLgEg");
	this.shape_32.setTransform(63.1,17.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2B3785").s().p("AgRAyQgKgEgIgHQgHgHgFgKQgEgKAAgMQAAgLAEgKQAFgKAHgHQAIgHAKgEQALgEAKAAQALAAAJAEQAJAEAGAHQAHAHADAKQADAKAAALIAAAKIhIAAQACAJAGAFQAHAGAIAAQAIAAAFgEQAFgDAEgGIAXAQQgIAKgMAFQgLAGgNgBQgKABgLgEgAgHgcIgHAEIgEAGQgCAEAAADIApAAQAAgHgFgGQgGgGgJAAQgEAAgEACg");
	this.shape_33.setTransform(51.525,17.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2B3785").s().p("AADBCQgGgCgFgDQgFgEgCgGQgDgGAAgIIAAgwIgVAAIAAgZIAVAAIAAgfIAeAAIAAAfIAcAAIAAAZIgcAAIAAAhIABAIQAAADACADQABADADAAQADACAFAAIAHgBQAEAAACgCIAAAaIgLADIgLAAQgIAAgHgBg");
	this.shape_34.setTransform(40.975,16.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2B3785").s().p("AgVAyQgLgEgHgHQgIgHgEgKQgFgKAAgMQAAgLAFgKQAEgKAIgHQAHgHALgEQAKgEALAAQAMAAAKAEQAKAEAIAHQAIAHAEAKQAFAKAAALQAAAMgFAKQgEAKgIAHQgIAHgKAEQgKAEgMgBQgLABgKgEgAgSgSQgGAIAAAKQAAAMAGAGQAHAIALAAQAMAAAGgIQAHgGAAgMQAAgKgHgIQgGgHgMAAQgLAAgHAHg");
	this.shape_35.setTransform(30.425,17.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2B3785").s().p("AgjA0IAAhlIAfAAIAAARIABAAQAEgKAHgFQAHgEALAAIAFAAIAFABIAAAcIgHgBIgHgBQgIAAgFADQgGACgDAFQgBAEgCAHIgBANIAAAqg");
	this.shape_36.setTransform(20.1,17.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2B3785").s().p("Ag3BKIAAiTIA3AAQALAAAKACQAKACAIAFQAIAFAEAJQAFAIAAAOQAAANgFAJQgEAHgHAGQgHAFgLACQgKACgLAAIgXAAIAAA6gAgWgKIAWAAIAHgBIAHgDQAEgCACgEQACgDAAgFQAAgGgDgDQgDgEgEgCQgEgCgFAAIgIgBIgRAAg");
	this.shape_37.setTransform(9.2,15.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_02, new cjs.Rectangle(0,0,245.5,55.4), null);


(lib.copy_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AiMCcIAAk3IB7AAQAeAAAcAKQAdAJAWATQAWAUANAdQANAdAAAnQABAogPAdQgQAegYATQgYATgdAJQgdAKgbAAgAhVBqIAqAAQAaAAAWgGQAXgGASgNQAQgMALgUQAJgUABgdQgBgbgIgUQgKgVgPgMQgQgNgVgGQgUgGgaAAIgzAAg");
	this.shape.setTransform(152.65,19.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AhdCcIAAk3IA3AAIAAEFICEAAIAAAyg");
	this.shape_1.setTransform(125.175,19.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AhCCYQgegMgWgVQgVgVgNgeQgMgeAAglQAAgkAMgfQANgeAVgWQAWgVAegMQAegMAkAAQAkAAAeALQAeALAXAWQAWAVAMAfQAMAeAAAlQAAAkgMAeQgMAegWAWQgXAVgeAMQgeAMgkABQgkAAgegMgAgrhoQgUAJgOAPQgOAPgHAUQgIAUAAAYQAAAYAIAVQAHAVAOAQQAOAPAUAJQAUAIAXAAQAYAAAUgIQAUgJAOgPQAOgQAHgVQAIgVAAgYQAAgYgIgUQgHgUgOgPQgOgPgUgJQgUgIgYAAQgXAAgUAIg");
	this.shape_2.setTransform(93.975,19.424);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgpCYQgfgMgVgVQgWgVgMgeQgNgeAAglQAAgkANgfQAMgeAWgWQAVgVAfgMQAegMAjAAQAfAAAcALQAbAMAYAbIgsAfQgRgSgQgGQgQgGgRAAQgXAAgTAIQgUAJgOAPQgOAPgIAUQgHAUAAAYQAAAYAHAVQAIAVAOAQQAOAPAUAJQATAIAXAAQATAAATgJQARgIAPgUIAuAgQgVAdgeANQgfAOgiAAQgjAAgegMg");
	this.shape_3.setTransform(61.4,19.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("Ag9CaQgbgKgTgXIAqgoQAKAPARAJQAQAIATAAQAIAAAKgCQAJgDAJgFQAHgFAFgIQAFgJAAgKQAAgRgLgKQgLgJgQgGIgigMQgUgGgQgKQgRgJgKgQQgMgRAAgcQAAgYAKgRQAKgSAQgMQAQgLAVgGQAUgGAVAAQAZAAAXAIQAXAHASASIgoAqQgJgNgOgGQgPgFgRAAIgSACQgIACgHAFQgIAFgFAHQgDAIAAALQgBAPALAJQAMAIAQAGIAiAMQATAGARAKQARAJAKARQALARAAAbQAAAZgJATQgKATgPAMQgPAMgWAGQgUAHgVAAQgeAAgbgKg");
	this.shape_4.setTransform(21.75,19.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgpA6IAehzIA1AAIglBzg");
	this.shape_5.setTransform(3.125,9.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgbCcIAAkFIhfAAIAAgyID1AAIAAAyIhfAAIAAEFg");
	this.shape_6.setTransform(-16.025,19.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgbCcIAAk3IA3AAIAAE3g");
	this.shape_7.setTransform(-34.725,19.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_01, new cjs.Rectangle(-42.9,-11,213.5,64.1), null);


(lib.click = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#044F04").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.btn_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AARAkIgRgwIgPAwIgSAAIgZhHIATAAIAQAyIAAAAIAPgyIASAAIAQAyIAAAAIAPgyIASAAIgYBHg");
	this.shape.setTransform(87.025,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAjQgIgDgFgFQgFgFgDgGQgDgIAAgIQAAgHADgIQADgHAFgFQAFgEAIgDQAHgDAHAAQAIAAAHADQAIADAFAEQAFAFADAHQADAIAAAHQAAAIgDAIQgDAGgFAFQgFAFgIADQgHADgIAAQgHAAgHgDgAgIgTIgHAFIgEAHIgBAHIABAIIAEAHIAHAFQAEACAEAAQAFAAAEgCIAHgFIAEgHIABgIIgBgHIgEgHIgHgFQgEgCgFABQgEgBgEACg");
	this.shape_1.setTransform(76.475,20.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAYA1Ig0hRIAABRIgTAAIAAhpIAZAAIAzBNIAAhNIATAAIAABpg");
	this.shape_2.setTransform(65.975,19.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgkA0IADgQIAEABIAFABIAFgBIAEgCIACgDIADgFIADgJIgfhHIAUAAIAUAyIASgyIATAAIgiBXIgFAJIgEAGQgDACgFABQgEACgGAAQgHAAgHgCg");
	this.shape_3.setTransform(51.75,22.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAiQgFgCgDgEQgDgEgBgFQgCgFAAgGIAAgsIASAAIAAAkIABAGIABAHQACADACACQADACAEABQAEAAADgCIAFgEIADgGIABgGIAAgnIASAAIAABHIgRAAIAAgLIgBAAQgCAFgGAEQgFAEgHAAQgIAAgFgDg");
	this.shape_4.setTransform(43.55,20.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmA1IAAhpIAoAAIAMABQAGABAEAEQAFADADAFQADAGAAAGQAAAKgGAGQgFAFgIADQAFABAEABQAFACADAEQADADABAEQACAFAAAFQAAAIgDAGQgEAGgFADQgGAEgHABIgOACgAgTAlIARAAIAHgBIAHgCQAEgBACgDQACgDAAgGQAAgIgFgEQgGgDgKAAIgSAAgAgTgJIARAAQAIAAAFgDQAFgFAAgFQAAgIgFgCQgFgEgKAAIgPAAg");
	this.shape_5.setTransform(34.675,19.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DA3F55").s().p("AphDNIAAmZITDAAIAAGZg");
	this.shape_6.setTransform(61,20.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_cta, new cjs.Rectangle(0,0,122,41), null);


(lib.bg_lightblue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7E6F4").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_lightblue, new cjs.Rectangle(0,0,300,250), null);


(lib.bg_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AoHTiMAAAgnDIQPAAMAAAAnDg");
	this.shape.setTransform(52,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_blue, new cjs.Rectangle(0,0,104,250), null);


(lib.spray_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray("synched",0);
	this.instance.setTransform(12.1,44,0.1793,0.1594,0,0,0,12,43.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:12.1,regY:44,scaleX:1,scaleY:1},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,88.1);


(lib.hand_spray_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hand_spray_png
	this.instance = new lib.hand_spray();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(31).to({_off:true},1).wait(6).to({_off:false},0).wait(9).to({_off:true},1).wait(28));

	// spray_01_png
	this.instance_1 = new lib.spray_anim("synched",0);
	this.instance_1.setTransform(130.65,21.15,1,0.3428,0,0,0,72.7,44.1);
	this.instance_1.alpha = 0.5781;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(30).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(9).to({startPosition:1},0).to({_off:true},1).wait(28));

	// spray_01_png
	this.instance_2 = new lib.spray_anim("synched",0);
	this.instance_2.setTransform(134.65,21.15,1.0533,1.2976,0,0,0,72.8,44);
	this.instance_2.alpha = 0.5781;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).wait(29).to({startPosition:2},0).to({_off:true},1).wait(6).to({_off:false,startPosition:0},0).wait(9).to({startPosition:0},0).to({_off:true},1).wait(28));

	// spray_01_png
	this.instance_3 = new lib.spray_anim("synched",0);
	this.instance_3.setTransform(130.65,21.15,1,1,0,0,0,72.7,44.1);
	this.instance_3.alpha = 0.5781;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(27).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(9).to({startPosition:1},0).to({_off:true},1).wait(28));

	// spray_01_png
	this.instance_4 = new lib.spray_anim("synched",0);
	this.instance_4.setTransform(130.65,21.15,1,1,0,0,0,72.7,44.1);
	this.instance_4.alpha = 0.5781;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).wait(30).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(9).to({startPosition:1},0).to({_off:true},1).wait(28));

	// Layer_8
	this.instance_5 = new lib.spray_mist("synched",0);
	this.instance_5.setTransform(154.3,26.8,0.5267,0.5267,0,0,0,150,150.1);
	this.instance_5.alpha = 0.3398;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).wait(27).to({startPosition:1},0).to({_off:true},1).wait(6).to({_off:false,startPosition:0},0).wait(9).to({startPosition:1},0).to({_off:true},1).wait(28));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-70.7,245.4,242.7);


(lib.germs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_18 = new cjs.Graphics().p("AREDYIgNgFQgIgDgEgDQgEgDADgLIgNgZQgKgTANAIQANAIAHgDQAGgDgJgUQgJgUAKgEQAJgEAJAFQAFACABAQQAIgKAHAFQAKAJADAIQAGANgGAAIgGgBQAAAAgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAIAJAKIAMALQADAHgBAGQgBAGgFADQgFADgGgCIgEgBIgDgBQgGgGgCABQgCABAAAFIABAIQAAAFgBABIgHADIgCAAIgGgBg");
	var mask_graphics_19 = new cjs.Graphics().p("AQgDxIgdgGQgRgEgIgFQgJgFAKgYQgIgMgRgjQgRgjAcAMQAcAMAQgIQAQgIgQgmQgQgmAXgKQAXgJAUAGQAJAEgBAfQAXgVAMAIQAXAPAFAPQAJAZgOACIgMAAQgGAAAAACQgBABAUAQQAWARACAEQAHAMgEANQgEANgNAHQgMAIgOgDIgKgCIgGgBQgNgJgFACQgEACAAAJIAAARQgBAKgEACQgLAHgGABIgIABIgKgBg");
	var mask_graphics_20 = new cjs.Graphics().p("AP8EKIgsgIQgagFgNgHQgNgHAQglQgLgQgYg0QgZg0ArARQArAQAZgMQAZgMgWg5QgXg3AkgPQAkgQAfAJQAOAEgDAuQAjggAUAMQAiAVAIAWQAMAlgWADIgSABQgKAAgBADQAAABAeAXQAgAYAEAGQAKARgIAUQgHAUgTAMQgUALgVgEIgPgCIgJgBQgUgNgIADQgGADgBAOIgBAZQgCAPgGAEQgSAKgJADQgHACgIAAIgOgBg");
	var mask_graphics_21 = new cjs.Graphics().p("APaEiIg8gKQgjgGgRgJQgSgJAWgwQgNgWgghEQgghEA5AVQA6AVAigRQAigRgdhIQgehKAxgWQAxgWAqAMQASAFgFA+QAxgsAaAQQAuAbAKAdQAQAvgfAGIgYABQgNAAgBAEQgBACAoAeQArAfAFAIQANAWgKAbQgKAagbAQQgbAPgcgFIgUgCIgNgBQgagRgLAFQgIAEgCASIgCAiQgCATgJAFQgZAPgMADQgKADgMAAIgQgBg");
	var mask_graphics_22 = new cjs.Graphics().p("AO3E6IhKgMQgsgGgWgLQgWgLAdg8QgRgcgnhTQgohVBIAaQBIAZArgVQArgWgkhaQgjhbA9gbQA+gcA0AOQAXAGgHBNQA+g3AgATQA6AhALAkQAUA8gmAHIgfACQgQAAgCAFQgBACAzAkQA1AmAGAKQAPAbgNAhQgMAhgiAUQgiATgjgFIgagCIgQgDQgggUgOAHQgLAEgCAXIgDAqQgDAYgLAHQgfARgQAFQgNAEgPAAQgJAAgLgBg");
	var mask_graphics_23 = new cjs.Graphics().p("AOWFRIhagNQg0gHgagNQgbgNAjhIQgUggguhkQgvhjBWAdQBWAdA0gZQAzgZgqhsQgqhsBKghQBKgiA/AQQAcAHgJBcQBKhCAnAWQBFAnANArQAXBHgtAJQgHABgeABQgTAAgDAHQgBACA8ArQBAAsAHAMQASAggPAoQgQAogoAXQgpAXgqgGIgfgCQgSgCgCgBQgmgXgRAHQgMAGgEAbIgEAyQgDAcgOAIQglAWgTAGQgQAFgSAAQgLAAgMgCg");
	var mask_graphics_24 = new cjs.Graphics().p("AN0FoIhogOQg8gJgfgOQgfgPAqhUQgYglg1hzQg2hyBlAiQBjAgA8gdQA9gegxh9Qgwh9BWgmQBXgnBJASQAgAIgLBqQBXhNAtAaQBPAsAQAyQAaBSg1ALQgIABgiABQgXABgDAHQgBADBFAxQBKAzAIAOQAWAlgTAuQgSAugvAbQgwAcgxgHIgkgDQgUgCgCgBQgtgbgTAJQgPAGgEAgIgFA6QgEAhgQAJQgsAZgWAHQgTAGgWAAQgMAAgOgCg");
	var mask_graphics_25 = new cjs.Graphics().p("ANUGSIh3gQQhEgJgjgRQgjgQAvhfQgagqg9iCQg8iBByAlQBxAkBFggQBEgjg2iNQg3iNBjgsQBigtBTAUQAlAJgNB4QBjhXAzAdQBbAyARA4QAeBdg9AMQgJACgnACQgaAAgDAJQgCADBPA3QBUA6AJAQQAYApgVA1QgVA0g2AfQg2Afg4gIIgogDQgYgBgCgBQgzgfgWAKQgRAHgFAkQgDAsgCAWQgFAlgTALQgxAcgZAIQgWAHgZAAQgOAAgPgCg");
	var mask_graphics_26 = new cjs.Graphics().p("AM0HBIiFgRQhNgLgmgSQgogTA2hpQgegvhDiRQhDiQB/ApQB/ApBNglQBMgng8idQg9ieBvgxQBugyBdAWQApAKgPCGQBvhiA6AgQBkA4AUA+QAhBohEAOQgKACgsACQgdAAgEAKQgBADBYA+QBeBAAKASQAbAugYA7QgYA6g8AjQg9Ajg/gJIgtgDQgagCgDgBQg4gigZALQgTAJgGAoQgDAxgDAYQgGApgVAMQg3AggcAJQgZAIgcAAQgQAAgQgCg");
	var mask_graphics_27 = new cjs.Graphics().p("AMUHvIiSgTQhVgLgrgUQgrgUA7h1QghgzhJigQhKifCMAtQCMAtBVgpQBVgrhCitQhDiuB6g2QB6g4BnAYQAtALgRCUQB7hsBAAjQBvA+AVBEQAkBzhLAPQgLACgwACQggABgFAKQgBAEBhBEQBnBGAMAUQAdAzgaBAQgbBBhDAmQhDAnhFgJIgygEQgdgBgDgCQg+glgbAMQgWAJgGAtQgEA2gDAaQgGAugXANQg+AkgfAJQgbAJggAAQgRAAgSgCg");
	var mask_graphics_28 = new cjs.Graphics().p("AL1IcIiggUQhcgMgvgWQgvgWBAiAQgjg3hQiuQhRiuCaAyQCZAwBcgtQBdgvhIi9QhIi9CFg8QCGg9BwAaQAxAMgTChQCHh1BFAmQB6BDAXBKQAnB9hSARQgMACg1ADQgjAAgFAMQgBAEBqBKQBxBNAMAVQAgA4gdBGQgdBGhJAqQhKArhLgKIg3gEQgfgCgEgCQhDgogeANQgYALgGAwQgFA7gEAcQgHAzgZAOQhDAngiALQgeAJgjAAQgSAAgUgCg");
	var mask_graphics_29 = new cjs.Graphics().p("ALXJIIitgVQhlgNgygYQg0gXBHiKQgng9hWi8QhXi7CmA1QCmA0BkgxQBlgzhOjMQhOjNCRhBQCQhCB6AdQA1AMgUCuQCSh/BLApQCDBIAZBRQArCHhZASQgNADg6ACQglABgGANQgCAEB0BQQB6BTANAXQAjA8ggBMQggBMhPAuQhQAuhRgLIg8gEQgigCgEgBQhJgsggAOQgaAMgHA0QgFBAgEAeQgIA3gbAQQhJAqglALQghALgmAAQgTAAgVgDg");
	var mask_graphics_30 = new cjs.Graphics().p("AK5J0Ii6gXQhsgOg3gZQg3gaBMiUQgphBhdjKQhejJCzA5QCzA3Bsg0QBtg3hUjbQhUjcCchGQCbhHCDAeQA5AOgWC7QCeiJBQAsQCOBNAaBXQAuCRhgAUQgOACg+ADQgoABgGAOQgCAFB8BVQCDBZAOAZQAlBAgiBSQgiBShVAxQhWAxhYgLIhAgEQgkgCgEgCQhPgvgjAQQgcAMgIA4QgFBFgEAhQgJA6gdARQhPAugnAMQgkAMgpAAQgVAAgWgDg");
	var mask_graphics_31 = new cjs.Graphics().p("AKcKeIjHgYQh0gOg6gbQg7gbBSifQgshFhkjXQhjjXC/A8QC/A7Bzg4QB0g6hZjqQhZjrCmhLQCnhMCMAgQA9AOgYDIQCpiSBVAvQCYBSAcBdQAwCbhmAUQgPADhCAEQgrABgHAOQgCAFCEBcQCMBeAQAbQAoBFglBXQglBXhbA1QhcA1hegMIhEgEQgngCgEgDQhVgyglARQgdANgJA8QgGBJgEAkQgJA+ggASQhUAxgqANQgmAMgtAAQgWAAgXgDg");
	var mask_graphics_32 = new cjs.Graphics().p("AJ/LIIjUgZQh6gPg+gdQg/gdBXioQgvhKhpjkQhqjlDLBAQDLA/B7g8QB8g+hfj4Qhfj6CxhPQCyhRCUAiQBBAPgaDUQC0ibBbAxQChBXAeBjQA0CkhtAWQgQAEhHADQguACgHAPQgCAFCNBhQCVBlAQAbQAqBKgnBcQgnBdhhA4QhiA5hjgNIhJgEQgqgDgEgCQhag1goASQgfAOgJA/QgGBOgFAmQgKBCghATQhaA0gtAOQgoANgwAAQgXAAgZgDg");
	var mask_graphics_33 = new cjs.Graphics().p("AJjLxIjggaQiCgRhBgdQhDgfBciyQgxhOhvjyQhvjxDWBEQDWBCCDhAQCDhBhkkHQhkkIC7hUQC8hWCdAkQBEAQgbDgQC/ikBgA0QCqBcAgBoQA2CuhzAYQgRADhKAEQgxABgHAQQgDAGCVBnQCdBqARAdQAtBOgpBiQgqBihmA7QhoA8hpgNIhNgFQgsgCgFgDQhfg4gqATQghAPgKBDQgGBSgGAoQgKBGgjAVQhfA2gwAQQgrAOgyAAQgZAAgagEg");
	var mask_graphics_34 = new cjs.Graphics().p("AJIMaIjtgcQiIgRhGggQhFggBhi8Qg0hRh1j/Qh1j+DiBHQDiBFCJhDQCKhFhpkVQhpkVDFhZQDGhaCmAlQBIARgdDsQDJitBmA3QCzBhAhBtQA5C3h5AZQgSAEhOAEQg0ACgIAQQgCAGCdBsQClBwASAfQAwBSgsBnQgsBnhsA/QhtA/hwgOIhRgFQgugCgFgDQhkg7gtAUQgiAQgKBGQgIBXgFAqQgLBKglAVQhkA6gzAQQgtAPg1AAQgaAAgbgDg");
	var mask_graphics_35 = new cjs.Graphics().p("AItNBIj5gdQiPgShJghQhJgiBmjFQg3hVh5kLQh8kLDtBKQDuBJCQhGQCRhJhukjQhvkjDQhdQDQhfCuAnQBMASgfD4QDTi2BrA6QC8BlAjBzQA8DAiAAaQgSAEhTAEQg2ACgIARQgDAHClBxQCuB1ATAhQAxBWguBsQguBshxBCQhzBCh1gOIhVgFQgxgDgFgCQhpg+gvAVQgkAQgLBKQgIBbgGAsQgLBOgnAWQhpA9g1ARQgwAPg4AAQgbAAgcgDg");
	var mask_graphics_36 = new cjs.Graphics().p("AISNnIkEgeQiWgShMgjQhLgjBqjOQg6hah/kXQiBkXD4BOQD4BMCYhKQCXhNhzkvQhzkxDZhhQDahkC2ApQBPASggEEQDdi/BwA9QDFBqAkB4QA/DJiGAbQgTAEhWAFQg5ACgJASQgCAHCsB2QC2B6AUAiQA0BagxByQgwBxh3BFQh4BFh6gPQgYgChCgDQgygDgGgDQhuhAgxAWQgmARgLBOQgIBfgHAuQgMBRgpAYQhuA/g3ASQgyAQg7AAQgcAAgegEg");
	var mask_graphics_37 = new cjs.Graphics().p("AH4ONIkPgfQidgThOgkQhQglBvjXQg7heiGkjQiGkjEEBRQECBPCehNQCehQh4k8Qh4k+DjhmQDjhoC/AqQBSATgiEPQDnjHB1A/QDNBvAmB9QBBDSiLAdQgUAEhaAFQg7ABgJAUQgDAHCzB7QC/CAAUAjQA2BegyB2QgzB2h8BIQh9BJiAgQQgYgChFgDQg1gDgGgDQhzhDgzAXQgoARgMBRQgIBkgHAwQgMBUgrAZQhzBDg6ASQg0ARg+AAQgdAAgfgEg");
	var mask_graphics_38 = new cjs.Graphics().p("AHfOyIkaghQikgThRgmQhTgmB0jgQg+hhiLkvQiMkvEOBUQENBTClhRQClhTh9lJQh9lLDshqQDthtDGAtQBWAUgjEaQDwjQB5BCQDWBzAoCCQBEDaiRAeQgWAFheAFQg9ACgJATQgDAIC7CAQDGCFAVAlQA4Bhg0B7Qg1B7iBBLQiDBMiFgRQgZgChIgDQg3gDgGgDQh4hGg1AYQgpATgNBUQgIBngHAyQgNBYgtAaQh3BFg9ATQg2AShBAAQgeAAgggEg");
	var mask_graphics_39 = new cjs.Graphics().p("AHGPWIklgiQiogUhWgnQhWgnB5jpQhBhliQk6QiSk7EZBXQEYBWCqhUQCshWiClWQiClXD2huQD2hxDOAuQBZAVglEkQD6jXB+BEQDeB3ApCHQBGDjiWAfQgWAFhiAFQhAACgJAVQgEAHDCCFQDOCKAWAmQA6Blg2CAQg3CAiGBOQiIBOiKgRQgagChLgDQg5gDgGgDQh8hJg3AZQgsATgMBYQgJBrgIA0QgNBbgvAbQh8BIg/AUQg4AShDAAQgfAAgigEg");
	var mask_graphics_40 = new cjs.Graphics().p("AGeP6IkwgjQivgWhZgoQhZgpB9jwQhChpiWlGQiWlGEjBbQEhBYCxhWQCyhaiGliQiHljD/hzQD+h0DWAvQBcAVgmEwQEDjfCDBGQDmB7AqCMQBJDricAgQgXAFhlAFQhCACgKAWQgEAIDJCJQDVCPAXAoQA9Bpg5CEQg4CEiMBRQiNBRiOgRQgcgChNgEQg7gDgHgDQiAhLg5AaQgtATgOBbQgJBvgIA2QgOBfgwAbQiABLhBAUQg7AUhGAAQggAAgigEg");
	var mask_graphics_99 = new cjs.Graphics().p("AGeP6IkwgjQivgWhZgoQhZgpB9jwQhChpiWlGQiWlGEjBbQEhBYCxhWQCyhaiGliQiHljD/hzQD+h0DWAvQBcAVgmEwQEDjfCDBGQDmB7AqCMQBJDricAgQgXAFhlAFQhCACgKAWQgEAIDJCJQDVCPAXAoQA9Bpg5CEQg4CEiMBRQiNBRiOgRQgcgChNgEQg7gDgHgDQiAhLg5AaQgtATgOBbQgJBvgIA2QgOBfgwAbQiABLhBAUQg7AUhGAAQggAAgigEg");
	var mask_graphics_110 = new cjs.Graphics().p("AGeP6IkwgjQivgWhZgoQhZgpB9jwQhChpiWlGQiWlGEjBbQEhBYCxhWQCyhaiGliQiHljD/hzQD+h0DWAvQBcAVgmEwQEDjfCDBGQDmB7AqCMQBJDricAgQgXAFhlAFQhCACgKAWQgEAIDJCJQDVCPAXAoQA9Bpg5CEQg4CEiMBRQiNBRiOgRQgcgChNgEQg7gDgHgDQiAhLg5AaQgtATgOBbQgJBvgIA2QgOBfgwAbQiABLhBAUQg7AUhGAAQggAAgigEg");
	var mask_graphics_144 = new cjs.Graphics().p("AGeP6IkwgjQivgWhZgoQhZgpB9jwQhChpiWlGQiWlGEjBbQEhBYCxhWQCyhaiGliQiHljD/hzQD+h0DWAvQBcAVgmEwQEDjfCDBGQDmB7AqCMQBJDricAgQgXAFhlAFQhCACgKAWQgEAIDJCJQDVCPAXAoQA9Bpg5CEQg4CEiMBRQiNBRiOgRQgcgChNgEQg7gDgHgDQiAhLg5AaQgtATgOBbQgJBvgIA2QgOBfgwAbQiABLhBAUQg7AUhGAAQggAAgigEg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_graphics_18,x:114.1416,y:21.7192}).wait(1).to({graphics:mask_graphics_19,x:117.8186,y:24.2207}).wait(1).to({graphics:mask_graphics_20,x:121.4446,y:26.6897}).wait(1).to({graphics:mask_graphics_21,x:125.0142,y:29.1213}).wait(1).to({graphics:mask_graphics_22,x:128.5266,y:31.5144}).wait(1).to({graphics:mask_graphics_23,x:131.9816,y:33.8685}).wait(1).to({graphics:mask_graphics_24,x:135.379,y:36.1835}).wait(1).to({graphics:mask_graphics_25,x:138.7189,y:36.5086}).wait(1).to({graphics:mask_graphics_26,x:142.0012,y:36.2879}).wait(1).to({graphics:mask_graphics_27,x:145.2259,y:36.0711}).wait(1).to({graphics:mask_graphics_28,x:148.393,y:35.8581}).wait(1).to({graphics:mask_graphics_29,x:151.5024,y:35.649}).wait(1).to({graphics:mask_graphics_30,x:154.5542,y:35.4438}).wait(1).to({graphics:mask_graphics_31,x:157.5484,y:35.2425}).wait(1).to({graphics:mask_graphics_32,x:160.4849,y:35.045}).wait(1).to({graphics:mask_graphics_33,x:163.3638,y:34.8514}).wait(1).to({graphics:mask_graphics_34,x:166.185,y:34.6617}).wait(1).to({graphics:mask_graphics_35,x:168.9486,y:34.4758}).wait(1).to({graphics:mask_graphics_36,x:171.6545,y:34.2939}).wait(1).to({graphics:mask_graphics_37,x:174.3028,y:34.1158}).wait(1).to({graphics:mask_graphics_38,x:176.8934,y:33.9416}).wait(1).to({graphics:mask_graphics_39,x:179.4264,y:33.7712}).wait(1).to({graphics:mask_graphics_40,x:180.2504,y:38.1563}).wait(59).to({graphics:mask_graphics_99,x:180.2504,y:38.1563}).wait(1).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_graphics_110,x:180.2504,y:38.1563}).wait(34).to({graphics:mask_graphics_144,x:180.2504,y:38.1563}).wait(1).to({graphics:null,x:0,y:0}).wait(45));

	// Layer_5
	this.instance = new lib.germs_group();
	this.instance.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({_off:false},0).wait(81).to({_off:true},1).wait(10).to({_off:false},0).wait(34).to({_off:true},1).wait(45));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_36 = new cjs.Graphics().p("AJANHQhpAEkwgWQkvgVC9iEQC+iEAKh9QAKh/k9gnQk+gnAXixQAXixB9hmQA3gtDOB2Qg2jWBrgyQC9hXB5AVQDMAigrBhQgGAOgnA6QgaAlALAMQAFAFC6hEQDFhHAnAAQBmAABKBJQBJBKAABmQAABohJBIIgxA4QgbAggGADQhtAugGAoQgEAfA9AlQBOAoAkAVQBAAnAAAjQAABfgMAqQgQA5g4A4IibCcQhaBbhEAkQgNAHgQAAQg/AAhkh1g");
	var mask_1_graphics_37 = new cjs.Graphics().p("AGyORQiSAFmlgbQmmgcEIipQEHioAPihQANiim5gyQm6gyAhjiQAfjkCuiDQBMg5EgCXQhLkSCUhAQEFhwCoAbQEbAsg7B8QgJASg2BKQgkAvAPAQQAHAGEDhWQERhcA2AAQCOAABmBeQBmBeAACDQAACFhmBeQgSASgxA2QgmAogIADQiYA8gIAzQgGAoBVAuQBsA0AzAbQBYAxAAAtQAAB6gRA2QgWBJhOBHIjXDJQh9BzhdAvQgTAJgWAAQhYAAiKiWg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AEsPXQi5AGoTghQoXghFOjMQFMjMATjCQARjDotg9Qovg8AqkQQAnkTDcifQBghEFsC2QhflLC8hNQFLiHDTAhQFlA1hKCVQgLAWhEBZQgvA5AUATQAIAHFIhoQFYhvBFAAQC0AACAByQCBByAACeQAACgiBByQgXAWg+BAQgwAxgJAEQjBBJgJA8QgIAwBrA4QCJA/A/AhQBwA7AAA2QAACTgWBBQgbBYhiBWQhzBlidCNQieCMh2A4QgYALgcAAQhvAAiui1g");
	var mask_1_graphics_39 = new cjs.Graphics().p("AE+RTQjdAGp7gmQp/gmGPjsQGNjtAXjhQAUjjqbhGQqchFAyk+QAvk/EHi4QBzhPGzDTQhxmADghZQGMieD+AnQGqA+hZCtQgNAZhSBnQg3BDAYAWQAJAIGIh5QGciABSAAQDXAACaCEQCaCDAAC4QAAC6iaCEQgcAZhKBLQg5A5gMAFQjmBUgLBIQgJA2CABBQCjBJBMAmQCGBFAAA/QAACqgaBMQghBmh1BkQiKB1i7CkQi+CiiNBBQgcANghAAQiFAAjRjSg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AFvTjQj/AHrdgrQrhgrHNkMQHKkLAaj/QAXkAsBhPQsDhOA6lnQA2loEwjQQCFhaH1DvQiDmyEDhlQHIixEmArQHrBGhnDDQgPAdheB1QhABLAcAZQAKAJHEiIQHciSBeAAQD4AACyCVQCyCVAADQQAADSiyCVQggAdhWBUQhCBAgNAGQkJBfgNBRQgLA9CUBKQC8BSBYArQCaBOAABHQAADAgeBWQgmBziHBxQifCFjYC4QjaC3ijBKQghAPgmAAQiaAAjwjtg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AGdVoQkfAIs4gwQs8gvIFkoQIDkoAdkaQAbkctghXQtihWBAmNQA9mPFVjmQCWhkIzEIQiTngEjhvQIBjFFJAwQIpBNh0DZQgRAfhqCBQhIBUAgAcQAMAKH7iXQIXihBpAAQEYAADHClQDICkAADnQAADojIClQgkAfhgBeQhLBHgOAGQkqBpgPBaQgMBECmBSQDUBbBjAvQCtBWAABPQAADVgiBfQgrB/iYB9QiyCTjzDMQj1DLi3BRQglAQgrAAQitAAkNkGg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AHHXkQk8AIuMgzQuRg0I6lDQI4lCAgkzQAdk1u4hfQu7heBImxQBCmzF5j6QCkhsJtEfQiioLFBh5QI1jWFrA0QJhBUiADsQgSAih1CNQhPBbAiAeQANALIwilQJNivB0AAQE0AADcC0QDcCzAAD7QAAD9jcCzQgoAjhqBmQhSBOgQAGQlJBzgQBhQgNBLC3BYQDpBkBtA0QC/BdAABWQAADoglBnQgwCLinCIQjECgkMDfQkODcjKBZQgpASgvAAQi+AAkpkeg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AHtZWQlWAJvag4Qveg4JrlaQJolbAilKQAglNwJhmQwMhlBNnRQBInUGZkOQCyh0KiE1QiwoyFciDQJljmGLA4QKUBbiKD9QgUAlh/CXQhWBiAmAhQAOALJfiwQJ/i9B/AAQFNAADvDBQDvDBAAEOQAAEQjvDBQgrAlhzBuQhZBTgSAHQlkB8gSBoQgOBRDGBfQD+BrB2A4QDPBkAABdQAAD5goBvQg0CVi2CTQjUCskjDvQkmDujaBfQgsATg0AAQjOAAlDkzg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AIRa+QlvAJwhg7Qwlg7KXlxQKUlxAllfQAilixThtQxWhsBTnvQBNnxG2kfQC/h8LSFJQi8pXF1iKQKRj1GmA7QLEBhiUENQgVAoiIChQhcBoAoAiQAPANKLi8QKsjJCIAAQFmAAEADOQEADNAAEfQAAEikADNQgvAoh7B0QhgBZgSAHQl+CEgTBvQgPBWDUBlQEQByB+A7QDeBrAABjQAAEIgrB3Qg3CfjDCbQjkC4k3D/Qk7D8jqBlQgvAVg3AAQjeAAlZlHg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AIxccQmGAKxgg/Qxlg+K/mFQK8mFAnlyQAkl2yWhyQyZhyBYoKQBSoNHQkuQDLiDL9FbQjHp3GLiSQK5kDHAA/QLvBmidEcQgXAqiQCpQhiBuArAlQAQANKyjHQLWjTCQAAQF7AAEQDYQEPDZAAEvQAAExkPDZQgxApiDB7QhmBegTAIQmWCKgTB2QgRBaDiBrQEgB4CGA/QDrBwAABoQAAEXguB+Qg6CnjOCkQjyDBlLENQlNEKj5BrQgyAVg6AAQjrAAlulYg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AJNdwQmZALyahCQyehBLjmXQLgmXApmEQAmmGzSh4QzWh3BdoiQBWolHok9QDViIMlFrQjSqVGgiZQLckOHXBBQMVBrilEpQgYAsiXCyQhnByAsAmQASAOLVjPQL7jeCXAAQGPAAEdDjQEdDjAAE8QAAFAkdDiQg0AsiJCAQhrBjgUAIQmqCRgVB6QgRBfDtBwQEuB9CNBCQD4B1AABuQAAEkgwCDQg+CvjZCsQj+DKlbEZQlfEWkFBwQg1AWg9AAQj2ABmClpg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AJme6QmqALzMhEQzRhEMCmnQL/mmArmTQAomW0Hh9Q0Kh7Bgo4QBao6H9lJQDeiONHF6QjbqvGyifQL7kZHrBFQM4BuisE1QgZAuieC4QhsB3AvAoQASAOL0jXQMcjmCeAAQGfAAEqDrQEpDsAAFJQAAFMkpDrQg2AtiPCGQhvBmgWAIQm8CXgWB/QgSBjD4B0QE7CCCTBFQECB5AAByQAAEvgyCJQhBC1jiCzQkJDSlqEkQltEhkRB1Qg3AXhAAAQkBAAmSl3g");
	var mask_1_graphics_48 = new cjs.Graphics().p("AJ8f6Qm5AMz4hGQz9hHMem0QMam0AtmgQAomj00iBQ04iABkpKQBdpMIPlUQDmiTNkGGQjirFHBikQMXkiH8BGQNVBziyE/QgaAvikC+QhvB7AwApQATAPMPjfQM4jtCjAAQGvAAE0DzQE0DzAAFUQAAFXk0DzQg4AviUCJQhzBqgWAIQnNCcgWCDQgTBmEBB4QFGCHCYBGQEMB+AAB1QAAE6g0CMQhDC8jqC4QkTDZl3EuQl6EqkaB4Qg5AYhCAAQkKAAmhmDg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAKPAgxQnHAM0dhJQ0ihIM1nAQMynAAumrQAqmu1ciEQ1fiDBnpaQBgpcIeldQDtiWN+GQQjprYHOioQMukqILBIQNuB1i4FIQgbAwioDEQhyB+AxAqQAUAPMmjkQNQj0CoAAQG7AAE9D6QE9D5AAFdQAAFgk9D5Qg6AwiYCOQh3BsgXAJQnZCfgXCIQgTBoEHB7QFQCLCdBIQETCBAAB4QAAFCg2CQQhEDBjxC9QkbDfmBE2QmGEykiB8Qg7AYhEAAQkSAAmsmNg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAKeAhdQnRAM08hJQ1AhKNInKQNFnJAvm0QArm317iHQ1/iGBppnQBippIrlkQDyiaOTGZQjvrnHZisQNBkwIXBJQOCB4i8FPQgbAxisDIQh1CBAyArQAUAPM5jpQNjj5CsAAQHFAAFFD/QFED/AAFkQAAFnlED/Qg7AxicCQQh5BvgYAJQnkCjgYCKQgTBrENB9QFYCOCgBJQEaCEAAB7QAAFJg3CTQhGDFj2DBQkiDkmKE8QmPE5kpB+Qg8AZhFAAQkZAAm2mWg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAKqAiAQnZAM1ThLQ1YhKNXnRQNTnRAvm8QAsm+2UiJQ2XiIBrpwQBkp0I0lqQD3icOiGfQjyrzHhivQNPk0IhBKQORB6i+FUQgcAyivDLQh4CDA0AsQAUAPNHjtQNzj9CvAAQHNAAFKEDQFKEDAAFqQAAFulKEDQg7AxifCTQh8BwgYAKQntClgYCNQgTBsESCAQFeCPCjBLQEeCGAAB9QAAFOg3CWQhIDIj6DEQknDnmRFCQmWE+kuCAQg9AZhHAAQkdAAm+mcg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAKyAiZQnfAM1khMQ1phLNinXQNdnWAxnAQAsnD2liLQ2piKBsp3QBlp7I8luQD5idOuGjQj1r7HnixQNZk5IoBMQOdB7jCFYQgcAzixDNQh5CEA1AtQAUAPNRjvQN+kACxAAQHTAAFOEGQFOEGAAFuQAAFxlOEGQg8AzihCUQh9BygYAJQnzCngYCOQgVBuEWCBQFiCRClBMQEiCIAAB+QAAFSg4CXQhIDKj+DHQkqDqmXFFQmaFBkyCCQg+AahIAAQkgAAnEmhg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAK3AinQniAN1uhMQ1zhMNonaQNjnZAxnDQAtnH2wiMQ20iKBtp8QBmp+JAlxQD7ifO1GnQj3sBHqiyQNgk7IsBNQOjB7jCFbQgdAziyDOQh6CGA1AsQAUAQNYjxQOEkCCzAAQHWAAFREIQFQEIAAFwQAAF0lQEIQg9AyiiCWQh+BygYAKQn3CogZCPQgUBuEYCDQFlCSCmBMQEkCJAAB/QAAFUg5CYQhJDLj/DJQksDrmaFHQmeFEk0CCQg+AahIAAQkjAAnHmkg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAK5AisQnkAN1xhMQ13hNNqnaQNmnbAxnEQAtnH2ziMQ24iLBup9QBlqAJClyQD8ifO3GnQj4sCHsiyQNik8ItBNQOmB8jDFbQgdAzizDPQh6CGA1AsQAUAQNajyQOHkCCyAAQHYAAFREJQFSEIAAFxQAAF1lSEIQg9AziiCWQh+BygZAKQn4CpgYCPQgUBuEYCDQFmCSCnBNQEkCJAAB/QAAFVg5CZQhJDMkADIQktDsmaFIQmfFFk1CCQg+AahJAAQkjAAnImlg");
	var mask_1_graphics_99 = new cjs.Graphics().p("EAK5AisQnkAN1xhMQ13hNNqnaQNmnbAxnEQAtnH2ziMQ24iLBup9QBlqAJClyQD8ifO3GnQj4sCHsiyQNik8ItBNQOmB8jDFbQgdAzizDPQh6CGA1AsQAUAQNajyQOHkCCyAAQHYAAFREJQFSEIAAFxQAAF1lSEIQg9AziiCWQh+BygZAKQn4CpgYCPQgUBuEYCDQFmCSCnBNQEkCJAAB/QAAFVg5CZQhJDMkADIQktDsmaFIQmfFFk1CCQg+AahJAAQkjAAnImlg");
	var mask_1_graphics_110 = new cjs.Graphics().p("EAK5AisQnkAN1xhMQ13hNNqnaQNmnbAxnEQAtnH2ziMQ24iLBup9QBlqAJClyQD8ifO3GnQj4sCHsiyQNik8ItBNQOmB8jDFbQgdAzizDPQh6CGA1AsQAUAQNajyQOHkCCyAAQHYAAFREJQFSEIAAFxQAAF1lSEIQg9AziiCWQh+BygZAKQn4CpgYCPQgUBuEYCDQFmCSCnBNQEkCJAAB/QAAFVg5CZQhJDMkADIQktDsmaFIQmfFFk1CCQg+AahJAAQkjAAnImlg");
	var mask_1_graphics_144 = new cjs.Graphics().p("EAK5AisQnkAN1xhMQ13hNNqnaQNmnbAxnEQAtnH2ziMQ24iLBup9QBlqAJClyQD8ifO3GnQj4sCHsiyQNik8ItBNQOmB8jDFbQgdAzizDPQh6CGA1AsQAUAQNajyQOHkCCyAAQHYAAFREJQFSEIAAFxQAAF1lSEIQg9AziiCWQh+BygZAKQn4CpgYCPQgUBuEYCDQFmCSCnBNQEkCJAAB/QAAFVg5CZQhJDMkADIQktDsmaFIQmfFFk1CCQg+AahJAAQkjAAnImlg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(36).to({graphics:mask_1_graphics_36,x:120.0305,y:95.6025}).wait(1).to({graphics:mask_1_graphics_37,x:130.0165,y:106.3038}).wait(1).to({graphics:mask_1_graphics_38,x:139.4319,y:116.3936}).wait(1).to({graphics:mask_1_graphics_39,x:133.8185,y:120.0589}).wait(1).to({graphics:mask_1_graphics_40,x:125.421,y:120.7231}).wait(1).to({graphics:mask_1_graphics_41,x:117.6027,y:121.3415}).wait(1).to({graphics:mask_1_graphics_42,x:110.3635,y:121.9141}).wait(1).to({graphics:mask_1_graphics_43,x:103.7035,y:122.4409}).wait(1).to({graphics:mask_1_graphics_44,x:97.6226,y:122.9218}).wait(1).to({graphics:mask_1_graphics_45,x:92.1208,y:123.357}).wait(1).to({graphics:mask_1_graphics_46,x:87.1981,y:123.7463}).wait(1).to({graphics:mask_1_graphics_47,x:82.8546,y:124.0899}).wait(1).to({graphics:mask_1_graphics_48,x:79.0903,y:124.3876}).wait(1).to({graphics:mask_1_graphics_49,x:75.905,y:124.6396}).wait(1).to({graphics:mask_1_graphics_50,x:73.2989,y:124.8457}).wait(1).to({graphics:mask_1_graphics_51,x:71.2719,y:125.006}).wait(1).to({graphics:mask_1_graphics_52,x:69.8241,y:125.1205}).wait(1).to({graphics:mask_1_graphics_53,x:68.9554,y:125.1892}).wait(1).to({graphics:mask_1_graphics_54,x:75.5764,y:129.6703}).wait(45).to({graphics:mask_1_graphics_99,x:75.5764,y:129.6703}).wait(1).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_1_graphics_110,x:75.5764,y:129.6703}).wait(34).to({graphics:mask_1_graphics_144,x:75.5764,y:129.6703}).wait(1).to({graphics:null,x:0,y:0}).wait(45));

	// Layer_10
	this.instance_1 = new lib.germs_group();
	this.instance_1.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(36).to({_off:false},0).wait(63).to({_off:true},1).wait(10).to({_off:false},0).wait(34).to({_off:true},1).wait(45));

	// mask_idn (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_1 = new cjs.Graphics().p("AHdKXQgSABg2gEQg2gEAigXQAhgXACgXQACgWg4gHQg5gHAEgfQAEggAXgSQAJgIAlAVQgKgmATgJQAigPAVADQAkAHgHARIgIAMQgFAHACACQABABAhgMQAjgNAHAAQASAAANANQANANAAASQAAATgNANIgJAKIgFAGQgUAIgBAHQgBAGALAGIAUALQAMAHAAAGQAAARgCAHQgDALgKAJIgcAcQgQAQgMAHIgFABQgLAAgSgVg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AHSKlQgYAAhEgEQhFgFArgeQAqgeADgcQACgchIgJQhHgJAFgoQAFgoAcgXQANgKAuAbQgMgxAYgLQArgUAbAFQAuAIgKAWIgKAQQgGAIADADQABABAqgPQAsgQAJAAQAXAAARAQQAQARAAAXQAAAXgQARIgLAMIgIAIQgYALgCAJQgBAHAOAIIAaAOQAOAIAAAIQAAAWgDAJQgDANgNANIgjAjQgUAUgPAIQgDACgEAAQgOAAgWgag");
	var mask_2_graphics_3 = new cjs.Graphics().p("AHGKyQgdABhTgGQhTgGA0gkQA0gkADgiQADgihXgLQhXgLAHgwQAGgwAigcQAPgMA4AgQgOg7AdgNQAzgYAhAGQA4AJgMAaIgMAUQgHAKADADQABACAzgTQA1gTALAAQAcAAAUAUQAUAUAAAcQAAAcgUAUIgNAPIgJAKQgeANgCAKQgBAJARAKIAfARQARAKAAAKQAAAZgDAMQgEAPgPAQIgrAqQgYAZgTAKQgDACgFAAQgRAAgbggg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AG6K/QghABhhgHQhhgGA8gqQA9grADgoQADgohlgNQhmgMAIg5QAHg4AoghQARgOBDAlQgShEAjgQQA8gcAnAHQBBALgOAfIgOAWQgJAMAEAEQABACA8gWQA/gXAMAAQAhAAAXAYQAYAXAAAhQAAAhgYAYIgPARIgLALQgjAPgBANQgCAKAUAMIAkATQAVANAAALQAAAegEAOQgGASgRASIgyAyQgdAdgVALQgFADgFAAQgUAAgggmg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AGvLMQgmABhwgHQhvgIBGgwQBFgxAEguQADguh0gOQh0gOAIhBQAIhBAugmQAVgQBLArQgThOAngSQBFggAsAHQBLANgQAjQgCAFgPAVQgJAOAEAFQACABBEgYQBIgbAOAAQAmAAAaAbQAbAbAAAmQAAAmgbAaIgRAVIgMAMQgoASgCAOQgCAMAWANIAqAXQAXANAAANQAAAjgEAQQgGAUgUAVIg5A5QghAhgZANQgFADgFAAQgYAAgkgrg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AGkLZQgsABh8gIQh+gJBPg2QBNg3AFgzQAEg0iDgQQiDgQAKhJQAJhKA0gqQAWgSBVAwQgWhYAsgUQBOgkAyAJQBUAOgSAnQgCAGgQAYQgLAPAEAFQACACBNgcQBRgdAQAAQAqAAAeAeQAfAeAAArQAAAqgfAfIgUAXQgLANgCABQgtATgCAQQgCANAZAPIAvAaQAaAPAAAPQAAAngFARQgHAYgXAXIg/BAQglAlgcAPQgGADgGAAQgaAAgpgwg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AGZLmQgwABiLgJQiLgKBXg8QBWg9AFg5QAFg6iSgSQiQgRALhRQAKhSA4guQAZgVBfA2QgZhiAxgWQBWgoA4AJQBdAQgUAsQgCAHgSAaQgMARAFAGQACACBVgfQBaghASAAQAvAAAhAiQAiAhAAAvQAAAvgiAiIgWAZQgNAPgCABQgyAWgDASQgCAOAcARIA0AcQAeARAAAQQAAAsgGATQgHAagaAZIhHBIQgpApgfARQgGADgHAAQgdAAgtg1g");
	var mask_2_graphics_8 = new cjs.Graphics().p("AGOLyQg1ACiYgLQiZgKBfhCQBfhDAGg/QAFg/iggUQifgTAMhZQAMhZA+g0QAbgWBoA7QgbhrA2gZQBegsA9ALQBmARgVAwQgDAHgUAdQgNATAGAGQACACBdghQBjgkAUAAQAzAAAlAlQAlAkAAA0QAAA0glAlIgZAcQgNAQgDABQg3AXgDAUQgCAQAfASIA5AfQAgATAAASQAAAwgGAVQgIAcgcAcIhOBPQgtAtgiASQgHAEgIAAQgfAAgyg7g");
	var mask_2_graphics_9 = new cjs.Graphics().p("AGDL/Qg6ACilgMQilgMBmhIQBohHAGhFQAFhFitgVQitgWANhgQAMhhBEg4QAegYBwBAQgdh1A6gbQBngwBCAMQBvASgXA1QgDAIgVAfQgPAUAGAHQADADBmglQBrgnAVAAQA4AAAoAoQAoAoAAA4QAAA5goAoIgaAeQgPARgDACQg8AZgDAWQgCARAhAUIA+AiQAjAVAAATQAAA0gHAXQgIAfgfAeIhUBWQgyAxgkAUQgIAEgIAAQgjAAg2hAg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AF4MLQg+ACizgMQiygNBvhOQBwhNAGhKQAGhLi8gXQi6gXAOhoQANhpBKg9QAggaB5BGQggh/A/gdQBvgyBIAMQB4ATgZA5QgEAJgXAiQgPAVAGAIQADACBugnQB0grAXAAQA8AAAsAsQArArAAA9QAAA9grArIgdAhQgQATgDABQhBAcgDAXQgDASAkAWQAuAYAVAMQAmAXAAAVQAAA3gHAZQgKAighAhIhbBcQg1A1goAWQgIAEgJAAQglAAg7hFg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AFuMXQhDACjAgNQi/gOB3hTQB4hTAGhQQAGhQjHgYQjKgZAPhwQAOhxBQhAQAigcCCBKQgiiHBEgfQB3g3BNANQCBAWgbA8QgEAJgZAkQgRAYAIAIQACADB2grQB9gtAYAAQBBAAAvAuQAuAvAABAQAABCguAuIgfAkQgRAUgEACQhFAdgEAZQgCAUAmAXQAyAaAWANQApAYAAAXQAAA7gIAbQgKAkgjAjIhiBjQg5A5grAXQgJAFgKAAQgoAAg+hKg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AFjMjQhHACjNgOQjMgOB/hZQCAhZAHhVQAHhWjWgaQjXgaAQh4QAPh4BVhFQAlgeCLBQQgjiQBHghQB/g7BSAOQCJAXgcBBQgFAKgaAmQgSAZAIAIQADADB+gtQCFgwAaAAQBFAAAyAxQAxAyAABFQAABGgxAxIghAmQgTAVgDACQhKAggEAbQgDAVApAYQA1AcAYAOQArAaAAAXQAABAgIAdQgLAmglAmIhpBqQg9A9gtAYQgJAFgLAAQgrAAhDhPg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AFZMvQhMACjZgPQjZgPCIhfQCHheAHhaQAHhbjigcQjlgcARh/QAQh/BahKQAoggCUBVQgniZBMgjQCHg/BXAPQCSAZgeBFQgFAKgcAqQgTAZAIAJQAEADCFgvQCNgzAcAAQBKAAA0A0QA1A0AABJQAABLg1A0IgiAoQgUAXgEACQhPAigDAcQgEAWAsAaQA4AeAaAPQAuAbAAAaQAABDgJAfQgMAogoAoIhvBxQhABAgwAaQgKAGgLAAQguAAhHhUg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AFPM6QhQADjmgQQjmgQCQhkQCPhkAIhfQAHhgjwgeQjxgdASiHQARiGBfhOQApghCeBYQgpihBRgmQCOhCBcAQQCaAaggBJQgFALgdAsQgVAcAJAJQADADCOgyQCVg3AeAAQBNAAA4A4QA4A3AABOQAABOg4A4IglAqQgVAYgEACQhTAkgEAeQgDAXAuAcQA7AfAcAQQAwAdAAAbQAABHgJAhQgNArgqAqIh1B3QhFBEgzAcQgKAFgMAAQgwAAhLhZg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AFFNGQhUADjygRQjzgRCYhqQCWhpAJhkQAHhmj9gfQj+gfATiNQASiOBkhRQAsgkClBdQgriqBWgnQCVhGBhARQCjAbgiBNQgFAMgfAtQgVAeAJAKQADAECWg2QCdg5AfAAQBSAAA7A6QA6A7AABRQAABTg6A6IgnAtQgWAZgFADQhXAlgEAgQgEAZAxAdQA+AgAdARQAzAfAAAcQAABLgKAiQgNAugsAsIh8B9QhIBJg2AdQgLAFgMAAQgzAAhPhdg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AE7NRQhZADj9gSQkAgSCghuQCehvAJhpQAIhrkKggQkLghAUiVQASiVBqhVQAuglCuBjQgui0BagqQCdhJBmASQCrAdgkBRQgFALggAxQgXAfAKAKQAEAECcg4QClg9AhAAQBWAAA+A+QA9A+AABVQAABXg9A9IgpAvQgXAbgFACQhcAogEAhQgEAaAzAeQBCAjAeARQA2AgAAAeQAABQgLAjQgNAwgvAvIiCCDQhMBMg4AeQgLAGgOAAQg1AAhThig");
	var mask_2_graphics_17 = new cjs.Graphics().p("AExNcQhdADkJgSQkMgTCnh0QCmh0AJhuQAJhvkXgjQkYgiAVicQAUibBuhaQAwgnC2BnQgvi8BegrQClhNBqASQCzAfglBUQgFANgjAyQgXAhAKALQAEAECkg7QCtg/AiAAQBaAABBBAQBABBAABaQAABahABBIgrAxQgYAcgFACQhgApgFAjQgEAcA2AfQBEAkAgATQA4AhAAAfQAABUgLAlQgOAygxAxIiICKQhPBPg7AgQgMAGgOAAQg4AAhXhng");
	var mask_2_graphics_18 = new cjs.Graphics().p("AEnNnQhgAEkWgUQkYgTCvh5QCuh6AKhzQAIh0kjgkQklgkAWiiQAVijBzheQAygpC/BtQgyjFBiguQCshQBwATQC7AggnBZQgGANgkA1QgYAiAKALQAEAECsg+QC0hBAkAAQBeAABEBDQBDBDAABfQAABehDBDIgtAzQgZAegFACQhlArgFAlQgEAcA4AiQBIAlAhATQA7AjAAAhQAABXgMAnQgOA0gzAzIiPCQQhTBTg9AhQgNAHgOAAQg6AAhchsg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AEeNyQhlAEkhgVQkkgUC2h+QC2h+AKh5QAJh5kwglQkxglAXiqQAVipB4hiQA1grDGBxQg0jNBngvQCzhUB0AUQDDAhgpBdQgFANgmA3QgZAkALAMQAEAECzhBQC8hEAlAAQBiAABHBGQBGBGAABjQAABihGBGIgvA1QgaAfgFACQhpAtgFAmQgFAeA7AjQBKAnAjAUQA9AlAAAhQAABbgMApQgPA2g1A1IiVCWQhWBXhAAiQgNAHgPAAQg9AAhfhwg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AEVN9QhpADktgVQkvgVC9iDQC9iDAKh9QAKh+k8gnQk9gnAXiwQAWiwB9hmQA3gsDOB1Qg2jVBrgxQC7hYB4AWQDLAigrBgQgGAOgmA5QgbAlAMANQAEAEC6hDQDDhHAnAAQBmAABJBJQBJBJAABmQAABmhJBJIgwA4QgbAfgGADQhtAvgFAnQgFAfA9AkQBOApAkAVQA/AmAAAjQAABegMAqQgQA5g4A3IiaCcQhZBahDAkQgOAHgQAAQg/AAhih0g");
	var mask_2_graphics_21 = new cjs.Graphics().p("AELOHQhsAEk5gWQk6gWDEiIQDEiIALiCQAKiDlIgoQlJgoAYi3QAXi2CChqQA5guDVB5Qg3jdBugzQDDhaB8AWQDSAjgrBkQgHAOgoA8QgcAmAMANQAFAFDBhGQDLhKAoAAQBqAABMBMQBMBMAABqQAABrhMBLIgzA5QgcAhgFADQhyAwgFApQgFAgA/AmQBRAqAlAWQBCAnAAAlQAABhgNAsQgQA7g6A5IigCiQhdBdhFAmQgOAHgRAAQhBAAhnh5g");
	var mask_2_graphics_22 = new cjs.Graphics().p("AECOSQhwAElEgXQlGgXDMiNQDKiNAMiGQAKiIlUgpQlVgqAai9QAYi+CGhtQA7gwDdB+Qg5jlByg1QDKheCAAXQDaAlgtBnQgHAPgqA+QgcAoAMANQAFAFDIhIQDShNAqAAQBtAABPBPQBPBOAABuQAABvhPBNIg0A8QgdAigGADQh1AygGArQgFAhBBAnQBUArAnAXQBEApAAAlQAABmgOAtQgRA9g7A7IimCoQhgBghIAnQgPAIgRAAQhEAAhqh9g");
	var mask_2_graphics_23 = new cjs.Graphics().p("AD+OkQh0AElPgYQlRgXDTiSQDRiSAMiLQALiMlggrQlggrAajEQAZjDCLhyQA8gxDlCCQg7jtB2g3QDRhgCFAXQDhAmgvBrQgHAQgrA/QgdApAMAOQAFAFDPhKQDZhQArAAQByAABRBSQBRBRAABxQAABzhRBQQgPAQgnAuQgeAjgGADQh5A0gGAsQgFAiBDAoQBWAtApAYQBGAqAAAnQAABpgOAvQgRA+g+A+IirCtQhkBkhKAoQgPAIgSAAQhGAAhuiBg");
	var mask_2_graphics_99 = new cjs.Graphics().p("AD+OkQh0AElPgYQlRgXDTiSQDRiSAMiLQALiMlggrQlggrAajEQAZjDCLhyQA8gxDlCCQg7jtB2g3QDRhgCFAXQDhAmgvBrQgHAQgrA/QgdApAMAOQAFAFDPhKQDZhQArAAQByAABRBSQBRBRAABxQAABzhRBQQgPAQgnAuQgeAjgGADQh5A0gGAsQgFAiBDAoQBWAtApAYQBGAqAAAnQAABpgOAvQgRA+g+A+IirCtQhkBkhKAoQgPAIgSAAQhGAAhuiBg");
	var mask_2_graphics_110 = new cjs.Graphics().p("AD+OkQh0AElPgYQlRgXDTiSQDRiSAMiLQALiMlggrQlggrAajEQAZjDCLhyQA8gxDlCCQg7jtB2g3QDRhgCFAXQDhAmgvBrQgHAQgrA/QgdApAMAOQAFAFDPhKQDZhQArAAQByAABRBSQBRBRAABxQAABzhRBQQgPAQgnAuQgeAjgGADQh5A0gGAsQgFAiBDAoQBWAtApAYQBGAqAAAnQAABpgOAvQgRA+g+A+IirCtQhkBkhKAoQgPAIgSAAQhGAAhuiBg");
	var mask_2_graphics_144 = new cjs.Graphics().p("AD+OkQh0AElPgYQlRgXDTiSQDRiSAMiLQALiMlggrQlggrAajEQAZjDCLhyQA8gxDlCCQg7jtB2g3QDRhgCFAXQDhAmgvBrQgHAQgrA/QgdApAMAOQAFAFDPhKQDZhQArAAQByAABRBSQBRBRAABxQAABzhRBQQgPAQgnAuQgeAjgGADQh5A0gGAsQgFAiBDAoQBWAtApAYQBGAqAAAnQAABpgOAvQgRA+g+A+IirCtQhkBkhKAoQgPAIgSAAQhGAAhuiBg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_2_graphics_1,x:58.8008,y:68.3897}).wait(1).to({graphics:mask_2_graphics_2,x:60.6157,y:70.2988}).wait(1).to({graphics:mask_2_graphics_3,x:62.4098,y:72.1861}).wait(1).to({graphics:mask_2_graphics_4,x:64.1832,y:74.0516}).wait(1).to({graphics:mask_2_graphics_5,x:65.9358,y:75.8952}).wait(1).to({graphics:mask_2_graphics_6,x:67.6677,y:77.717}).wait(1).to({graphics:mask_2_graphics_7,x:69.3789,y:79.517}).wait(1).to({graphics:mask_2_graphics_8,x:71.0693,y:81.2952}).wait(1).to({graphics:mask_2_graphics_9,x:72.739,y:83.0516}).wait(1).to({graphics:mask_2_graphics_10,x:74.3879,y:84.7861}).wait(1).to({graphics:mask_2_graphics_11,x:76.0161,y:86.4989}).wait(1).to({graphics:mask_2_graphics_12,x:77.6235,y:88.1898}).wait(1).to({graphics:mask_2_graphics_13,x:79.2102,y:89.8589}).wait(1).to({graphics:mask_2_graphics_14,x:80.7762,y:91.5062}).wait(1).to({graphics:mask_2_graphics_15,x:82.3214,y:93.1316}).wait(1).to({graphics:mask_2_graphics_16,x:83.8459,y:94.7353}).wait(1).to({graphics:mask_2_graphics_17,x:85.3497,y:96.3171}).wait(1).to({graphics:mask_2_graphics_18,x:86.8327,y:97.8771}).wait(1).to({graphics:mask_2_graphics_19,x:88.2949,y:99.4153}).wait(1).to({graphics:mask_2_graphics_20,x:89.7364,y:100.9317}).wait(1).to({graphics:mask_2_graphics_21,x:91.1572,y:102.4262}).wait(1).to({graphics:mask_2_graphics_22,x:92.5573,y:103.8989}).wait(1).to({graphics:mask_2_graphics_23,x:94.426,y:106.133}).wait(76).to({graphics:mask_2_graphics_99,x:94.426,y:106.133}).wait(1).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_2_graphics_110,x:94.426,y:106.133}).wait(34).to({graphics:mask_2_graphics_144,x:94.426,y:106.133}).wait(1).to({graphics:null,x:0,y:0}).wait(45));

	// Layer_1
	this.instance_2 = new lib.germs_group();
	this.instance_2.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(98).to({_off:true},1).wait(10).to({_off:false},0).wait(34).to({_off:true},1).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-12,427,277);


// stage content:
(lib.LysolColdFlu_LDS_300x250_en = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var self = this;
		//this.btnColor;
		////this.downText = this.cta.cta.textDown;
		////this.upText = this.cta.cta.textUp;
		////this.textRestingYPos = 17;
		//this.ctaTextOffset = 30;
		
		////self.upText.y = this.textRestingYPos + this.ctaTextOffset;
		////self.downText.y = this.textRestingYPos;
		
		//this.setBtnColor = function(p_color) {
		//	switch (p_color) {
		//		case "white":
		//			self.cta.cta.arrow.gotoAndPlay("dark-green");
		//			//self.cta.cta.textDown.gotoAndPlay("dark-green");
		//			self.cta.cta.bg.gotoAndPlay("white");
		//			self.btnColor = "white";
		//			break;
		//		case "regular-green":
		//			self.cta.cta.arrow.gotoAndPlay("white");
		//			//self.cta.cta.textDown.gotoAndPlay("white");
		//			self.cta.cta.bg.gotoAndPlay("regular-green");
		//			self.btnColor = "regular-green";
		//			break;	
		//	}
		//}
		//this.setRolloverBtnColor = function() {
		//	if (self.btnColor == "regular-green") {
		//		setTimeout(function() {
		//			self.cta.cta.arrow.gotoAndPlay("dark-green");
		//		}, 150);
		//	}	
		//}
		//this.setRolloutBtnColor = function() {
		//	if (self.btnColor == "regular-green") {
		//		setTimeout(function() {
		//			self.cta.cta.arrow.gotoAndPlay("white");
		//		}, 150);
		//	}
		//}
		
		//// Set initial button color
		//setTimeout(function() {
		//	self.setBtnColor("regular-green");
		//}, 50);
		
		// Clicktag =======================
		
		this.clicktag.addEventListener('click', handleClick);
		//this.clicktag.addEventListener('mouseover', handleMouseOver);
		//this.clicktag.addEventListener('mouseout', handleMouseOut);
		
		function handleClick() {
		    window.ctaClick();
		}
		//function handleMouseOver() {
		//	//var landingY = self.textRestingYPos;
		//	self.cta.gotoAndPlay("over"); 
		//	self.cta.cta.gotoAndPlay("over");
		//	self.setRolloverBtnColor();
		//	//self.downText.y = landingY;
		//	//self.upText.y = landingY-self.ctaTextOffset;
		//	//createjs.Tween.get(self.downText, {override:true}).to({y:landingY+self.ctaTextOffset}, 200, createjs.Ease.quintIn);
		//	//createjs.Tween.get(self.upText, {override:true}).wait(200).to({y:landingY}, 300, createjs.Ease.quintOut);
		//}
		//function handleMouseOut() {
		//	//var landingY = self.textRestingYPos;
		//	self.cta.gotoAndPlay("out");
		//	self.cta.cta.gotoAndPlay("out");
		//	self.setRolloutBtnColor();
		//	//self.downText.y = landingY+self.ctaTextOffset;
		//	//self.upText.y = landingY;
		//	//createjs.Tween.get(self.downText, {override:true}).wait(200).to({y:landingY}, 300, createjs.Ease.quintOut);
		//	//createjs.Tween.get(self.upText, {override:true}).to({y:landingY-self.ctaTextOffset}, 200, createjs.Ease.quintIn);
		//}
		//
	}
	this.frame_396 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(396).call(this.frame_396).wait(1));

	// ClickTag
	this.clicktag = new lib.click();
	this.clicktag.setTransform(150.1,125.3,1,0.9999,0,0,0,0.1,0.3);
	new cjs.ButtonHelper(this.clicktag, 0, 1, 2, false, new lib.click(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clicktag).wait(397));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("A3bzhMAu3AAAMAAAAnDMgu3AAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(397));

	// what_it_takes
	this.instance = new lib.whatittakes();
	this.instance.setTransform(247.5,184,1,1,0,0,0,32.5,11);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(368).to({_off:false},0).to({alpha:1},9,cjs.Ease.get(1)).wait(20));

	// product
	this.instance_1 = new lib.product_1();
	this.instance_1.setTransform(355.5,106.5,1,1,0,0,0,35.5,54.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(361).to({_off:false},0).to({x:245.5},9,cjs.Ease.get(1)).wait(27));

	// bg_blue
	this.instance_2 = new lib.bg_blue();
	this.instance_2.setTransform(358,125,1,1,0,0,0,52,125);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(354).to({_off:false},0).to({x:248},9,cjs.Ease.get(1)).wait(34));

	// copy_04
	this.instance_3 = new lib.copy_04();
	this.instance_3.setTransform(68.1,234.8,1,1,0,0,0,61.1,12);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(347).to({_off:false},0).to({alpha:1},9,cjs.Ease.get(1)).wait(41));

	// btn_cta
	this.instance_4 = new lib.btn_cta();
	this.instance_4.setTransform(90,151,1,1,0,0,0,61,20.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(340).to({_off:false},0).to({x:70,alpha:1},9,cjs.Ease.get(1)).wait(48));

	// copy_03
	this.instance_5 = new lib.copy_03();
	this.instance_5.setTransform(109.7,90.25,1,1,0,0,0,82,27.3);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(334).to({_off:false},0).to({x:89.7,alpha:1},9,cjs.Ease.get(1)).wait(54));

	// copy_02
	this.instance_6 = new lib.copy_02();
	this.instance_6.setTransform(150.05,125.7,1,1,0,0,0,122.8,27.7);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(246).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).wait(67).to({alpha:0},5).to({_off:true},1).wait(63));

	// logo
	this.instance_7 = new lib.logo_1();
	this.instance_7.setTransform(265.5,217,1,1,0,0,0,24.5,23);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(165).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).to({_off:true},154).wait(63));

	// bg_light_blue
	this.instance_8 = new lib.bg_lightblue();
	this.instance_8.setTransform(98,-125,1,1,0,0,0,98,125);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(237).to({_off:false},0).to({y:125},9,cjs.Ease.get(1)).wait(151));

	// hand
	this.instance_9 = new lib.hand_spray_1("single",0);
	this.instance_9.setTransform(-97.1,245.05,1,1,-22.7187,0,0,-0.1,112);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(180).to({_off:false},0).to({regX:0,rotation:0,x:0,y:185},4,cjs.Ease.get(1)).wait(3).to({mode:"synched"},0).to({regX:0.1,rotation:4.9513,x:-4.05,startPosition:12},20,cjs.Ease.get(1)).to({regX:-0.1,rotation:-7.0401,x:-5.2,y:195,startPosition:38},20,cjs.Ease.get(1)).to({regX:0,rotation:0,x:0,y:185,mode:"single",startPosition:0},10,cjs.Ease.get(1)).to({y:425},9,cjs.Ease.get(1)).to({_off:true},1).wait(150));

	// spray
	this.instance_10 = new lib.spray_mist("synched",0);
	this.instance_10.setTransform(150,125,0.6263,0.6263,0,0,0,150,150.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(187).to({_off:false},0).to({regX:149.8,regY:149.8,scaleX:1.486,scaleY:1.486,x:149.9,y:124.65,alpha:0.2813},40,cjs.Ease.get(1)).to({scaleX:2.1808,scaleY:2.1808,x:150,y:124.75,alpha:0},10).to({_off:true},4).wait(156));

	// ice_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_33 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_34 = new cjs.Graphics().p("AumB3IAAjtIdNAAIAADtg");
	var mask_graphics_35 = new cjs.Graphics().p("AumCbIAAk1IdNAAIAAE1g");
	var mask_graphics_36 = new cjs.Graphics().p("AumC/IAAl9IdNAAIAAF9g");
	var mask_graphics_37 = new cjs.Graphics().p("AumDkIAAnHIdNAAIAAHHg");
	var mask_graphics_38 = new cjs.Graphics().p("AumEIIAAoPIdNAAIAAIPg");
	var mask_graphics_39 = new cjs.Graphics().p("AumEsIAApXIdNAAIAAJXg");
	var mask_graphics_40 = new cjs.Graphics().p("AumFRIAAqgIdNAAIAAKgg");
	var mask_graphics_41 = new cjs.Graphics().p("AumF1IAArpIdNAAIAALpg");
	var mask_graphics_42 = new cjs.Graphics().p("AumGZIAAsxIdNAAIAAMxg");
	var mask_graphics_43 = new cjs.Graphics().p("AumG9IAAt6IdNAAIAAN6g");
	var mask_graphics_44 = new cjs.Graphics().p("AumHiIAAvDIdNAAIAAPDg");
	var mask_graphics_45 = new cjs.Graphics().p("AumIGIAAwLIdNAAIAAQLg");
	var mask_graphics_46 = new cjs.Graphics().p("AumIrIAAxUIdNAAIAARUg");
	var mask_graphics_47 = new cjs.Graphics().p("AumJPIAAydIdNAAIAASdg");
	var mask_graphics_48 = new cjs.Graphics().p("AumJzIAAzlIdNAAIAATlg");
	var mask_graphics_49 = new cjs.Graphics().p("AumKXIAA0tIdNAAIAAUtg");
	var mask_graphics_50 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_51 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_52 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_53 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_54 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_55 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_56 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_57 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_58 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_59 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_60 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_61 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_62 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_63 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_64 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_65 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_66 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_67 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_68 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_69 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_70 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_71 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_72 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_73 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_74 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_75 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_76 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_77 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_78 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_79 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_80 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_81 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_82 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_83 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_84 = new cjs.Graphics().p("AumJvIAAzdIdNAAIAATdg");
	var mask_graphics_85 = new cjs.Graphics().p("AumIiIAAxCIdNAAIAARCg");
	var mask_graphics_86 = new cjs.Graphics().p("AumHUIAAunIdNAAIAAOng");
	var mask_graphics_87 = new cjs.Graphics().p("AumGHIAAsNIdNAAIAAMNg");
	var mask_graphics_88 = new cjs.Graphics().p("AumE6IAApzIdNAAIAAJzg");
	var mask_graphics_89 = new cjs.Graphics().p("AumDtIAAnZIdNAAIAAHZg");
	var mask_graphics_90 = new cjs.Graphics().p("AumCfIAAk9IdNAAIAAE9g");
	var mask_graphics_91 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_92 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_93 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_94 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_95 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_96 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_97 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_98 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_99 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_100 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_101 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_102 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_103 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_104 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_105 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_106 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_107 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_108 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_109 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_110 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_111 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_112 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_113 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_114 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_115 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_116 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_117 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_118 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_119 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_120 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_121 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_122 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_123 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_124 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_125 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_126 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_127 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_128 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_129 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_130 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_131 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_132 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_133 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_134 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_135 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_136 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_137 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_138 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_139 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_140 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_141 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_142 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_143 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_144 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_145 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_146 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_147 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_148 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_149 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_150 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_151 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_152 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_153 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_154 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_155 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_156 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_157 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_158 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_159 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_160 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_161 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_162 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_163 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_164 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_165 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_166 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_167 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_168 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_169 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_170 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_171 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_172 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_173 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_174 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_175 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_176 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_177 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_178 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_179 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_180 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_181 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_182 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_183 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_184 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_185 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_186 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_187 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_188 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_189 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_190 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_191 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_192 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_193 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_194 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_195 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_196 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_197 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_198 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_199 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_200 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_201 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_202 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_203 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_204 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_205 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_206 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_207 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_208 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_209 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_210 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_211 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_212 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_213 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_214 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_215 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_216 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_217 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_218 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_219 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_220 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_221 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_222 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_223 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_224 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_225 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_226 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_227 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_228 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_229 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_230 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_231 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_232 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_233 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_234 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_235 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_236 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_237 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_238 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_239 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_240 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_241 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_242 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_243 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_244 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_245 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_246 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_247 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_248 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_249 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_250 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_251 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_252 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_253 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_254 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_255 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_256 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_257 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_258 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_259 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_260 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_261 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_262 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_263 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_264 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_265 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_266 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_267 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_268 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_269 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_270 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_271 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_272 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_273 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_274 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_275 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_276 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_277 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_278 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_279 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_280 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_281 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_282 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_283 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_284 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_285 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_286 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_287 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_288 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_289 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_290 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_291 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_292 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_293 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_294 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_295 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_296 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_297 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_298 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_299 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_300 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_301 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_302 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_303 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_304 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_305 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_306 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_307 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_308 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_309 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_310 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_311 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_312 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_313 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_314 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_315 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_316 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_317 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_318 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_319 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_320 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_321 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_322 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_323 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_324 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_325 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_326 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_327 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_328 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_329 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_330 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_331 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_332 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_333 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_334 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_335 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_336 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_337 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_338 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_339 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_340 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_341 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_342 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_343 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_344 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_345 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_346 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_347 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_348 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_349 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_350 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_351 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_352 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_353 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_354 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_355 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_356 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_357 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_358 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_359 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_360 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_361 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_362 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_363 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_364 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_365 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_366 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_367 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_368 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_369 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_370 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_371 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_372 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_373 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_374 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_375 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_376 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_377 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_378 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_379 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_380 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_381 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_382 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_383 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_384 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_385 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_386 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_387 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_388 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_389 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_390 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_391 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_392 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_393 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_394 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_395 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_396 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(33).to({graphics:mask_graphics_33,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_34,x:193,y:84.95}).wait(1).to({graphics:mask_graphics_35,x:193,y:88.625}).wait(1).to({graphics:mask_graphics_36,x:193,y:92.275}).wait(1).to({graphics:mask_graphics_37,x:193,y:95.95}).wait(1).to({graphics:mask_graphics_38,x:193,y:99.575}).wait(1).to({graphics:mask_graphics_39,x:193,y:103.25}).wait(1).to({graphics:mask_graphics_40,x:193,y:106.9}).wait(1).to({graphics:mask_graphics_41,x:193,y:110.575}).wait(1).to({graphics:mask_graphics_42,x:193,y:114.225}).wait(1).to({graphics:mask_graphics_43,x:193,y:117.9}).wait(1).to({graphics:mask_graphics_44,x:193,y:121.55}).wait(1).to({graphics:mask_graphics_45,x:193,y:125.225}).wait(1).to({graphics:mask_graphics_46,x:193,y:128.85}).wait(1).to({graphics:mask_graphics_47,x:193,y:132.525}).wait(1).to({graphics:mask_graphics_48,x:193,y:136.175}).wait(1).to({graphics:mask_graphics_49,x:193,y:139.85}).wait(1).to({graphics:mask_graphics_50,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_51,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_52,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_53,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_54,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_55,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_56,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_57,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_58,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_59,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_60,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_61,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_62,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_63,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_64,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_65,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_66,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_67,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_68,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_69,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_70,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_71,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_72,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_73,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_74,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_75,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_76,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_77,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_78,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_79,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_80,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_81,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_82,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_83,x:193,y:143.5}).wait(1).to({graphics:mask_graphics_84,x:193,y:135.725}).wait(1).to({graphics:mask_graphics_85,x:193,y:127.95}).wait(1).to({graphics:mask_graphics_86,x:193,y:120.175}).wait(1).to({graphics:mask_graphics_87,x:193,y:112.4}).wait(1).to({graphics:mask_graphics_88,x:193,y:104.625}).wait(1).to({graphics:mask_graphics_89,x:193,y:96.85}).wait(1).to({graphics:mask_graphics_90,x:193,y:89.075}).wait(1).to({graphics:mask_graphics_91,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_92,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_93,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_94,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_95,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_96,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_97,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_98,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_99,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_100,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_101,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_102,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_103,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_104,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_105,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_106,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_107,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_108,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_109,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_110,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_111,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_112,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_113,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_114,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_115,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_116,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_117,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_118,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_119,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_120,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_121,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_122,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_123,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_124,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_125,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_126,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_127,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_128,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_129,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_130,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_131,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_132,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_133,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_134,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_135,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_136,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_137,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_138,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_139,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_140,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_141,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_142,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_143,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_144,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_145,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_146,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_147,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_148,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_149,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_150,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_151,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_152,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_153,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_154,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_155,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_156,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_157,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_158,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_159,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_160,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_161,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_162,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_163,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_164,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_165,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_166,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_167,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_168,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_169,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_170,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_171,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_172,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_173,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_174,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_175,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_176,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_177,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_178,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_179,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_180,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_181,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_182,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_183,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_184,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_185,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_186,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_187,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_188,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_189,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_190,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_191,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_192,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_193,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_194,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_195,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_196,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_197,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_198,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_199,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_200,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_201,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_202,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_203,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_204,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_205,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_206,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_207,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_208,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_209,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_210,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_211,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_212,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_213,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_214,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_215,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_216,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_217,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_218,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_219,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_220,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_221,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_222,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_223,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_224,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_225,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_226,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_227,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_228,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_229,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_230,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_231,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_232,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_233,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_234,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_235,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_236,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_237,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_238,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_239,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_240,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_241,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_242,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_243,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_244,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_245,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_246,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_247,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_248,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_249,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_250,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_251,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_252,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_253,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_254,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_255,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_256,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_257,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_258,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_259,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_260,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_261,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_262,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_263,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_264,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_265,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_266,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_267,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_268,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_269,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_270,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_271,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_272,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_273,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_274,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_275,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_276,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_277,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_278,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_279,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_280,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_281,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_282,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_283,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_284,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_285,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_286,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_287,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_288,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_289,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_290,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_291,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_292,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_293,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_294,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_295,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_296,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_297,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_298,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_299,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_300,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_301,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_302,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_303,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_304,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_305,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_306,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_307,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_308,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_309,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_310,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_311,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_312,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_313,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_314,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_315,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_316,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_317,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_318,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_319,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_320,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_321,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_322,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_323,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_324,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_325,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_326,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_327,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_328,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_329,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_330,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_331,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_332,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_333,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_334,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_335,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_336,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_337,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_338,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_339,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_340,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_341,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_342,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_343,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_344,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_345,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_346,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_347,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_348,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_349,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_350,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_351,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_352,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_353,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_354,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_355,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_356,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_357,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_358,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_359,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_360,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_361,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_362,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_363,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_364,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_365,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_366,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_367,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_368,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_369,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_370,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_371,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_372,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_373,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_374,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_375,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_376,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_377,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_378,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_379,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_380,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_381,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_382,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_383,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_384,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_385,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_386,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_387,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_388,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_389,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_390,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_391,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_392,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_393,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_394,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_395,x:193,y:81.3}).wait(1).to({graphics:mask_graphics_396,x:193,y:81.3}).wait(1));

	// ice
	this.instance_11 = new lib.ice_1();
	this.instance_11.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(33).to({_off:false},0).wait(50).to({regX:150.1,scaleX:0.72,scaleY:0.72,x:154.05,y:94,alpha:0},8).wait(306));

	// cold_ice
	this.instance_12 = new lib.text_cold_1();
	this.instance_12.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({alpha:1},8).wait(42).to({regX:150.1,regY:125.1,scaleX:0.6155,scaleY:0.6155,x:155.15,y:98.1,alpha:0},8).to({_off:true},2).wait(304));

	// text_cold1
	this.instance_13 = new lib.copy_01();
	this.instance_13.setTransform(162.2,131.5,1,1,0,0,0,84.2,25.9);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(24).to({_off:false},0).to({alpha:1},9).wait(50).to({regX:84.3,regY:26.2,scaleX:0.6324,scaleY:0.6323,x:163.45,y:100.25},8).to({_off:true},150).wait(156));

	// text_cold2
	this.instance_14 = new lib.text_andFluSeason();
	this.instance_14.setTransform(150,125.95,1,1,0,0,0,102.2,20.2);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(93).to({_off:false},0).to({alpha:1},4).wait(300));

	// text_cold3
	this.instance_15 = new lib.text_cold3();
	this.instance_15.setTransform(70,156.95,1,1,0,0,0,69,20.2);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(93).to({_off:false},0).to({alpha:1},4).wait(300));

	// germs
	this.instance_16 = new lib.germs("synched",0,false);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(106).to({_off:false},0).wait(100).to({startPosition:110},0).to({alpha:0,startPosition:141},31,cjs.Ease.get(1)).to({_off:true},4).wait(156));

	// white_box
	this.instance_17 = new lib.whitebox();
	this.instance_17.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(16).to({_off:false},0).to({alpha:0.6914},8).wait(69).to({alpha:1},13,cjs.Ease.get(1)).wait(291));

	// logo
	this.instance_18 = new lib.logo_1();
	this.instance_18.setTransform(265.5,217,1,1,0,0,0,24.5,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(16).to({alpha:0},8,cjs.Ease.get(1)).to({_off:true},1).wait(372));

	// frost
	this.instance_19 = new lib.frost();
	this.instance_19.setTransform(150,126,1,1,0,0,0,150,125);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(36).to({_off:false},0).to({alpha:1},25).wait(32).to({alpha:0},28).wait(276));

	// boy
	this.instance_20 = new lib.girl();
	this.instance_20.setTransform(169.4,144.7,0.9999,0.9999,-0.0009,0,0,169.4,144.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).to({_off:true},61).wait(336));

	// BG
	this.instance_21 = new lib.whitebox();
	this.instance_21.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(397));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.8,-153.3,604.5,638.3);
// library properties:
lib.properties = {
	id: '3CE4C820892743FB9D5BF0281A417E72',
	width: 300,
	height: 250,
	fps: 30,
	color: "#339966",
	opacity: 1.00,
	manifest: [
		{src:"images/boy.jpg?1574352336139", id:"boy"},
		{src:"images/boy_frost.jpg?1574352336139", id:"boy_frost"},
		{src:"images/germs_sm.png?1574352336139", id:"germs_sm"},
		{src:"images/hand_spray.png?1574352336139", id:"hand_spray"},
		{src:"images/ice.png?1574352336139", id:"ice"},
		{src:"images/logo.png?1574352336139", id:"logo"},
		{src:"images/product.png?1574352336139", id:"product"},
		{src:"images/spray_01.png?1574352336139", id:"spray_01"},
		{src:"images/spray_02.png?1574352336139", id:"spray_02"},
		{src:"images/text_cold.png?1574352336139", id:"text_cold"},
		{src:"images/whatittaketoprotect.png?1574352336139", id:"whatittaketoprotect"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3CE4C820892743FB9D5BF0281A417E72'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;