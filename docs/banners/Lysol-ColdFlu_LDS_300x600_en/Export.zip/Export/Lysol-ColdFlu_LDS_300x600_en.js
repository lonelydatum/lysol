(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.boy = function() {
	this.initialize(img.boy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.boy_frost = function() {
	this.initialize(img.boy_frost);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.germs_sm = function() {
	this.initialize(img.germs_sm);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,150,125);


(lib.hand_spray = function() {
	this.initialize(img.hand_spray);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,87,172);


(lib.ice = function() {
	this.initialize(img.ice);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,49,46);


(lib.product = function() {
	this.initialize(img.product);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,133,201);


(lib.spray_01 = function() {
	this.initialize(img.spray_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,141,93);


(lib.spray_02 = function() {
	this.initialize(img.spray_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);


(lib.text_cold = function() {
	this.initialize(img.text_cold);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.whatittaketoprotect = function() {
	this.initialize(img.whatittaketoprotect);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,275,19);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whitebox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebox, new cjs.Rectangle(0,0,300,600), null);


(lib.whatittakes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.whatittaketoprotect();
	this.instance.setTransform(3,-10,0.98,0.98);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whatittakes, new cjs.Rectangle(3,-10,269.5,18.6), null);


(lib.text_cold3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape.setTransform(264.725,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AAtBjIgtiWIAAAAIgtCWIghAAIg6jEIAnAAIAlCNIAAAAIAsiNIAiAAIArCNIABAAIAniNIAjAAIg5DEg");
	this.shape_1.setTransform(240,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgHgTAAgXQAAgXAHgTQAIgTAOgOQANgNAUgIQASgHAXAAQAWgBATAIQAUAHAOANQAOAOAHATQAJATgBAXQABAXgJATQgHATgOAOQgOANgUAIQgTAIgWAAQgXAAgSgIgAgbhBQgNAFgIAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAIAKANAFQAMAGAPAAQAPAAANgGQAMgFAJgKQAJgKAFgNQAEgNAAgPQAAgPgEgNQgFgMgJgKQgJgKgMgFQgNgFgPAAQgPAAgMAFg");
	this.shape_2.setTransform(214.75,19.1984);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_3.setTransform(195.175,19.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AhDBjIAAjEICCAAIAAAfIhfAAIAAAxIBaAAIAAAeIhaAAIAAA2IBkAAIAAAgg");
	this.shape_4.setTransform(179.175,19.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_5.setTransform(162.225,19.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgQBjIAAilIg9AAIAAgfICbAAIAAAfIg8AAIAAClg");
	this.shape_6.setTransform(146.275,19.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgpBgQgUgHgNgNQgOgOgIgTQgIgTABgXQgBgXAIgTQAIgTAOgOQANgNAUgIQATgHAWAAQAWgBAUAIQATAHAOANQANAOAIATQAJATAAAXQAAAXgJATQgIATgNAOQgOANgTAIQgUAIgWAAQgWAAgTgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQANAGAOAAQAPAAAMgGQANgFAJgKQAJgKAFgNQAEgNABgPQgBgPgEgNQgFgMgJgKQgJgKgNgFQgMgFgPAAQgOAAgNAFg");
	this.shape_7.setTransform(126.7,19.1984);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_8.setTransform(108.825,19.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("AAgBjIgthUIgZAAIAABUIgjAAIAAjEIBEAAQANgBAOADQANADAKAGQAKAGAGALQAHALAAARQAAAVgMAPQgMAOgWACIA0BYgAgmgOIAbAAIAOgBQAIgBAGgCQAGgCAEgGQAEgGAAgJQAAgJgEgFQgDgGgGgCQgGgDgHgBIgNgBIgeAAg");
	this.shape_9.setTransform(92.825,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AA8BjIgSgtIhVAAIgRAtIgoAAIBWjEIAdAAIBVDEgAAeAXIgehPIgeBPIA8AAg");
	this.shape_10.setTransform(73.15,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AAuBjIAAhYIhbAAIAABYIgjAAIAAjEIAjAAIAABOIBbAAIAAhOIAjAAIAADEg");
	this.shape_11.setTransform(52.8,19.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgaBgQgTgIgNgNQgOgNgIgTQgIgTAAgXQAAgXAIgTQAIgUAOgNQANgOATgHQATgIAWAAQAUABARAGQARAIAPARIgbATQgLgLgKgEQgKgDgLAAQgPAAgLAEQgNAGgIAJQgJALgFAMQgFANAAAPQAAAOAFAOQAFANAJAKQAIAJANAGQALAFAPABQAMgBAMgFQALgGAKgMIAdAUQgOATgTAIQgTAJgWgBQgWABgTgIg");
	this.shape_12.setTransform(33.475,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_cold3, new cjs.Rectangle(0,0,299.2,40.5), null);


(lib.text_cold_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.text_cold();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_cold_1, new cjs.Rectangle(0,0,300,250), null);


(lib.text_andFluSeason = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape.setTransform(211.075,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgRBjIAAjEIAjAAIAADEg");
	this.shape_1.setTransform(196.15,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AAsBjIhgiXIgBAAIAACXIgjAAIAAjEIAvAAIBeCRIABAAIAAiRIAjAAIAADEg");
	this.shape_2.setTransform(173.025,19.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgqBgQgSgHgOgNQgOgOgIgTQgIgTAAgXQAAgXAIgTQAIgTAOgOQAOgNASgIQAUgHAWAAQAWgBAUAIQATAHAOANQANAOAJATQAHATABAXQgBAXgHATQgJATgNAOQgOANgTAIQgUAIgWAAQgWAAgUgIgAgbhBQgMAFgJAKQgJAKgFAMQgFANAAAPQAAAPAFANQAFANAJAKQAJAKAMAFQAMAGAPAAQAPAAAMgGQANgFAJgKQAJgKAFgNQAFgNAAgPQAAgPgFgNQgFgMgJgKQgJgKgNgFQgMgFgPAAQgPAAgMAFg");
	this.shape_3.setTransform(150.35,19.1984);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_4.setTransform(130.475,19.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AA8BjIgSgtIhVAAIgRAtIgoAAIBWjEIAdAAIBVDEgAAeAXIgehPIgeBPIA8AAg");
	this.shape_5.setTransform(112.75,19.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AhDBjIAAjEICCAAIAAAfIhfAAIAAAxIBaAAIAAAeIhaAAIAAA2IBkAAIAAAgg");
	this.shape_6.setTransform(94.725,19.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgmBiQgRgHgMgOIAagaQAHAKAKAFQALAGALAAIAMgCQAGgBAFgEQAFgDADgGQADgEAAgHQAAgLgHgGQgHgFgKgFIgWgHQgMgEgKgGQgLgGgHgKQgHgKAAgSQAAgPAHgMQAGgLAKgHQAKgIANgDQANgEANAAQAQAAAOAFQAPAFALALIgZAbQgGgIgJgEQgJgDgLAAIgLAAQgFACgFADQgEADgDAFQgDAFAAAHQAAAJAHAGQAHAFAKAEIAWAHQAMAEAKAGQALAGAHAKQAGALAAARQAAARgFALQgGAMgKAIQgKAIgNAEQgNADgOAAQgSAAgRgFg");
	this.shape_7.setTransform(77.425,19.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgeBfQgPgFgKgKQgLgKgGgOQgGgOAAgTIAAh7IAjAAIAAB6QAAAIACAIQACAHAGAHQAFAHAIAFQAJADALAAQANAAAIgDQAJgFAFgHQAFgHACgHQACgIAAgIIAAh6IAjAAIAAB7QAAATgGAOQgGAOgKAKQgLAKgOAFQgPAGgRAAQgQAAgOgGg");
	this.shape_8.setTransform(51.475,19.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("Ag6BjIAAjEIAjAAIAACkIBSAAIAAAgg");
	this.shape_9.setTransform(35.175,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("Ag+BjIAAjEIB+AAIAAAfIhbAAIAAA0IBVAAIAAAfIhVAAIAABSg");
	this.shape_10.setTransform(19.65,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("Ag0BkQgMgEgKgHQgJgIgFgKQgGgLABgOQAAgLACgIQAEgIAFgIQAHgGAIgFQAHgGAJgDIgJgKIgHgLIgFgLQgBgGgBgHQABgMAEgJQAEgKAJgFQAHgHALgCQAKgEALAAQALAAAJAEQAKACAIAGQAHAGAFAIQAFAKgBALQAAAJgDAIQgDAHgGAHQgFAHgHAEIgOAJIAfAhIAWggIAnAAIgnA4IArAvIgsAAIgUgXQgMAOgOAHQgNAHgTgBQgNAAgMgDgAgnARIgJAGIgHAJQgCAFAAAHQAAAGACAGQADAFAFAEQAEAEAFACQAGACAGAAQALABAJgHIAPgNIgngsgAghhDQgHAFAAAKIACAHIAEAIIAGAGIAHAHIAJgFIAIgHQAEgDABgFQADgEAAgGQAAgIgGgGQgFgEgKAAQgJgBgHAGg");
	this.shape_11.setTransform(-6.95,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_andFluSeason, new cjs.Rectangle(-19,0,242.5,40.5), null);


(lib.spray_mist = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray_02();
	this.instance.setTransform(-51,-47,1.341,1.341);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.5466,scaleY:1.5466,rotation:180,x:382,y:370},0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0.118)","#FFFFFF","rgba(255,255,255,0)"],[0,0,0,1],0,0,0,0,0,151.9).s().p("AwqQrQm6m6AApxQAApwG6m6QG6m6JwAAQJxAAG6G6QG5G6AAJwQAAJxm5G6Qm6G6pxAAQpwAAm6m6g");
	this.shape.setTransform(158.05,159.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-307.5,-189.5,1129.1,765);


(lib.spray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray_01();
	this.instance.setTransform(4.5,0,1,0.8635,3.2113);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,88.1);


(lib.product_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.product();
	this.instance.setTransform(0,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.product_1, new cjs.Rectangle(0,-23,133,201), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(0,0,49,46), null);


(lib.ice_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ice();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ice_1, new cjs.Rectangle(0,0,300,250), null);


(lib.girl = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.boy();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girl, new cjs.Rectangle(0,0,300,600), null);


(lib.germs_group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.germs_sm();
	this.instance.setTransform(-74,-185);

	this.instance_1 = new lib.germs_sm();
	this.instance_1.setTransform(214,-198);

	this.instance_2 = new lib.germs_sm();
	this.instance_2.setTransform(73,-194);

	this.instance_3 = new lib.germs_sm();
	this.instance_3.setTransform(-6,314,1,1,0,-90,90);

	this.instance_4 = new lib.germs_sm();
	this.instance_4.setTransform(112,464,1,1,-90);

	this.instance_5 = new lib.germs_sm();
	this.instance_5.setTransform(381,327,1,1,0,0,180);

	this.instance_6 = new lib.germs_sm();
	this.instance_6.setTransform(424,184,1,1,90);

	this.instance_7 = new lib.germs_sm();
	this.instance_7.setTransform(310,187,1,1,90);

	this.instance_8 = new lib.germs_sm();
	this.instance_8.setTransform(40,193);

	this.instance_9 = new lib.germs_sm();
	this.instance_9.setTransform(-13,47,1,1,0,-90,90);

	this.instance_10 = new lib.germs_sm();
	this.instance_10.setTransform(112,47,1,1,0,-90,90);

	this.instance_11 = new lib.germs_sm();
	this.instance_11.setTransform(381,60,1,1,0,0,180);

	this.instance_12 = new lib.germs_sm();
	this.instance_12.setTransform(421,-80,1,1,90);

	this.instance_13 = new lib.germs_sm();
	this.instance_13.setTransform(310,-80,1,1,90);

	this.instance_14 = new lib.germs_sm();
	this.instance_14.setTransform(40,-74);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.germs_group, new cjs.Rectangle(-74,-198,498,662), null);


(lib.frost = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.boy_frost();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.frost, new cjs.Rectangle(0,0,300,600), null);


(lib.copy_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCADQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgCg");
	this.shape.setTransform(199.375,9.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_1.setTransform(197.3,6.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_2.setTransform(194.175,8.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHAdIgFgGIAAAHIgHAAIAAg8IAHAAIAAAdQACgDAEgCQADgCADAAQAFAAADACIAGAEIAEAFQACAEAAAEQAAAEgCAEIgEAGIgFAEQgEACgEAAQgEAAgEgCgAgFgBIgEACQgCACAAADIgBAFIABAGQAAAAAAABQAAABABAAQAAABAAAAQABAAAAABIAEADIAFABIAFgBIAFgDIACgEIABgGIgBgFIgCgFIgFgCIgFgBIgFABg");
	this.shape_3.setTransform(189.625,7.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_4.setTransform(184.975,8.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_5.setTransform(182,6.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_6.setTransform(176.675,8.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAKAeIAAgWQAAgFgCgDQgCgBgEAAIgFABIgDACIgCAEIgBAGIAAASIgGAAIAAg7IAGAAIAAAcIAAAAIACgCIADgCIADgCIADAAIAGABIAFADQACACAAACIABAGIAAAXg");
	this.shape_7.setTransform(172.275,6.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAAAXIgCgCIgBgEIgBgFIAAgTIgIAAIAAgGIAIAAIAAgKIAGAAIAAAKIALAAIAAAGIgLAAIAAARIAAADIAAADIACACIADABIADAAIADgCIAAAGIgEABIgDAAIgGgBg");
	this.shape_8.setTransform(168.625,7.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AALATIgLgcIAAAAIgJAcIgGAAIgNglIAHAAIAJAcIAKgcIAFAAIAKAcIAJgcIAHAAIgNAlg");
	this.shape_9.setTransform(162.1,8.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHASIgHgEIgDgGIgCgIQAAgDACgEQABgEACgCIAHgEQAEgCADAAIAIACIAGAEQACACACAEQACAEAAADQAAAEgCAEIgEAGIgGAEIgIACQgDAAgEgCgAgFgMIgEADIgDAFIgBAEIABAGIADAEIAEADIAFABIAFgBIAFgDIACgEIABgGIgBgEIgCgFIgFgDIgFgBIgFABg");
	this.shape_10.setTransform(156.8,8.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_11.setTransform(153.45,6.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_12.setTransform(151.55,6.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgHASIgHgEIgDgGIgCgIQAAgDACgEQABgEACgCIAHgEQAEgCADAAIAIACIAGAEQACACACAEQACAEAAADQAAAEgCAEIgEAGIgGAEIgIACQgDAAgEgCgAgFgMIgEADIgDAFIgBAEIABAGIADAEIAEADIAFABIAFgBIAFgDIACgEIABgGIgBgEIgCgFIgFgDIgFgBIgFABg");
	this.shape_13.setTransform(148.25,8.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgEAfIAAgfIgIAAIAAgGIAIAAIAAgIIABgGIACgFIADgEIAHgBIACABIACAAIgBAGIgEgBIgEABIgCACIgBAEIAAAEIAAAHIAKAAIAAAGIgKAAIAAAfg");
	this.shape_14.setTransform(144.75,6.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_15.setTransform(138.675,7.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AALATIAAgVQAAgFgDgDQgCgCgEAAIgFABIgDADIgCAEIgBAFIAAASIgGAAIAAgbIAAgFIAAgEIAFAAIAAADIAAADIABAAIACgDIADgCIADgCIAEAAIAFABIAFADQACACAAADIABAGIAAAWg");
	this.shape_16.setTransform(134.1,8.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_17.setTransform(129.775,8.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_18.setTransform(123.075,7.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_19.setTransform(118.575,8.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_20.setTransform(114.375,8.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJATIAAgbIgBgFIAAgEIAGAAIAAADIAAADIABAAIABgDIACgCIAEgCIAEAAIABAAIACAAIgBAHIgDgBQgGAAgBAEQgDAEAAAFIAAASg");
	this.shape_21.setTransform(110.975,8.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_22.setTransform(105.425,8.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgOAcIgDgBIABgFIACABIADAAQAAAAABAAQABAAAAgBQABAAAAAAQABAAAAgBIADgEIACgIIgQgkIAIAAIAKAcIAAAAIALgcIAHAAIgSAtIgBAEIgCAEIgEACIgEAAg");
	this.shape_23.setTransform(101.85,9.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_24.setTransform(97.775,8.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AALATIgLgcIAAAAIgJAcIgGAAIgNglIAHAAIAJAcIAKgcIAGAAIAJAcIAJgcIAHAAIgNAlg");
	this.shape_25.setTransform(92.8,8.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgCAeIAAg7IAFAAIAAA7g");
	this.shape_26.setTransform(88.9,6.975);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAUAcIgGgOIgbAAIgGAOIgIAAIAZg3IAGAAIAYA3gAALAIIgLgbIgLAbIAWAAg");
	this.shape_27.setTransform(85.175,7.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgCADQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgCg");
	this.shape_28.setTransform(79.075,9.575);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_29.setTransform(75.475,7.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_30.setTransform(70.925,8.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAAAXIgCgCIgBgEIgBgFIAAgTIgIAAIAAgGIAIAAIAAgKIAGAAIAAAKIALAAIAAAGIgLAAIAAARIAAADIAAADIACACIADABIADAAIADgCIAAAGIgEABIgDAAIgGgBg");
	this.shape_31.setTransform(67.275,7.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgFASIgGgEQgCgCgCgEIgBgIIABgHIAEgGIAGgEIAHgCQAFAAADACQAEABADADIgFAFIgFgEIgFgBIgEABIgEADIgCAFIgBAEIABAFIACAFIAEADIAEABQAHAAADgFIAFAFQgDADgEABIgIACIgHgCg");
	this.shape_32.setTransform(64.125,8.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_33.setTransform(59.875,8.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgJATIAAgbIgBgFIAAgEIAGAAIAAADIAAADIABAAIABgDIACgCIAEgCIAEAAIABAAIACAAIgBAHIgDgBQgGAAgBAEQgDAEAAAFIAAASg");
	this.shape_34.setTransform(56.475,8.075);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgCAcIAAgkIAFAAIAAAkgAgCgUQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAIACgBIAEABIABADIgBADQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQgBAAAAgBg");
	this.shape_35.setTransform(53.9,7.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_36.setTransform(50.475,7.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_37.setTransform(44.175,8.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgHATIgEgCIgDgEIgBgEQAAgFACgDIAGgDIAHgBIAHgBIADAAIAAgBQAAgEgDgCQgCgCgFAAIgFABIgFADIgEgEQADgDAEgBIAHgCQAIAAAEAEQAEAEAAAIIAAAPIAAAEIAAADIgGAAIAAgDIAAgDQgCADgDACQgDACgEAAIgFgBgAgFACQgEACAAAEQAAADADACQACABADAAIAEAAIAEgDIACgDIABgFIAAgCIgHAAQgFAAgDABg");
	this.shape_38.setTransform(40.375,8.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgIAdIgGgEIgEgGIgBgIIABgIIAEgFIAHgEQADgCAEAAQAEAAADACQAEACACADIAAgdIAHAAIAAA8IgHAAIAAgHIgFAGQgEACgEAAQgEAAgEgCgAgEgBIgFACIgCAFIgBAFIABAGIACAEIAFADIAEABIAGgBIAEgDIACgEIABgGIgBgFIgCgFIgEgCIgGgBIgEABg");
	this.shape_39.setTransform(33.675,7.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_40.setTransform(29.125,8.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgIASQgDgBgDgEIAFgEIAEAEIAFABIADAAIACgBIACgCIABgDIgBgCIgCgCIgCgBIgDgBIgEgBIgEgBIgDgDIgBgFIABgEQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAgBIAEgCIAFgBQAEAAADACQADACACADIgFAEIgDgEIgFgBIgBAAIgDABIgBACIgBACIABACIACACIADABIACABIAFABIAEABIADADIABAFQAAADgCACIgDAEIgFACIgFABQgEAAgEgCg");
	this.shape_41.setTransform(25.175,8.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgHASIgFgDQgCgCgBgDIAAgGIAAgWIAGAAIAAAVQAAAFACADQACACAEAAIAEgBIAEgDQAAAAABgBQAAAAAAgBQAAAAABgBQAAgBAAAAIABgFIAAgSIAGAAIAAAbIAAAFIABAEIgGAAIAAgDIAAgDIgBAAIgBADIgEACIgDACIgEAAIgFgBg");
	this.shape_42.setTransform(21.35,8.175);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAKATIAAgVQAAgFgCgDQgCgCgEAAIgFABIgDADIgCAEIgBAFIAAASIgGAAIAAgbIAAgFIAAgEIAGAAIAAADIAAADIAAAAIACgDIACgCIAEgCIADAAIAHABIAEADQACACABADIABAGIAAAWg");
	this.shape_43.setTransform(14.7,8.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgGASQgEgBgCgDIgEgGIgBgIIABgHQABgEADgCIAGgEQAEgCADAAQAEAAADACIAGAEIADAGIABAHIAAACIgdAAIABAFIADADIAEADIADABIAHgBQADgCACgDIAFAEQgDAEgEACQgEACgGAAQgDAAgDgCgAAMgCQAAgFgDgDQgDgDgGAAQgEAAgDADQgDADgBAFIAXAAIAAAAg");
	this.shape_44.setTransform(10.325,8.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAKAeIAAgWQAAgFgCgDQgCgBgEAAIgFABIgDACIgCAEIgBAGIAAASIgGAAIAAg7IAGAAIAAAcIAAAAIACgCIADgCIADgCIADAAIAGABIAFADQACACAAACIABAGIAAAXg");
	this.shape_45.setTransform(5.925,6.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAOAcIgOgvIgNAvIgIAAIgQg3IAHAAIAOAuIANguIAHAAIAOAuIANguIAHAAIgRA3g");
	this.shape_46.setTransform(-0.15,7.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_04, new cjs.Rectangle(-6,0,248,15), null);


(lib.copy_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AgKAbQgGgCgEgEQgEgEgDgGQgBgFAAgGQAAgFABgFQADgGAEgEQAEgEAGgCQAFgCAFAAQAGAAAGACQAFACAEAEQAEAEACAGQADAFAAAFQAAAGgDAFQgCAGgEAEQgEAEgFACQgGADgGgBQgFABgFgDg");
	this.shape.setTransform(250.45,70.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AglBNQgRgFgMgMIAeggQAHAJAHAEQAJAEALAAQAHAAAHgCQAHgDAAgGQgBgGgGgDQgFgDgJgCIgTgFQgKgCgKgFQgIgFgHgIQgFgIAAgPQgBgOAGgKQAGgKAJgGQAJgHAMgCQAMgEALAAQAPAAAQAFQAQAEAKAMIgdAdQgKgNgSAAQgFAAgFADQgHADAAAHQAAAFAHADIANAFIAUAEQALADAJAFQAIAFAGAIQAHAJAAAOQgBAPgGAKQgHAKgKAGQgKAGgNACQgNADgLAAQgRAAgQgFg");
	this.shape_1.setTransform(238.6,65.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("ABKBQIAAhaQAAgLgEgHQgFgIgMAAQgIAAgGACQgFADgEAFQgDAFgCAGIgBAOIAABRIgvAAIAAhRIAAgLIgDgLQgBgGgFgEQgEgDgIAAQgKAAgFADQgGADgDAGQgDAGgBAHIgBANIAABOIgwAAIAAibIAuAAIAAAVIABAAIAGgJIAKgIIANgFQAHgDAJAAQAQAAANAHQAMAHAGAOQAIgPAMgGQAMgHARAAQAQAAALAGQAKAFAGAJQAHAJADAMQACANAAAOIAABbg");
	this.shape_2.setTransform(217.625,65.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("Ag2BQIAAibIAwAAIAAAZIABAAQAHgOAKgHQALgIAQAAIAIABIAIABIAAAsIgKgCIgLgBQgOAAgIADQgIAEgEAHQgDAHgBAKIgCAUIAABBg");
	this.shape_3.setTransform(198.175,65.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgaBMQgQgGgLgLQgMgKgHgPQgHgPAAgTQAAgRAHgQQAHgPAMgKQALgLAQgGQAQgGARAAQAQAAAOAGQAOAGAJALQAKAKAFAPQAFAQAAARIAAAPIhvAAQADAOAKAIQAJAIAOAAQALAAAJgFQAIgFAGgJIAhAZQgLAPgSAIQgRAIgTAAQgRAAgQgGgAgLgrQgGACgEAEQgEAEgDAFQgCAGgBAFIA/AAQAAgMgIgIQgJgJgNAAQgHAAgGADg");
	this.shape_4.setTransform(182.125,65.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AguBxQgUgEgRgOIAbgnQALAJAMAFQANAGAOAAQAWAAAKgLQAKgLAAgQIAAgPIAAAAQgJALgMAFQgMAEgKAAQgRAAgOgGQgPgGgKgKQgKgLgFgOQgFgPAAgRQAAgPAEgPQAFgPAKgLQAJgLANgHQANgHAQAAQALAAAHACIAPAGIAMAIIAIAIIAAAAIAAgUIAsAAIAACNQAAAsgWAXQgWAXgsAAQgVAAgVgFgAgMhIQgHADgFAGQgGAFgDAHQgDAHAAAIQAAAHADAHQADAHAGAFQAFAGAHADQAGACAIAAQAIAAAHgCQAHgDAFgGQAGgFACgHQADgHAAgHQAAgIgDgHQgCgHgGgFQgFgGgHgDQgHgDgIAAQgIAAgGADg");
	this.shape_5.setTransform(162.675,69.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AguBKQgLgGgGgKQgHgJgCgOQgCgNAAgQIAAhVIAwAAIAABMIABANQAAAHADAHQACAGAFAEQAFADAJAAQAIAAAGgDQAGgDADgGQADgFABgIIABgNIAAhOIAwAAIAACbIguAAIAAgVIgBAAIgGAJIgKAIIgMAFQgIADgIAAQgSAAgMgGg");
	this.shape_6.setTransform(135.075,66.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgXB5IAAjxIAvAAIAADxg");
	this.shape_7.setTransform(122.05,61.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgcB7IAAh1IgfAAIAAgmIAfAAIAAgbQAAgNADgLQACgMAGgIQAHgJALgFQAMgFATAAIAPABIANACIgCApIgIgCIgIgBQgLAAgGAEQgGAFAAAQIAAAYIAkAAIAAAmIgkAAIAAB1g");
	this.shape_8.setTransform(112.625,61.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("Ag+BzQgPgEgLgJQgLgIgHgNQgHgNAAgRQAAgLAEgJQAEgKAGgIQAHgIAIgFQAJgGAKgEIgKgLIgIgMIgFgMQgCgHAAgIQAAgQAGgLQAGgLAKgHQAKgHANgDQANgDANAAQANAAALADQAMAEAJAHQAJAGAFALQAGAKAAAPQAAAKgEAIQgDAJgGAIQgFAHgIAGIgQAKIAdAfIAWgeIA4AAIgwA/IAzA1Ig+AAIgTgVQgOAOgQAHQgPAGgUAAQgQAAgOgEgAgtAWIgIAHIgGAJQgCAEAAAHQAAAGADAFQACAGAEADQAFAEAFACQAGACAFAAQAMAAAIgFIAPgMIgngrgAgjhKQgHAGAAAJQAAAFACAEIAFAHIAGAHIAGAGIAIgFIAJgHIAGgIQACgEAAgFQAAgKgGgFQgGgGgKAAQgJAAgGAGg");
	this.shape_9.setTransform(86.025,62.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgmB1QgPgGgKgLQgKgKgFgPQgFgPAAgRQAAgRAEgPQAFgOAKgLQAJgLANgIQANgGAQAAQAOAAAOAEQAMAFAJALIAAAAIAAhnIAwAAIAADxIgsAAIAAgVIAAAAIgIAJIgLAIIgOAGQgHACgHAAQgRAAgOgGgAgaANQgKALAAARQAAASAKALQALAKARAAQASAAAKgKQAKgLAAgSQAAgRgKgLQgKgLgSAAQgRAAgLALg");
	this.shape_10.setTransform(53.875,61.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgXB5IAAjxIAvAAIAADxg");
	this.shape_11.setTransform(40.45,61.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AghBMQgQgGgLgLQgMgKgHgPQgGgPAAgTQAAgRAGgQQAHgPAMgKQALgLAQgGQAQgGARAAQASAAAQAGQAPAGAMALQAMAKAHAPQAGAQAAARQAAATgGAPQgHAPgMAKQgMALgPAGQgQAGgSAAQgRAAgQgGgAgcgbQgKAKAAARQAAASAKALQALAKARAAQASAAAKgKQAKgLAAgSQAAgRgKgKQgKgLgSAAQgRAAgLALg");
	this.shape_12.setTransform(26.875,65.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgRBMQgQgGgLgLQgMgKgHgPQgHgPAAgTQAAgRAHgQQAHgPAMgKQALgLAQgGQAQgGARAAQAOAAAPAFQAOAFAMALIggAhQgDgFgHgDQgGgDgHAAQgSAAgJALQgLAKAAARQAAASALALQAJAKASAAQAHAAAGgDQAGgEAEgFIAgAiQgMALgOAFQgPAFgOAAQgRAAgQgGg");
	this.shape_13.setTransform(10.3,65.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgcB7IAAh1IgfAAIAAgmIAfAAIAAgbQAAgNADgLQACgMAGgIQAHgJALgFQAMgFATAAIAPABIANACIgCApIgIgCIgIgCQgLABgGAEQgGAFAAAQIAAAYIAkAAIAAAmIgkAAIAAB1g");
	this.shape_14.setTransform(195.875,21.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AghBMQgQgGgLgLQgMgKgHgPQgGgPAAgTQAAgRAGgQQAHgPAMgKQALgLAQgGQAQgGARAAQASAAAQAGQAPAGAMALQAMAKAHAPQAGAQAAARQAAATgGAPQgHAPgMAKQgMALgPAGQgQAGgSAAQgRAAgQgGgAgcgbQgKAKAAARQAAASAKALQALAKARAAQASAAAKgKQAKgLAAgSQAAgRgKgKQgKgLgSAAQgRAAgLALg");
	this.shape_15.setTransform(180.225,26.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AAAASIgQAYIgRgOIARgWIgbgIIAGgUIAbAKIAAgeIAVAAIAAAeIAbgJIAGATIgbAIIARAXIgRAOg");
	this.shape_16.setTransform(156.625,12.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AhNBuICBjpIAbAQIiEDngAA4BwQgMgFgIgIQgJgJgEgMQgGgLAAgOQAAgNAGgLQAEgMAJgIQAIgJAMgEQAMgFAMAAQAOAAAMAFQAKAEAJAJQAJAIAFAMQAEALAAANQAAAOgEALQgFAMgJAJQgJAIgKAFQgMAFgOAAQgMAAgMgFgAA7AgQgJAJAAAMQAAAOAJAIQAJAKAMAAQANAAAJgKQAJgIAAgOQAAgMgJgJQgJgJgNAAQgMAAgJAJgAhoAFQgMgFgIgIQgJgJgEgLQgGgMAAgNQAAgNAGgLQAEgMAJgJQAIgIAMgFQALgFANAAQAOAAALAFQAMAFAIAIQAJAJAFAMQAEALAAANQAAANgEAMQgFALgJAJQgIAIgMAFQgLAFgOAAQgNAAgLgFgAhlhKQgJAIAAANQAAANAJAJQAJAJAMAAQANAAAKgJQAIgJAAgNQAAgNgIgIQgKgKgNAAQgMAAgJAKg");
	this.shape_17.setTransform(137.4,22.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AgyBzIA0hRIgGACIgIABQgQAAgNgGQgOgGgJgKQgKgKgEgMQgGgOAAgPQABgSAGgOQAGgOAMgLQALgKAQgGQAPgFARAAQASAAAPAFQAQAGALAKQALALAHAOQAGAOABASQgBAMgCAKIgGASIgJARIgKARIgyBNgAgZg8QgLAKAAAPQAAAQALAKQAJAJAQAAQAQAAAKgJQALgKAAgQQAAgPgLgKQgKgKgQAAQgQAAgJAKg");
	this.shape_18.setTransform(113.85,22.475);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgLAbQgFgCgEgEQgEgEgDgGQgCgFAAgGQAAgFACgGQADgFAEgEQAEgEAFgCQAGgDAFAAQAGAAAGADQAFACAEAEQAEAEACAFQACAGABAFQgBAGgCAFQgCAGgEAEQgEAEgFACQgGACgGABQgFgBgGgCg");
	this.shape_19.setTransform(99.9,31.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AgyBzIA0hRIgGACIgIABQgRAAgNgGQgNgGgJgKQgJgKgGgMQgEgOAAgPQAAgSAGgOQAGgOAMgLQALgKAPgGQAQgFARAAQARAAAQAFQAPAGAMAKQALALAHAOQAHAOAAASQAAAMgDAKIgGASIgIARIgLARIgyBNgAgag8QgKAKAAAPQAAAQAKAKQAKAJAQAAQAQAAAKgJQAKgKAAgQQAAgPgKgKQgKgKgQAAQgQAAgKAKg");
	this.shape_20.setTransform(86.1,22.475);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgyBzIA0hRIgGACIgIABQgQAAgNgGQgOgGgJgKQgKgKgEgMQgGgOAAgPQABgSAGgOQAGgOAMgLQALgKAQgGQAPgFARAAQASAAAPAFQAQAGALAKQALALAHAOQAGAOABASQgBAMgCAKIgGASIgIARIgLARIgyBNgAgZg8QgLAKAAAPQAAAQALAKQAJAJAQAAQAQAAAKgJQALgKAAgQQAAgPgLgKQgKgKgQAAQgQAAgJAKg");
	this.shape_21.setTransform(67.5,22.475);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgXB5IAAjxIAvAAIAADxg");
	this.shape_22.setTransform(44.95,21.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgXB5IAAjxIAvAAIAADxg");
	this.shape_23.setTransform(36.95,21.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgXB0IAAiaIAvAAIAACagAgThEQgIgIAAgLQAAgMAIgIQAIgIALAAQALAAAJAIQAIAIAAAMQAAALgIAIQgJAJgLAAQgLAAgIgJg");
	this.shape_24.setTransform(28.975,22.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AAkBxIhbhrIAABrIgyAAIAAjhIAyAAIAABeIBXheIBBAAIhjBpIBsB4g");
	this.shape_25.setTransform(15.1,22.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_03, new cjs.Rectangle(0,0,257.1,87.4), null);


(lib.copy_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AAZBLIAAhIIAAgMQgBgHgCgFQgCgGgFgDQgFgEgIAAQgIAAgFADQgGADgDAFQgDAGAAAGIgBANIAABJIgtAAIAAiRIArAAIAAAUIABAAIAGgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAFAGAJQAGAJACANQACANAAAOIAABQg");
	this.shape.setTransform(235.575,94.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AgeBHQgPgFgMgKQgKgKgHgPQgGgNAAgSQAAgQAGgPQAHgOAKgJQAMgKAPgGQAOgFAQgBQARABAPAFQAOAGAMAKQALAJAGAOQAGAPAAAQQAAASgGANQgGAPgLAKQgMAKgOAFQgPAGgRgBQgQABgOgGgAgagZQgJAKAAAPQAAAQAJALQAKAKAQAAQARAAAJgKQAKgLAAgQQAAgPgKgKQgJgLgRAAQgQAAgKALg");
	this.shape_1.setTransform(217.7,94.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AgjBJQgPgFgLgMIAbgdQAGAHAIAEQAIAEAKAAQAHAAAGgCQAGgCAAgGQAAgFgFgEQgGgDgHgBIgSgFQgKgCgJgEQgIgFgGgHQgFgJAAgNQAAgNAFgKQAFgIAJgGQAIgHALgCQALgEALAAQAOABAPAEQAPAEAKALIgcAbQgKgMgQAAQgFAAgFACQgFADAAAGQAAAGAFADIANAEIATAEQAJADAJAEQAIAFAGAHQAFAJAAAOQAAANgGAKQgGAJgJAFQgKAGgMADQgMABgLAAQgPAAgQgDg");
	this.shape_2.setTransform(201.525,94.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AglBKQgJgDgHgGQgIgFgEgJQgEgJAAgLQAAgMAFgIQAEgKAIgEQAIgGAKgDQAKgDALgBIAVgCIAVAAQAAgNgJgHQgJgHgLAAQgKAAgJAFQgKAEgHAJIgYgZQANgMARgFQAQgHARAAQAUAAANAGQANAEAHAKQAIAKADANQADAPAAASIAABJIgpAAIAAgSIgBAAQgHALgNAGQgLAEgOAAQgKAAgKgCgAAFAKIgOACQgHACgFAFQgFADAAAIQAAAIAHAEQAHAEAHAAQAGAAAGgCQAGgBAFgEQAFgDADgGQADgFAAgGIAAgKIgMAAg");
	this.shape_3.setTransform(186.275,94.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("AgYBHQgPgFgLgKQgLgKgHgPQgGgNAAgSQAAgQAGgPQAHgOALgJQALgKAPgGQAOgFAQgBQAQABAMAFQANAGAJAKQAJAJAFAOQAFAPAAAQIAAAOIhoAAQADANAJAIQAJAIAMgBQALAAAIgEQAHgFAGgJIAgAYQgLANgRAIQgQAHgSAAQgQABgOgGgAAegPQAAgMgIgIQgIgIgMAAQgHAAgFACIgKAHQgEAEgCAEQgDAFAAAGIA7AAIAAAAg");
	this.shape_4.setTransform(169.725,94.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgjBJQgPgFgLgMIAbgdQAGAHAIAEQAIAEAKAAQAHAAAGgCQAGgCAAgGQAAgFgFgEQgGgDgHgBIgSgFQgKgCgJgEQgIgFgGgHQgFgJAAgNQAAgNAFgKQAFgIAJgGQAIgHALgCQALgEALAAQAOABAPAEQAPAEAKALIgcAbQgKgMgQAAQgFAAgFACQgFADAAAGQAAAGAFADIANAEIATAEQAJADAJAEQAIAFAGAHQAFAJAAAOQAAANgGAKQgGAJgJAFQgKAGgMADQgMABgLAAQgPAAgQgDg");
	this.shape_5.setTransform(154.075,94.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgrBGQgLgGgGgJQgFgJgCgNQgCgMAAgPIAAhQIAtAAIAABIIAAAMQABAHACAFQACAGAFAEQAEADAJAAQAIAAAFgDQAGgDACgFQADgFABgHIABgNIAAhJIAtAAIAACRIgrAAIAAgUIgBAAIgGAJIgJAHIgLAGQgHACgIAAQgSAAgKgFg");
	this.shape_6.setTransform(129.525,94.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgVBxIAAjiIAsAAIAADig");
	this.shape_7.setTransform(116.9,90.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2B3785").s().p("AgaBzIAAhuIgeAAIAAgjIAeAAIAAgZQAAgMACgLQACgLAGgIQAHgIAKgEQAKgFATAAIANAAIAOADIgCAmIgIgDIgIAAQgKAAgGAEQgFAFAAAOIAAAXIAhAAIAAAjIghAAIAABug");
	this.shape_8.setTransform(107.65,90.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2B3785").s().p("Ag6BsQgOgEgKgIQgLgIgGgMQgHgMAAgQQAAgKAEgJQADgJAGgIQAHgHAIgFQAIgGAJgDIgJgLIgIgKIgEgMQgCgHAAgIQAAgOAFgKQAGgKAJgHQAKgHAMgCQAMgEAMAAQANAAAKAEQALADAIAGQAJAHAFAJQAFAKAAAOQAAAJgDAIQgDAJgGAHQgFAHgHAFIgPAKIAbAcIAVgbIA0AAIgtA6IAwAyIg6AAIgSgUQgNAOgPAGQgOAGgTAAQgPAAgNgEgAgqAVIgHAGIgGAIQgCAFAAAGQAAAGACAFQADAFAEADQAEADAFACQAFACAFAAQALAAAIgEQAHgFAHgHIglgogAghhFQgGAFAAAJQAAAEACAEIAEAHIAGAGIAGAGIAHgFIAIgGIAGgIQACgEAAgEQAAgKgGgFQgGgFgIAAQgJAAgGAGg");
	this.shape_9.setTransform(81.925,91.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2B3785").s().p("AgkBuQgNgGgKgKQgJgKgFgOQgFgNAAgRQAAgPAEgOQAFgNAJgLQAIgLAMgGQANgHAPAAQANAAANAFQAMAEAIALIAAAAIAAhhIAtAAIAADiIgpAAIAAgTIgBAAIgHAHIgKAIIgNAFQgHACgHAAQgQAAgNgFgAgYAMQgJAKAAARQAAAQAJALQAKAKAQAAQARAAAJgKQAKgLAAgQQAAgRgKgKQgJgKgRAAQgQAAgKAKg");
	this.shape_10.setTransform(51.025,90.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2B3785").s().p("AgVBxIAAjiIAsAAIAADig");
	this.shape_11.setTransform(38.05,90.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B3785").s().p("AgeBHQgPgFgLgKQgMgKgFgPQgHgNAAgSQAAgQAHgPQAFgOAMgJQALgKAPgGQAOgFAQgBQARABAPAFQAPAGALAKQAKAJAHAOQAGAPAAAQQAAASgGANQgHAPgKAKQgLAKgPAFQgPAGgRgBQgQABgOgGgAgagZQgJAKAAAPQAAAQAJALQAKAKAQAAQARAAAJgKQAKgLAAgQQAAgPgKgKQgJgLgRAAQgQAAgKALg");
	this.shape_12.setTransform(24.9,94.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2B3785").s().p("AgQBHQgPgFgLgKQgLgKgGgPQgHgNAAgSQAAgQAHgPQAGgOALgJQALgKAPgGQAPgFAPgBQANABAOAEQAOAEAMALIgeAgQgEgFgFgEQgGgDgIAAQgQAAgJALQgKAKAAAPQAAAQAKALQAJAKAQAAQAIAAAGgEQAEgDAFgEIAeAfQgMALgOAFQgOADgNAAQgPABgPgGg");
	this.shape_13.setTransform(9,94.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B3785").s().p("AgjBJQgPgFgLgMIAbgdQAGAHAIAEQAIAEAKABQAHAAAGgDQAGgCAAgGQAAgGgFgDQgGgDgHgBIgSgFQgKgCgJgEQgIgFgGgHQgFgJAAgNQAAgNAFgKQAFgIAJgGQAIgHALgCQALgEALAAQAOAAAPAFQAPAEAKALIgcAbQgKgMgQAAQgFAAgFACQgFADAAAGQAAAGAFADIANAEIATAEQAJADAJAEQAIAFAGAIQAFAIAAANQAAAOgGAKQgGAJgJAFQgKAGgMACQgMACgLAAQgPAAgQgDg");
	this.shape_14.setTransform(223.525,59.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2B3785").s().p("AgWBtIAAiRIAsAAIAACRgAgRg/QgIgIAAgKQAAgLAIgIQAHgIAKAAQALAAAIAIQAHAIAAALQAAAKgHAIQgIAHgLABQgKgBgHgHg");
	this.shape_15.setTransform(212.6,56.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2B3785").s().p("AAZBxIAAhHIAAgNQgBgHgCgFQgCgGgFgDQgFgFgIAAQgIABgFADQgGADgDAFQgDAFAAAHIgBAOIAABIIgtAAIAAjiIAtAAIAABlIAAAAIAFgIIAJgHIALgGQAHgCAIAAQARAAALAFQAKAGAGAJQAGAJACAMQACANAAAOIAABQg");
	this.shape_16.setTransform(200.025,55.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2B3785").s().p("AAEBeQgIgCgIgGQgHgFgEgIQgEgJAAgMIAAhEIgdAAIAAgkIAdAAIAAgrIAsAAIAAArIAoAAIAAAkIgoAAIAAAwIAAALIAEAIQACAEAEACQAEACAIAAIAJgBQAGgBADgDIAAAmQgIADgIAAIgQABQgLAAgKgCg");
	this.shape_17.setTransform(184.95,57.725);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2B3785").s().p("AgjBJQgPgFgLgMIAbgdQAGAHAIAEQAIAEAKABQAHAAAGgDQAGgCAAgGQAAgGgFgDQgGgDgHgBIgSgFQgKgCgJgEQgIgFgGgHQgFgJAAgNQAAgNAFgKQAFgIAJgGQAIgHALgCQALgEALAAQAOAAAPAFQAPAEAKALIgcAbQgKgMgQAAQgFAAgFACQgFADAAAGQAAAGAFADIANAEIATAEQAJADAJAEQAIAFAGAIQAFAIAAANQAAAOgGAKQgGAJgJAFQgKAGgMACQgMACgLAAQgPAAgQgDg");
	this.shape_18.setTransform(163.125,59.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2B3785").s().p("AgYBHQgPgFgLgKQgLgKgHgPQgGgNAAgSQAAgQAGgPQAHgOALgJQALgKAPgGQAOgGAQAAQAQAAAMAGQANAGAJAKQAJAJAFAOQAFAPAAAQIAAAOIhoAAQADANAJAIQAJAIAMAAQALgBAIgEQAHgFAGgIIAgAXQgLANgRAIQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAHQgEADgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape_19.setTransform(147.525,59.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2B3785").s().p("AAZBLIAAhIIAAgMQgBgHgCgFQgCgGgFgDQgFgEgIAAQgIAAgFADQgGADgDAFQgDAGAAAGIgBANIAABJIgtAAIAAiRIArAAIAAAUIABAAIAGgJIAJgHIALgGQAHgCAIAAQARAAALAGQAKAFAGAJQAGAJACANQACANAAAOIAABQg");
	this.shape_20.setTransform(130.225,59.525);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2B3785").s().p("AgfBHQgPgFgLgKQgKgKgGgPQgHgNAAgSQAAgQAHgPQAGgOAKgJQALgKAPgGQAPgGAQAAQARAAAOAGQAPAGALAKQALAJAHAOQAGAPAAAQQAAASgGANQgHAPgLAKQgLAKgPAFQgOAGgRgBQgQABgPgGgAgZgZQgKAKAAAPQAAARAKAKQAJAKAQAAQARAAAKgKQAJgKAAgRQAAgPgJgKQgKgLgRAAQgQAAgJALg");
	this.shape_21.setTransform(112.35,59.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2B3785").s().p("AgkBuQgNgGgKgKQgJgKgFgOQgFgNAAgRQAAgPAEgOQAFgNAJgLQAIgLAMgGQANgHAPAAQANAAANAFQAMAEAIALIAAAAIAAhhIAtAAIAADiIgpAAIAAgTIgBAAIgHAHIgKAIIgNAFQgHACgHAAQgQAAgNgFgAgYAMQgJAKAAARQAAAQAJALQAKAKAQAAQARAAAJgKQAKgLAAgQQAAgRgKgKQgJgKgRAAQgQAAgKAKg");
	this.shape_22.setTransform(84.225,55.825);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2B3785").s().p("AgYBHQgPgFgLgKQgLgKgHgPQgGgNAAgSQAAgQAGgPQAHgOALgJQALgKAPgGQAOgGAQAAQAQAAAMAGQANAGAJAKQAJAJAFAOQAFAPAAAQIAAAOIhoAAQADANAJAIQAJAIAMAAQALgBAIgEQAHgFAGgIIAgAXQgLANgRAIQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAHQgEADgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape_23.setTransform(66.575,59.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2B3785").s().p("AgVBJIg9iRIAwAAIAkBjIABAAIAihjIAuAAIg6CRg");
	this.shape_24.setTransform(49.55,59.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2B3785").s().p("AgfBHQgOgFgMgKQgKgKgHgPQgGgNAAgSQAAgQAGgPQAHgOAKgJQAMgKAOgGQAPgGAQAAQARAAAOAGQAPAGAMAKQALAJAGAOQAGAPAAAQQAAASgGANQgGAPgLAKQgMAKgPAFQgOAGgRgBQgQABgPgGgAgZgZQgKAKAAAPQAAARAKAKQAJAKAQAAQARAAAJgKQAKgKAAgRQAAgPgKgKQgJgLgRAAQgQAAgJALg");
	this.shape_25.setTransform(31.95,59.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2B3785").s().p("AgVBxIAAjiIAsAAIAADig");
	this.shape_26.setTransform(18.8,55.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2B3785").s().p("AgyBLIAAiRIAtAAIAAAXIAAAAQAGgNAKgHQAKgHAPAAIAIABIAHABIAAApIgJgCIgKgBQgNAAgHAEQgIADgEAHQgDAGgBAJIgBATIAAA9g");
	this.shape_27.setTransform(207.075,24.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2B3785").s().p("AgrBGQgLgGgGgJQgFgJgCgNQgCgMAAgPIAAhQIAtAAIAABIIAAAMQABAHACAFQACAGAFAEQAEADAJAAQAIAAAFgDQAGgDACgFQADgFABgHIABgNIAAhJIAtAAIAACRIgrAAIAAgUIgBAAIgGAJIgJAHIgLAGQgHACgIAAQgSAAgKgFg");
	this.shape_28.setTransform(191.675,24.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2B3785").s().p("AgfBHQgOgFgMgLQgKgJgHgPQgGgNAAgSQAAgQAGgPQAHgNAKgKQAMgLAOgFQAPgGAQAAQARAAAOAGQAPAFAMALQALAKAGANQAGAPAAAQQAAASgGANQgGAPgLAJQgMALgPAFQgOAGgRgBQgQABgPgGgAgZgaQgKALAAAPQAAARAKAKQAJAKAQAAQARAAAKgKQAJgKAAgRQAAgPgJgLQgKgKgRAAQgQAAgJAKg");
	this.shape_29.setTransform(173.8,24.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2B3785").s().p("AhOBnIAGglQAKAFALAAQAIAAAEgBQAFgCADgEIAGgHIAEgLIADgIIhAiSIAxAAIAkBhIABAAIAghhIAvAAIhDCpIgIAVQgFAJgFAGQgHAGgKADQgJADgQAAQgSAAgQgGg");
	this.shape_30.setTransform(156.25,28.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2B3785").s().p("AAEBeQgIgCgIgGQgHgFgEgIQgEgJAAgMIAAhEIgdAAIAAgkIAdAAIAAgrIAsAAIAAArIAnAAIAAAkIgnAAIAAAwIABALIADAIQACAEAEACQAEACAHAAIAKgBQAGgBACgDIAAAmQgHADgIAAIgQABQgLAAgKgCg");
	this.shape_31.setTransform(132.5,22.725);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2B3785").s().p("AgQBHQgPgFgLgLQgLgJgHgPQgFgNgBgSQABgQAFgPQAHgNALgKQALgLAPgFQAOgGAQAAQANAAAOAFQAOAEALALIgdAfQgDgFgGgDQgHgDgHAAQgPAAgKAKQgKALAAAPQAAARAKAKQAKAKAPAAQAIAAAGgDQAEgEAFgEIAdAfQgLALgOAFQgOADgNAAQgQABgOgGg");
	this.shape_32.setTransform(119.9,24.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2B3785").s().p("AgYBHQgPgFgLgLQgLgJgHgPQgGgNAAgSQAAgQAGgPQAHgNALgKQALgLAPgFQAOgGAQAAQAQAAAMAGQANAFAJALQAJAKAFANQAFAPAAAQIAAAPIhoAAQADAMAJAIQAJAIAMAAQALgBAIgFQAHgFAGgHIAgAXQgLAOgRAHQgQAIgSgBQgQABgOgGgAAegQQAAgLgIgIQgIgIgMAAQgHAAgFACIgKAGQgEAEgCAFQgDAFAAAFIA7AAIAAAAg");
	this.shape_33.setTransform(103.425,24.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2B3785").s().p("AAEBeQgJgCgGgGQgIgFgEgIQgEgJAAgMIAAhEIgcAAIAAgkIAcAAIAAgrIAsAAIAAArIAnAAIAAAkIgnAAIAAAwIAAALIADAIQADAEAEACQAEACAHAAIAKgBQAFgBADgDIAAAmQgHADgIAAIgQABQgLAAgKgCg");
	this.shape_34.setTransform(88.35,22.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2B3785").s().p("AgeBHQgPgFgMgLQgKgJgHgPQgGgNAAgSQAAgQAGgPQAHgNAKgKQAMgLAPgFQAOgGAQAAQARAAAPAGQAOAFAMALQALAKAGANQAGAPAAAQQAAASgGANQgGAPgLAJQgMALgOAFQgPAGgRgBQgQABgOgGgAgagaQgJALAAAPQAAARAJAKQAKAKAQAAQARAAAJgKQAKgKAAgRQAAgPgKgLQgJgKgRAAQgQAAgKAKg");
	this.shape_35.setTransform(73.25,24.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2B3785").s().p("AgyBLIAAiRIAtAAIAAAXIAAAAQAGgNAKgHQAKgHAPAAIAIABIAHABIAAApIgJgCIgKgBQgNAAgHAEQgIADgEAHQgDAGgBAJIgBATIAAA9g");
	this.shape_36.setTransform(58.525,24.525);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2B3785").s().p("AhPBqIAAjTIBPAAQAQAAAOADQAPADALAHQALAIAHAMQAGAMAAATQAAATgGANQgGALgLAIQgKAHgPADQgOADgRAAIghAAIAABTgAgggPIAfAAIAMgBIAKgEQAFgDADgFQACgFAAgIQAAgIgDgFQgEgFgGgCQgGgDgHgBIgNgBIgYAAg");
	this.shape_37.setTransform(42.925,21.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_02, new cjs.Rectangle(-0.8,0,247.20000000000002,115), null);


(lib.copy_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("AiMCcIAAk3IB7AAQAeAAAcAKQAdAJAWATQAWAUANAdQANAdAAAnQABAogPAdQgQAegYATQgYATgdAJQgdAKgbAAgAhVBqIAqAAQAaAAAWgGQAXgGASgNQAQgMALgUQAJgUABgdQgBgbgIgUQgKgVgPgMQgQgNgVgGQgUgGgaAAIgzAAg");
	this.shape.setTransform(152.65,19.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2B3785").s().p("AhdCcIAAk3IA3AAIAAEFICEAAIAAAyg");
	this.shape_1.setTransform(125.175,19.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2B3785").s().p("AhCCYQgegMgWgVQgVgVgNgeQgMgeAAglQAAgkAMgfQANgeAVgWQAWgVAegMQAegMAkAAQAkAAAeALQAeALAXAWQAWAVAMAfQAMAeAAAlQAAAkgMAeQgMAegWAWQgXAVgeAMQgeAMgkABQgkAAgegMgAgrhoQgUAJgOAPQgOAPgHAUQgIAUAAAYQAAAYAIAVQAHAVAOAQQAOAPAUAJQAUAIAXAAQAYAAAUgIQAUgJAOgPQAOgQAHgVQAIgVAAgYQAAgYgIgUQgHgUgOgPQgOgPgUgJQgUgIgYAAQgXAAgUAIg");
	this.shape_2.setTransform(93.975,19.424);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2B3785").s().p("AgpCYQgfgMgVgVQgWgVgMgeQgNgeAAglQAAgkANgfQAMgeAWgWQAVgVAfgMQAegMAjAAQAfAAAcALQAbAMAYAbIgsAfQgRgSgQgGQgQgGgRAAQgXAAgTAIQgUAJgOAPQgOAPgIAUQgHAUAAAYQAAAYAHAVQAIAVAOAQQAOAPAUAJQATAIAXAAQATAAATgJQARgIAPgUIAuAgQgVAdgeANQgfAOgiAAQgjAAgegMg");
	this.shape_3.setTransform(61.4,19.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2B3785").s().p("Ag9CaQgbgKgTgXIAqgoQAKAPARAJQAQAIATAAQAIAAAKgCQAJgDAJgFQAHgFAFgIQAFgJAAgKQAAgRgLgKQgLgJgQgGIgigMQgUgGgQgKQgRgJgKgQQgMgRAAgcQAAgYAKgRQAKgSAQgMQAQgLAVgGQAUgGAVAAQAZAAAXAIQAXAHASASIgoAqQgJgNgOgGQgPgFgRAAIgSACQgIACgHAFQgIAFgFAHQgDAIAAALQgBAPALAJQAMAIAQAGIAiAMQATAGARAKQARAJAKARQALARAAAbQAAAZgJATQgKATgPAMQgPAMgWAGQgUAHgVAAQgeAAgbgKg");
	this.shape_4.setTransform(21.75,19.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2B3785").s().p("AgpA6IAehzIA1AAIglBzg");
	this.shape_5.setTransform(3.125,9.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2B3785").s().p("AgbCcIAAkFIhfAAIAAgyID1AAIAAAyIhfAAIAAEFg");
	this.shape_6.setTransform(-16.025,19.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2B3785").s().p("AgbCcIAAk3IA3AAIAAE3g");
	this.shape_7.setTransform(-34.725,19.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.copy_01, new cjs.Rectangle(-42.9,-11,213.5,64.1), null);


(lib.click = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#044F04").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.btn_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AARAkIgRgwIgPAwIgSAAIgZhHIATAAIAQAyIAAAAIAPgyIASAAIAQAyIAAAAIAPgyIASAAIgYBHg");
	this.shape.setTransform(87.025,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAjQgIgDgFgFQgFgFgDgGQgDgIAAgIQAAgHADgIQADgHAFgFQAFgEAIgDQAHgDAHAAQAIAAAHADQAIADAFAEQAFAFADAHQADAIAAAHQAAAIgDAIQgDAGgFAFQgFAFgIADQgHADgIAAQgHAAgHgDgAgIgTIgHAFIgEAHIgBAHIABAIIAEAHIAHAFQAEACAEAAQAFAAAEgCIAHgFIAEgHIABgIIgBgHIgEgHIgHgFQgEgCgFABQgEgBgEACg");
	this.shape_1.setTransform(76.475,20.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAYA1Ig0hRIAABRIgTAAIAAhpIAZAAIAzBNIAAhNIATAAIAABpg");
	this.shape_2.setTransform(65.975,19.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgkA0IADgQIAEABIAFABIAFgBIAEgCIACgDIADgFIADgJIgfhHIAUAAIAUAyIASgyIATAAIgiBXIgFAJIgEAGQgDACgFABQgEACgGAAQgHAAgHgCg");
	this.shape_3.setTransform(51.75,22.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSAiQgFgCgDgEQgDgEgBgFQgCgFAAgGIAAgsIASAAIAAAkIABAGIABAHQACADACACQADACAEABQAEAAADgCIAFgEIADgGIABgGIAAgnIASAAIAABHIgRAAIAAgLIgBAAQgCAFgGAEQgFAEgHAAQgIAAgFgDg");
	this.shape_4.setTransform(43.55,20.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmA1IAAhpIAoAAIAMABQAGABAEAEQAFADADAFQADAGAAAGQAAAKgGAGQgFAFgIADQAFABAEABQAFACADAEQADADABAEQACAFAAAFQAAAIgDAGQgEAGgFADQgGAEgHABIgOACgAgTAlIARAAIAHgBIAHgCQAEgBACgDQACgDAAgGQAAgIgFgEQgGgDgKAAIgSAAgAgTgJIARAAQAIAAAFgDQAFgFAAgFQAAgIgFgCQgFgEgKAAIgPAAg");
	this.shape_5.setTransform(34.675,19.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DA3F55").s().p("AphDNIAAmZITDAAIAAGZg");
	this.shape_6.setTransform(61,20.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_cta, new cjs.Rectangle(0,0,122,41), null);


(lib.bg_lightblue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C7E6F4").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_lightblue, new cjs.Rectangle(0,0,300,600), null);


(lib.bg_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B3785").s().p("A3bbWMAAAg2rMAu3AAAMAAAA2rg");
	this.shape.setTransform(150,175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_blue, new cjs.Rectangle(0,0,300,350), null);


(lib.spray_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.spray("synched",0);
	this.instance.setTransform(12.1,44,0.1793,0.1594,0,0,0,12,43.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:12.1,regY:44,scaleX:1,scaleY:1},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,88.1);


(lib.hand_spray_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hand_spray_png
	this.instance = new lib.hand_spray();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(31).to({_off:true},1).wait(6).to({_off:false},0).wait(18).to({_off:true},1).wait(19));

	// spray_01_png
	this.instance_1 = new lib.spray_anim("synched",0);
	this.instance_1.setTransform(130.65,21.15,1,0.3428,0,0,0,72.7,44.1);
	this.instance_1.alpha = 0.5781;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(30).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(18).to({startPosition:1},0).to({_off:true},1).wait(19));

	// spray_01_png
	this.instance_2 = new lib.spray_anim("synched",0);
	this.instance_2.setTransform(134.65,21.15,1.0533,1.2976,0,0,0,72.8,44);
	this.instance_2.alpha = 0.5781;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).wait(29).to({startPosition:2},0).to({_off:true},1).wait(6).to({_off:false,startPosition:0},0).wait(18).to({startPosition:0},0).to({_off:true},1).wait(19));

	// spray_01_png
	this.instance_3 = new lib.spray_anim("synched",0);
	this.instance_3.setTransform(130.65,21.15,1,1,0,0,0,72.7,44.1);
	this.instance_3.alpha = 0.5781;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(27).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(18).to({startPosition:1},0).to({_off:true},1).wait(19));

	// spray_01_png
	this.instance_4 = new lib.spray_anim("synched",0);
	this.instance_4.setTransform(130.65,21.15,1,1,0,0,0,72.7,44.1);
	this.instance_4.alpha = 0.5781;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).wait(30).to({startPosition:0},0).to({_off:true},1).wait(6).to({_off:false,startPosition:1},0).wait(18).to({startPosition:1},0).to({_off:true},1).wait(19));

	// Layer_8
	this.instance_5 = new lib.spray_mist("synched",0);
	this.instance_5.setTransform(154.3,26.8,0.5267,0.5267,0,0,0,150,150.1);
	this.instance_5.alpha = 0.3398;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).wait(27).to({startPosition:1},0).to({_off:true},1).wait(6).to({_off:false,startPosition:0},0).wait(18).to({startPosition:0},0).to({_off:true},1).wait(19));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-101.7,276.5,273.7);


(lib.germs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_18 = new cjs.Graphics().p("AREDYIgNgFQgIgDgEgDQgEgDADgLIgNgZQgKgTANAIQANAIAHgDQAGgDgJgUQgJgUAKgEQAJgEAJAFQAFACABAQQAIgKAHAFQAKAJADAIQAGANgGAAIgGgBQAAAAgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAIAJAKIAMALQADAHgBAGQgBAGgFADQgFADgGgCIgEgBIgDgBQgGgGgCABQgCABAAAFIABAIQAAAFgBABIgHADIgCAAIgGgBg");
	var mask_graphics_19 = new cjs.Graphics().p("AP0D7IgqgIQgZgFgMgHQgNgHAPgiQgKgQgYgyQgXgxApAQQAoAQAYgMQAXgLgVg2QgWg1AigOQAigPAeAJQAMAEgCArQAigeASAMQAhATAHAWQAMAjgVADIgRABQgJgBgBADQgBACAdAWQAfAXADAGQAKAQgHATQgGATgTALQgSALgUgEIgPgCIgJgCQgSgMgIADQgGADgBANIgBAYQgBAOgGAEQgRAKgJACQgGACgHAAIgNgBg");
	var mask_graphics_20 = new cjs.Graphics().p("AOlEdIhHgLQgpgHgVgKQgVgLAbg5QgQgagmhQQglhQBEAYQBEAYAogTQApgUgihWQgjhXA6gaQA6gaAyAOQAWAFgGBJQA6gzAeASQA3AgALAiQATA5gkAHIgdABQgPAAgCAFQgBACAwAiQAzAlAFAJQAPAagMAgQgMAfgfATQggASgigFIgYgDIgPgCQgfgTgNAGQgKAEgCAWIgDAoQgCAWgLAHQgdARgPAEQgMAEgOAAQgJAAgKgCg");
	var mask_graphics_21 = new cjs.Graphics().p("ANXFSIhjgOQg5gIgdgPQgegOAnhPQgWgkgzhuQg0htBfAgQBfAgA5gbQA5gdguh3Qgvh4BSgkQBSglBFASQAeAHgKBlQBThIArAYQBLAsAPAvQAaBPgzAJQgHACghABQgVAAgDAHQgBACBCAwQBGAxAIANQAVAkgSAsQgRArgtAaQgtAagugHIgigDQgTgBgDgBQgqgagSAIQgPAGgDAeIgEA3QgEAggQAJQgpAXgVAHQgRAFgUAAQgNAAgNgCg");
	var mask_graphics_22 = new cjs.Graphics().p("AMLGvIh/gRQhJgLglgRQgmgTAyhlQgcgthBiLQhBiLB6AoQB5AnBJgiQBKglg7iYQg6iYBpguQBpgwBZAWQAmAKgNCAQBqhdA3AfQBgA2ATA8QAgBkhBANQgJACgqABQgcABgEAJQgBADBVA8QBaA+AJARQAaAtgWA4QgXA3g5AiQg6Ahg8gIIgrgEQgZgBgDgCQg2ghgXALQgTAIgFAmQgDAwgCAWQgGAogTAMQg1AegbAJQgXAHgbAAQgPAAgQgCg");
	var mask_graphics_23 = new cjs.Graphics().p("ALAIKIiagUQhZgNgugVQgtgVA+h7Qgjg3hOioQhOioCUAwQCTAvBZgrQBZgshGi3QhGi4B/g5QCAg6BtAaQAvALgRCcQCBhxBDAlQB1BBAWBJQAnB5hPAPQgMACgzADQghAAgFALQgCAEBnBIQBtBLAMAUQAfA3gcBDQgbBEhGAoQhHAphIgKIg1gDQgegCgEgCQhBgogdANQgWAKgGAvQgEA5gEAbQgGAxgZAOQhAAlghAKQgcAJghAAQgSAAgTgCg");
	var mask_graphics_24 = new cjs.Graphics().p("AJ2JjIi1gXQhpgOg1gYQg1gaBJiQQgog/hcjFQhbjFCuA4QCtA3BogzQBpg0hSjWQhSjXCXhDQCWhFB/AeQA3ANgUC3QCYiFBOArQCKBMAaBVQAtCNhdATQgNADg8ACQgoABgGANQgCAFB5BUQB/BXAOAYQAlA/ghBQQghBPhSAwQhTAvhVgLIg+gEQgjgCgEgCQhNgugiAPQgaALgIA3QgFBDgEAgQgIA5gcAQQhMAsgmAMQgiALgnAAQgVAAgWgDg");
	var mask_graphics_25 = new cjs.Graphics().p("AItK7IjPgaQh4gPg9gdQg9gcBUilQguhJhojhQhnjhDGBAQDGA/B4g7QB5g8hej1Qhej1CthNQCthPCRAiQA/APgYDRQCwiYBZAxQCdBWAeBhQAzCihqAVQgQADhFADQgtABgGAPQgDAGCKBfQCSBkAQAbQAqBJgmBaQglBbhfA3QhfA3higNIhHgFQgogCgFgCQhYg1gnASQgeANgJA+QgFBNgFAlQgJBBghATQhXAygsAOQgnAMgtAAQgYAAgZgDg");
	var mask_graphics_26 = new cjs.Graphics().p("AHmMSIjpgdQiHgShEgfQhEggBei6Qg0hRh0j9Qh1j8DfBHQDfBGCHhCQCIhEhpkSQhpkUDChXQDDhZCkAmQBHARgcDqQDGirBkA3QCxBhAhBtQA6C1h4AZQgRADhOAEQgzABgHARQgDAGCbBrQCkBwASAfQAvBRgrBmQgqBmhrA9QhrA+hugOIhQgFQgtgCgFgDQhjg7gsAUQgiAPgKBGQgGBWgGApQgKBKglAVQhiA4gyAQQgsAOgzAAQgaAAgcgDg");
	var mask_graphics_27 = new cjs.Graphics().p("AGgNnIkDggQiVgThLgjQhMgjBpjOQg5haiBkYQiCkYD4BPQD3BOCWhKQCWhLhzkwQh1kxDYhhQDYhjC2AqQBPATgfEDQDbi9BvA8QDEBrAlB5QA/DJiEAbQgUAEhVAEQg5ABgIATQgDAGCsB3QC2B8ATAiQA0BagvBxQgvBxh3BEQh3BFh6gPQgXgDhBgDQgzgDgGgDQhthBgxAWQgmARgKBNQgIBggGAuQgMBRgoAXQhtA/g4ASQgxAPg5AAQgdAAgegDg");
	var mask_graphics_28 = new cjs.Graphics().p("AFbO6IkcgiQijgVhTgmQhTgnBzjhQg+hjiOkyQiNkzEQBXQEOBUClhQQClhTh/lOQh/lNDthrQDthsDHAtQBXAVgiEcQDwjQB6BDQDXB0ApCEQBFDdiSAdQgVAFheAEQg+ACgJAUQgDAHC8CCQDHCIAWAlQA5Big0B8Qg1B8iBBLQiDBMiGgRQgZgChIgEQg3gDgHgDQh4hHg1AYQgqASgMBVQgIBpgHAyQgMBZgtAZQh4BGg8ATQg2ARhAAAQgfAAghgEg");
	var mask_graphics_29 = new cjs.Graphics().p("AEXQMIkzglQiygWhagqQhbgqB+j0QhEhriZlNQialNEnBeQEnBbCyhXQC0hbiJlpQiKlrEBhzQECh2DYAxQBeAWglE1QEGjiCEBIQDqB/ArCPQBLDvieAgQgXAFhmAFQhDACgLAWQgDAIDNCNQDYCSAYApQA9Brg5CHQg4CGiNBSQiPBSiRgSQgbgDhOgEQg9gDgHgEQiChMg6AaQgtAUgNBcQgJBxgIA3QgOBggwAcQiCBLhCAVQg7AThFAAQgiAAgkgEg");
	var mask_graphics_30 = new cjs.Graphics().p("ADVRcQiLgRjAgWQjBgYhhgtQhigtCJkIQhKhzillmQillmE+BkQE+BiDAheQDChiiUmFQiTmGEVh9QEWh/DpA1QBlAXgoFNQEaj0CPBOQD8CIAvCaQBQECiqAjQgZAFhvAGQhIACgLAXQgEAJDdCYQDpCdAZAsQBDBzg+CRQg9CRiYBYQiZBZidgUQgdgChVgEQhBgEgHgEQiNhSg+AcQgxAVgOBkQgKB6gIA7QgPBog1AeQiMBRhHAWQhAAVhKAAQgkAAgngFg");
	var mask_graphics_31 = new cjs.Graphics().p("ACUSrQiVgSjOgYQjOgahogvQhpgwCSkbQhOh7ixl/QixmAFVBrQFVBpDPhlQDOhoiemhQidmiEoiGQEqiID6A4QBsAagrFkQEukFCZBTQEOCSAyCkQBWEUi2AmQgbAFh2AGQhOADgLAZQgEAJDsCiQD6CpAaAvQBIB7hCCbQhCCcijBeQikBfiogVQgggDhagEQhGgEgIgEQiWhYhDAeQg0AXgQBrQgKCCgJA/QgQBwg5AgQiWBXhMAYQhEAWhQAAQgnAAgpgFg");
	var mask_graphics_32 = new cjs.Graphics().p("ABUT4QiegTjcgZQjbgbhvgzQhwgzCcktQhUiDi8mYQi8mZFrBzQFrBvDdhsQDchvinm8Qipm8E8iPQE9iRELA8QBzAbgvF7QFDkWCjBYQEfCbA1CwQBcEljDAoQgcAGh+AHQhTACgMAbQgEAKD7CsQEKC0AdAyQBLCDhGClQhGCmiuBkQivBliygWQgigDhhgEQhKgEgIgEQighfhIAhQg3AYgRByQgLCLgJBDQgSB2g8AjQigBchRAaQhJAYhVAAQgpAAgsgGg");
	var mask_graphics_33 = new cjs.Graphics().p("AAVVEQingUjqgbQjogch2g2Qh2g2Clk/QhYiLjHmwQjHmxGBB5QGAB2DqhzQDqh2iynVQiynXFPiYQFQiaEbBAQB6AcgyGSQFWknCtBdQEwClA5C5QBhE3jPArQgeAGiFAHQhYADgNAcQgFALELC3QEaC+AeA1QBQCKhKCwQhLCvi4BqQi6Bsi9gXQgjgEhngEQhOgFgJgEQiqhkhMAiQg7AagRB5QgMCTgKBHQgTB+g/AkQiqBihWAcQhNAZhbAAQgrAAgvgGg");
	var mask_graphics_34 = new cjs.Graphics().p("AgnWPQiygWj2gcQj1geh9g4Qh8g6CulQQhdiSjSnJQjSnIGWB/QGWB9D3h5QD2h9i6nvQi9nxFjigQFiijEqBDQCBAeg0GoQFpk3C2BiQFBCtA8DEQBmFIjaAtQggAHiNAHQhcADgOAeQgFALEZDBQEqDJAgA3QBUCThOC5QhPC5jCBwQjEBxjIgYQgmgEhsgFQhTgEgJgEQizhqhQAkQg+AcgTB/QgNCbgKBLQgUCFhDAmQizBohbAdQhSAahgAAQgtAAgwgFg");
	var mask_graphics_35 = new cjs.Graphics().p("AhjXXQi7gXkDgdQkCgfiCg7QiEg9C4lhQhiiajcnfQjengGsCGQGqCDEEiAQEEiDjFoJQjGoKF1ioQF1irE5BGQCIAfg4G+QF8lHDABnQFRC2A/DOQBrFZjlAvQghAHiUAIQhhADgPAfQgFAMEnDLQE5DTAiA6QBZCahTDCQhTDDjMB2QjPB3jSgaQgngDhygFQhXgFgKgFQi8huhUAmQhCAdgTCFQgOCjgLBPQgVCLhGApQi9BthfAeQhWAchkAAQgwAAgzgGg");
	var mask_graphics_36 = new cjs.Graphics().p("AieYfQjEgYkPgfQkPghiIg9QiKhADBlyQhnihjnn2Qjnn3HACMQG/CJEQiGQERiJjPoiQjPojGHivQGGi0FJBJQCOAhg6HTQGOlXDIBsQFiC/BCDYQBwFpjwAxQgjAIibAIQhmADgPAhQgGAME2DUQFIDdAjA9QBdCihXDLQhXDMjWB8QjYB9jcgbQgqgEh3gFQhbgFgKgFQjGh0hYAoQhFAfgUCLQgOCrgMBTQgWCShJArQjGByhkAgQhbAdhpAAQgyAAg1gGg");
	var mask_graphics_37 = new cjs.Graphics().p("AjXZkQjNgZkcgfQkagiiPhBQiQhCDKmDQhsiojxoNQjxoMHTCRQHTCQEdiMQEdiQjYo5QjYo8GZi4QGYi7FXBMQCUAig9HoQGhlmDRBxQFyDHBEDhQB1F5j6A0QglAIijAIQhqAEgQAiQgFANFDDdQFWDnAlBAQBhCohaDVQhbDVjgCBQjiCDjmgcQgrgEh9gGQhfgEgLgGQjOh5hcAqQhIAggVCRQgPCzgMBXQgXCYhNAtQjPB3hoAhQhfAfhuAAQg0AAg3gHg");
	var mask_graphics_38 = new cjs.Graphics().p("AkQapQjVgakoghQkmgkiVhDQiVhFDSmTQhwivj7oiQj8ojHoCYQHmCVEoiSQEqiVjhpSQjhpTGqi/QGpjEFlBQQCbAjhAH8QGyl1DaB2QGBDOBIDrQB6GJkFA2QgnAIipAJQhvAEgQAkQgGANFRDnQFkDwAnBCQBlCwhfDdQheDejqCHQjrCIjwgdQgtgEiBgGQhkgFgLgGQjXh9hgArQhKAhgXCYQgQC6gMBaQgYCfhQAuQjYB9hsAiQhiAgh0AAQg2AAg6gGg");
	var mask_graphics_39 = new cjs.Graphics().p("AlHbrQjegbkzgiQkxglibhFQichIDbmjQh1i2kEo3QkGo4H7CdQH5CbE0iXQE1icjppoQjqprG7jHQG6jLFzBSQChAlhCIQQHDmEDjB7QGQDWBKD0QB/GZkQA4QgoAIiwAKQhzADgRAmQgGANFeDwQFzD6AoBFQBpC2hjDmQhiDnjzCMQj1CNj4geQgvgEiHgGQhngFgMgGQjfiDhkAtQhOAjgXCdQgQDCgNBdQgZClhUAxQjgCBhxAkQhlAhh5AAQg4AAg8gHg");
	var mask_graphics_40 = new cjs.Graphics().p("AmbcsQjmgbk+gkQk+gmighIQihhKDimzQh4i8kOpMQkPpNINCjQIMChE/ieQFBihjyp/QjzqBHMjPQHKjTGBBWQCnAmhFIkQHUmTDrB/QGfDeBND9QCDGokZA6QgqAJi2AJQh3AEgSAnQgHAOFsD4QGAEDApBIQBtC9hmDvQhmDvj8CRQj+CSkCgfQgwgEiMgGQhrgGgMgGQjoiHhnAvQhRAjgYCkQgRDJgOBhQgZCrhXAyQjoCGh0AlQhrAjh9AAQg6AAg+gIg");
	var mask_graphics_150 = new cjs.Graphics().p("AmbcsQjmgbk+gkQk+gmighIQihhKDimzQh4i8kOpMQkPpNINCjQIMChE/ieQFBihjyp/QjzqBHMjPQHKjTGBBWQCnAmhFIkQHUmTDrB/QGfDeBND9QCDGokZA6QgqAJi2AJQh3AEgSAnQgHAOFsD4QGAEDApBIQBtC9hmDvQhmDvj8CRQj+CSkCgfQgwgEiMgGQhrgGgMgGQjoiHhnAvQhRAjgYCkQgRDJgOBhQgZCrhXAyQjoCGh0AlQhrAjh9AAQg6AAg+gIg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_graphics_18,x:114.1416,y:21.7192}).wait(1).to({graphics:mask_graphics_19,x:119.4799,y:25.2126}).wait(1).to({graphics:mask_graphics_20,x:124.7435,y:28.6614}).wait(1).to({graphics:mask_graphics_21,x:129.9245,y:30.0988}).wait(1).to({graphics:mask_graphics_22,x:135.0222,y:27.4967}).wait(1).to({graphics:mask_graphics_23,x:140.0364,y:24.9371}).wait(1).to({graphics:mask_graphics_24,x:144.967,y:22.4203}).wait(1).to({graphics:mask_graphics_25,x:149.814,y:19.9461}).wait(1).to({graphics:mask_graphics_26,x:154.5774,y:17.5147}).wait(1).to({graphics:mask_graphics_27,x:159.2572,y:15.1259}).wait(1).to({graphics:mask_graphics_28,x:163.8533,y:12.7798}).wait(1).to({graphics:mask_graphics_29,x:168.3658,y:10.4765}).wait(1).to({graphics:mask_graphics_30,x:172.7946,y:8.2159}).wait(1).to({graphics:mask_graphics_31,x:177.1397,y:5.9979}).wait(1).to({graphics:mask_graphics_32,x:181.4012,y:3.8227}).wait(1).to({graphics:mask_graphics_33,x:185.5791,y:1.6902}).wait(1).to({graphics:mask_graphics_34,x:189.6733,y:-0.3996}).wait(1).to({graphics:mask_graphics_35,x:193.6838,y:-2.4467}).wait(1).to({graphics:mask_graphics_36,x:197.6107,y:-4.451}).wait(1).to({graphics:mask_graphics_37,x:201.4539,y:-6.4127}).wait(1).to({graphics:mask_graphics_38,x:205.2134,y:-8.3316}).wait(1).to({graphics:mask_graphics_39,x:208.8893,y:-10.2079}).wait(1).to({graphics:mask_graphics_40,x:209.4397,y:-3.539}).wait(110).to({graphics:mask_graphics_150,x:209.4397,y:-3.539}).wait(1).to({graphics:null,x:0,y:0}).wait(39));

	// Layer_5
	this.instance = new lib.germs_group();
	this.instance.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({_off:false},0).wait(132).to({_off:true},1).wait(39));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_36 = new cjs.Graphics().p("ALCKeQggABhdgFQhdgFA6ggQA6gfADgeQADgfhhgJQhhgJAHgrQAHgqAmgZQARgKA/AcQgQgzAhgMQA5gVAlAFQA+AIgNAXIgOASQgIAIAEADQABABA5gQQA8gRAMAAQAfAAAXASQAWARAAAZQAAAZgWARIgPANIgKAJQgiALgBAJQgCAIATAJIAjAOQATAJAAAJQAAAXgDAKQgFANgRAOIgwAlQgbAWgVAIQgEACgFAAQgTAAgegcg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AJcLbQhEACjGgLQjHgLB8hDQB8hDAHhBQAGhAjPgUQjPgUAPhbQAOhaBSg1QAkgWCHA8QgjhuBFgZQB7gtBPALQCFASgcAxQgEAHgZAeQgRATAHAGQADACB6giQCAglAZAAQBDAAAwAmQAwAlAAA1QAAA1gwAlIggAdQgRAQgEABQhHAYgEAVQgDAPAoATIBKAgQAqATAAASQAAAwgIAWQgKAdglAcIhlBRQg7AugsASQgIAEgLAAQgpAAhBg8g");
	var mask_1_graphics_38 = new cjs.Graphics().p("AH5MXQhoACktgQQksgRC8hmQC7hmAKhiQAKhik6geQk7geAYiJQAViKB9hPQA2giDNBaQg1ilBpgnQC7hEB4ARQDJAbgqBKQgGALgnAtQgaAdAMAJQAEAEC5g0QDCg4AnAAQBmAABIA5QBJA5AABPQAABQhJA5IgwArQgbAZgFACQhtAkgFAfQgFAYA9AcQBNAgAkARQA/AdAAAcQAABJgMAhQgQAsg3ArIiaB6QhZBGhDAcQgNAFgQAAQg/AAhihag");
	var mask_1_graphics_39 = new cjs.Graphics().p("AGZNRQiLADmQgWQmRgWD7iIQD6iIAOiCQAMiDmjgoQmkgoAfi3QAdi3CmhqQBJguERB5QhHjdCNgzQD4hbCgAWQEMAkg4BkQgIAOgzA8QgjAmAPANQAGAFD2hGQEDhKA0AAQCHAABhBMQBhBMAABqQAABrhhBLQgRAPgvArQgkAggHADQiRAxgHApQgGAgBRAlQBmAqAwAWQBUAoAAAkQAABigQAsQgVA7hKA5IjMCiQh3BehZAlQgSAIgUAAQhUAAiDh5g");
	var mask_1_graphics_40 = new cjs.Graphics().p("AE7OJQitAFnxgcQnzgbE4ipQE3iqARihQAQijoJgyQoLgyAojiQAkjlDOiEQBag5FUCYQhZkUCwg/QE1hxDGAbQFOAthGB8QgKAShABKQgsAwATAQQAIAFEyhWQFChcBAAAQCoAAB5BeQB4BeAACEQAACFh4BfQgWASg6A1QgtApgJAEQi0A7gIAzQgIAoBkAvQCAA0A8AbQBoAxAAAuQAAB5gUA3QgaBJhcBHQhrBUiTB1QiUB0huAvQgWAJgaAAQhoAAijiWg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AEoPAQjNAFpQggQpSghFzjJQFyjKAVjAQATjCptg7Qptg7AukOQArkQD2idQBrhEGUC0QhplHDRhMQFwiGDsAgQGNA1hTCUQgMAVhMBYQg0A5AWATQAJAHFshnQGAhuBMAAQDIAACQBxQCPBwAACdQAACeiPBxQgaAVhFBAQg2AxgKAEQjWBHgLA8QgIAwB3A3QCYA+BHAhQB8A6AAA2QAACRgYBBQgfBWhtBWQiABkiuCLQixCKiDA4QgaALgfAAQh8AAjCizg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AFWRCQjtAGqsglQqugmGtjpQGrjpAYjeQAWjfrNhFQrOhEA2k4QAyk7Ebi1QB8hOHTDQQh6l7DxhXQGpibESAmQHKA9hgCqQgOAZhYBmQg8BBAaAWQAKAIGlh3QG8h+BXAAQDoAAClCBQCmCCAAC1QAAC3imCCQgdAZhQBKQg+A4gMAFQj4BSgMBHQgKA1CKBBQCwBHBSAmQCPBDAAA/QAACngcBLQgkBkh9BjQiUBzjKChQjLCgiYBAQgeANgkAAQiPAAjgjPg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AGDTQQkNAHsFgqQsIgqHlkIQHjkHAbj7QAZj9sqhOQsshMA9liQA4ljFBjNQCMhYIPDrQiJmsERhjQHgivE1AqQIGBFhsDBQgQAchjBzQhEBKAeAZQALAJHciGQH1iQBjAAQEGAAC7CTQC7CTAADNQAADPi7CSQgiAdhaBTQhGA/gNAGQkYBdgOBQQgLA9CcBIQDGBRBdArQCiBMAABHQAAC9gfBUQgpByiOBvQinCDjkC2QjmC0isBIQgiAPgoAAQiiAAj9jqg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AGuVaQkqAItcgvQtfgvIbklQIZklAekXQAckZuFhWQuHhWBEmJQA/mLFkjkQCbhiJMEFQianbEwhuQIWjDFYAvQJABNh4DWQgSAghuB/QhMBTAhAbQANAKIRiVQItifBuAAQEjAADRCjQDQCjAADkQAADmjQCjQgmAfhkBdQhOBGgPAGQk3BogPBZQgNBECtBQQDdBbBnAvQC0BUAABPQAADSgjBfQgtB9ieB8Qi6CSj9DKQkADIi/BRQgmAQgtAAQi0AAkZkEg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AHYXgQlIAJuvg0Quzg0JQlBQJNlCAhkyQAek0vchfQvgheBLmwQBFmxGHj6QCqhsKFEfQiooKFNh5QJKjWF6A0QJ4BUiEDrQgTAjh6CMQhSBbAkAeQANALJFikQJkivB5AAQE/AADlCzQDkCzAAD6QAAD9jkCzQgpAihvBlQhVBOgRAHQlVBygQBhQgOBKC+BZQDyBjBxA0QDGBdAABWQAADngmBnQgyCKitCIQjMCgkWDeQkZDcjRBYQgrASgxAAQjFAAk1kdg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AIBZiQlkAJwBg4QwFg5KDldQKAldAklMQAhlPwyhnQw0hnBQnUQBLnXGpkQQC5h1K8E4Qi2o3FqiDQJ9joGZA4QKvBbiPEAQgVAliECYQhaBjAnAhQAPALJ3iyQKYi+CEAAQFbAAD4DDQD4DCAAEQQAAESj4DDQgtAlh4BuQhcBVgSAHQlzB8gSBpQgPBRDOBgQEIBsB6A4QDYBlAABeQAAD6gqBxQg2CWi9CTQjdCukuDxQkxDvjjBgQguATg1AAQjXAAlPk1g");
	var mask_1_graphics_47 = new cjs.Graphics().p("AIobfQl/AKxQg9QxTg8K0l4QKxl4AnlmQAjlpyEhvQyHhuBXn4QBQn7HKklQDHh+LyFQQjFpjGGiNQKuj6G5A9QLkBiibETQgXAoiNCkQhhBqAqAkQAQAMKojAQLKjMCOAAQF2AAELDSQELDRAAEkQAAEokLDRQgwAoiBB3QhkBbgTAHQmQCGgTBxQgQBYDeBnQEbB0CEA9QDoBsAABlQAAEOgtB5Qg6ChjLCfQjuC7lFEEQlJEBj0BoQgyAUg5AAQjnAAlplNg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AJOdYQmaALybhBQyghBLkmSQLhmRApl/QAmmCzUh2QzXh2BdobQBWoeHpk5QDViGMmFmQjSqMGgiXQLdkLHYBBQMWBpilEmQgYAriYCvQhnBxAtAmQARANLWjNQL8jaCYAAQGPAAEeDgQEdDgAAE4QAAE8kdDgQg0AriKB+QhqBhgVAJQmrCOgUB6QgSBdDuBvQEvB8CNBAQD4B0AABsQAAEhgxCBQg9CtjZCpQj/DIlcEWQlfETkFBuQg1AWg9AAQj3AAmClkg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AJzfNQmzALzlhFQzphEMRmrQMPmrArmWQApma0hh+Q0jh9Bio8QBcpAIHlMQDiiPNYF9Qjfq1G6ihQMLkbH0BEQNIBwivE4QgaAuihC6QhuB4AwApQASAOMEjaQMrjoChAAQGoAAEvDuQEwDuAAFMQAAFPkwDtQg3AuiSCHQhxBngWAJQnFCXgWCBQgSBjD8B2QFBCDCWBFQEHB7AABzQAAEygzCKQhCC3jmC0QkODUlxEnQl1EkkWB2Qg4AXhBAAQkGAAmal6g");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAKWAg9QnMAM0rhIQ0whJM+nDQM6nCAvmuQAqmw1qiGQ1uiEBopdQBhpgIkleQDviYOIGTQjsrcHUiqQM2krIRBIQN3B2i5FKQgbAwiqDFQh0B/AyAqQATAQMvjmQNZj1CqAAQHAAAFBD7QFAD7AAFfQAAFilAD7Qg6AwibCOQh3BtgYAJQneCggYCJQgTBoELB8QFTCMCfBIQEWCCAAB5QAAFEg2CRQhGDCjzC+QkeDgmGE4QmKE0klB8Qg7AZhFAAQkVAAmxmQg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAK4AipQnjAN1whMQ10hNNpnZQNlnaAwnEQAtnH2xiLQ22iLBup8QBlqAJBlwQD7ifO2GmQj3sBHriyQNhk7IsBMQOkB8jCFbQgdAzizDPQh5CFA0AtQAVAQNYjyQOGkCCyAAQHXAAFREIQFREIAAFxQAAF0lREIQg9AziiCVQh+BzgYAJQn4CpgYCPQgVBuEZCDQFlCSCmBMQElCJAAB/QAAFVg5CYQhJDMkADIQktDrmaFIQmeFEk0CDQg+AahJAAQkjAAnHmlg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EALZAkRQn6AO2xhQQ22hQOSnwQONnwAznZQAvnc32iTQ36iRBzqaQBqqdJcmCQEHinPjG7QkDsmICi6QOJlKJGBQQPRCCjMFrQgeA1i7DZQh/CLA3AvQAVAROBj9QOvkOC7AAQHtAAFhEUQFhEVAAGCQAAGFlhEVQhAA1iqCcQiDB4gaAKQoPCxgZCWQgWBzEmCJQF2CZCuBQQEyCPAACFQAAFkg8CgQhMDVkMDSQk6D2muFXQmxFUlDCIQhBAbhMAAQkxAAncm4g");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAL4Al1QoQAO3vhTQ31hUO5oFQO1oFA1ntQAxnx44iZQ47iYB3q2QBvq6J2mTQESitQOHNQkPtIIZjCQOwlYJfBTQP7CIjVF6QgfA4jDDhQiFCSA5AxQAXAROnkIQPYkZDDAAQICAAFwEgQFwEgAAGTQAAGXlwEgQhCA3iyCjQiJB9gbALQolC4gbCcQgWB5EyCOQGGCgC1BTQFACVAACLQAAF0g+CnQhQDekXDbQlIEAnAFmQnEFilRCPQhEAchPAAQk+AAnxnLg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAMWAnVQokAO4shXQ4xhWPfoaQPaoaA3oAQAzoE52ifQ57ieB8rSQB0rVKOmjQEei1Q2HhQkZtqItjKQPWllJ3BWQQjCNjeGJQggA6jLDrQiKCXA8AzQAXASPMkSQP/klDLAAQIWAAF/EsQF+ErAAGjQAAGml+EsQhFA6i5CpQiOCCgcALQo7C/gcCjQgXB9E+CUQGVCmC9BXQFMCbAACQQAAGDhBCtQhTDnkiDjQlVELnRF0QnWFwleCUQhHAehSAAQlKAAoFndg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAMzAowQo5AP5khaQ5rhaQDotQP+otA5oTQA0oX6yilQ63ijCBrsQB4rwKmmyQEoi7RdHxQkjuJJBjRQP5lyKPBZQRJCSjlGYQgiA8jSDzQiPCdA+A0QAYATPvkcQQkkvDSAAQIqAAGME2QGNE3AAGxQAAG2mNE3QhHA7i/CwQiUCHgdALQpQDGgdCpQgXCBFJCaQGkCsDEBaQFYCgAACWQAAGQhDC0QhWDvktDsQlhEVniGBQnnF9lrCaQhKAehVAAQlWAAoXnug");
	var mask_1_graphics_56 = new cjs.Graphics().p("EANOAqHQpLAP6chcQ6hhdQlpAQQgpAA7olQA2oo7riqQ7wiqCFsFQB7sIK9nBQEyjBSCICQktunJVjZQQbl+KkBcQRuCXjtGlQgiA+jZD7QiUCjBAA2QAYATQSkmQRHk5DZAAQI8AAGaFBQGZFBAAHAQAAHFmZFAQhKA+jGC2QiYCLgeAMQpkDMgeCuQgYCHFUCeQGyCyDLBdQFjCmAACaQAAGehFC6QhZD3k3DzQltEenyGPQn3GKl3CeQhMAghYAAQliAAopn/g");
	var mask_1_graphics_57 = new cjs.Graphics().p("EANoAraQpdAQ7QhgQ7VhgRFpRQRBpSA9o1QA4o68iivQ8nivCJscQCAshLSnOQE7jHSmIRQk2vEJnjfQQ7mKK5BfQSRCcj0GyQgkBAjgEDQiYCnBCA4QAZAUQxkvQRplDDgAAQJOAAGmFLQGmFLAAHOQAAHSmmFKQhMBAjMC7QidCQgfAMQp2DTgfCzQgZCLFfCjQG/C3DRBgQFuCrAACfQAAGrhHC/QhcD/lAD7Ql5EnoBGaQoHGWmDCkQhNAghbAAQltAAo6oOg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EAOBAsoQpvAR8AhjQ8HhiRkpiQRfpjA/pFQA5pK9Vi0Q9bi0COszQCCs3LnncQFEjMTIIgQk/vfJ5jlQRZmWLNBiQSyCgj7G/QglBBjmELQidCsBEA5QAaAURQk3QSIlMDnAAQJeAAGyFUQGyFUAAHcQAAHfmyFUQhOBBjRDBQijCTgfANQqIDZggC4QgaCOFpCoQHMC9DXBiQF4CwAACkQAAG3hJDEQheEGlKECQmDEwoQGlQoVGimOCoQhQAihdAAQl3AApKoeg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EAOYAtzQp/AQ8vhkQ82hlSCpzQR8pyBApVQA7pZ+Gi5Q+Li4CRtIQCGtNL6noQFMjSToIvQlHv5KJjrQR3mgLfBlQTRCkkCHKQglBDjsERQihCxBFA6QAbAVRsk/QSnlUDsAAQJvAAG9FcQG9FdAAHoQAAHsm9FcQhQBEjXDFQimCYggAMQqaDfggC9QgbCSFyCsQHZDCDcBlQGCC0AACpQAAHBhLDKQhhENlSEJQmNE3oeGxQojGsmYCtQhSAihgAAQmAAApaorg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EAOuAu5QqOAR9bhnQ9ihoSdqBQSYqBBCpjQA8po+0i9Q+6i8CUtdQCKthMMnzQFVjXUFI8QlPwSKZjwQSSmrLwBoQTvCokIHVQgmBFjyEXQilC1BIA8QAbAWSHlHQTEldDyAAQJ9AAHIFlQHIFlAAH0QAAH3nIFlQhSBFjcDLQirCaghANQqpDkghDCQgbCWF7CwQHjDGDiBnQGLC5AACtQAAHMhNDPQhjETlaEPQmWE/orG7QoxG3mhCwQhUAjhiAAQmKAApoo4g");
	var mask_1_graphics_61 = new cjs.Graphics().p("EAPDAv6QqdAS+EhpQ+MhqS4qPQSxqQBDpwQA+p1/fjCQ/ljACXtwQCMt0Men+QFcjcUhJJQlWwoKnj2QSsm0MBBqQULCrkOHgQgnBGj3EeQipC5BJA9QAcAWShlOQTelkD3AAQKMAAHSFtQHRFtAAH+QAAIDnRFtQhVBGjgDPQiuCegiANQq4DpgiDGQgcCZGDC0QHvDLDmBpQGUC9AACwQAAHXhPDTQhlEZlhEVQmgFGo3HFQo9HAmqC1QhWAkhkAAQmTAAp1pGg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EAPWAw4QqqAS+rhsQ+yhrTPqdQTKqcBFp9UAA/gKCggIgDFUggOgDFACbgOBQCPuGMtoIQFjjgU8JUQldw9K1j7QTDm9MRBsQUkCvkTHpQgoBIj8EjQisC9BLA/QAdAWS4lVQT3lrD8AAQKZAAHbF0QHbF0AAIJQAAINnbF0QhWBIjlDTQiyChgiAOQrGDtgiDKQgdCcGLC4QH4DPDrBrQGcDBAAC0QAAHghQDXQhnEflpEbQmoFMpCHOQpIHJmzC4QhYAlhmAAQmbAAqCpRg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EAPoAxxQq2AT/PhuQ/XhuTmqoQTgqpBGqJUABAgKNggtgDJUgg0gDIACegOSQCSuWM8oSQFpjkVVJfQlkxRLCkAQTanEMfBtQU8CykYHyQgpBJkAEpQivDABMBAQAdAXTOlbQUPlyEBAAQKkAAHkF7QHkF7AAISQAAIXnkF7QhXBJjqDXQi0CkgjAOQrTDygjDOQgeCeGTC8QIBDSDvBtQGkDFAAC3QAAHohSDcQhpEklvEgQmwFSpNHXQpSHSm8C7QhZAlhoAAQmiAAqOpcg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EAP4AymQrBAT/xhvQ/3hwT6q0QT1q0BHqUUABCgKYghRgDMUghWgDLACggOhQCUumNKobQFvjoVsJqQlqxkLOkEQTunMMtBwQVSC1kcH6QgqBKkFEuQixDDBNBBQAdAXTjlhQUll4EEAAQKwAAHsGCQHsGBAAIbQAAIfnsGCQhZBKjtDaQi4CogjAOQrfD2gkDRQgeChGaC/QIJDVDzBwQGrDIAAC5QAAHxhTDfQhqEpl2ElQm3FYpXHeQpcHanDC+QhbAmhpAAQmqAAqZpmg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EAQIAzXUgLMAATggQgBxUggWgBxAUOgK/QUIq+BIqeUABCgKighwgDPUgh3gDPACjgOvQCWuzNXojQF1jsWAJzQlvx1LYkIQUCnSM5BxQVnC4khICQgqBLkJEyQi1DGBPBCQAeAYT2lmQU4l+EJAAQK6AAHzGHQH0GHAAIjQAAIon0GHQhaBMjxDdQi6CqgkAOQrrD6gkDUQgeCkGfDBQISDZD3BxQGxDLAAC9QAAH4hUDiQhtEul7EpQm9FdpgHmQpmHhnJDBQhcAmhsAAQmvAAqjpvg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EAQWA0EUgLWAATggrgBzUggzgByAUggLIQUZrIBJqnUABDgKrgiOgDTUgiUgDRAClgO7QCZvBNioqQF6jvWTJ7Ql0yELikMQUUnZNDBzQV6C6kkIJQgrBNkME2Qi3DJBPBDQAeAYUHlrQVLmDEMAAQLEAAH6GMQH6GNAAIqQAAIvn6GNQhcBMj0DhQi9CsgkAOQr1D9gkDXQgfCnGlDEQIZDbD6BzQG3DOAAC/QAAH/hVDlQhuEymAEtQnEFipoHsQpuHnnQDEQhdAnhtAAQm1AAqsp3g");
	var mask_1_graphics_67 = new cjs.Graphics().p("EAQiA0sUgLeAAUghFgB1UghMgB0AUwgLQQUprRBKqvUABEgKzgiogDVUgivgDUACngPHQCavMNtoxQF+jyWlKDQl4ySLrkPQUjnfNNB0QWLC9koIPQgrBNkQE7Qi5DLBQBEQAfAYUXlwQVamHEQAAQLMAAIBGRQIAGRAAIxQAAI2oAGSQhdBNj3DjQi/CuglAPQr+EAglDaQgfCoGqDGQIfDfD+B0QG8DQAADBQAAIGhWDoQhwE2mEEwQnJFmpwHyQp2HunVDGQheAnhuAAQm7AAq1p/g");
	var mask_1_graphics_68 = new cjs.Graphics().p("EAQuA1QUgLnAAUghbgB2UghjgB1AU+gLYQU3rYBLq3UABFgK7gjAgDXUgjHgDWACpgPRQCcvXN2o3QGDj0W0KKQl9yfLzkSQUxnkNXB2QWaC+krIVQgsBOkSE+Qi7DNBRBFQAfAYUklzQVqmMESAAQLUAAIGGVQIGGWAAI3QAAI8oGGWQheBOj5DmQjCCwglAOQsGEDglDcQgfCqGuDJQIlDhEAB1QHBDSAADEQAAILhXDqQhwE5mJE0QnOFqp2H3Qp9HznaDIQhgAohvAAQm/AAq8qGg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EAQ4A1wUgLuAAUghvgB3Ugh3gB2AVLgLfQVDrfBMq9UABFgLBgjVgDZUgjbgDZACqgPaQCdvgN/o8QGGj3XCKQQmAyqL6kUQU9noNfB2QWoDAkvIaQgsBPkVFBQi9DPBSBFQAgAZUxl3QV2mQEVAAQLbAAIKGaQILGZAAI8QAAJCoLGZQheBPj8DoQjDCygmAOQsNEGgmDeQgfCsGyDKQIqDjEDB2QHFDUAADGQAAIQhYDtQhxE7mNE3QnSFtp8H8QqDH4nfDKQhgAohwAAQnEAArCqMg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EARAA2MUgLzAAUgiBgB4UgiIgB3AVVgLlQVPrlBMrCUABGgLIgjngDaUgjugDaACsgPjQCevoOGpAQGKj5XNKVQmDyzMAkXQVInsNmB3QWzDCkwIeQgtBQkXFDQi/DRBTBGQAgAZU7l6QWCmTEXAAQLgAAIPGdQIPGcAAJBQAAJGoPGdQhfBPj+DqQjFCzgmAPQsTEIgmDgQggCtG2DMQIvDkEEB4QHJDWAADGQAAIVhZDuQhyE/mQE5QnWFwqBIAQqHH7njDMQhhAphxAAQnIAArIqRg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EARIA2jUgL5AAUgiPgB4UgiXgB4AVegLqQVYrqBNrHUABGgLMgj2gDdUgj9gDbACsgPpQCgvvOMpEQGMj7XYKaQmGy7MFkZQVRnvNsB4QW9DDkzIiQgsBQkaFFQi/DTBTBGQAgAZVEl9QWLmVEZAAQLmAAISGfQITGgAAJFQAAJJoTGgQhgBQj/DrQjGC1gnAPQsYEJgnDhQggCuG5DOQIzDmEGB4QHMDYAADIQAAIYhZDwQhzFAmTE8QnZFyqGIEQqMH/nlDNQhiAphyAAQnKAArNqWg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EAROA22UgL9AAUgibgB5UgijgB4AVmgLuQVfrvBNrKUABHgLQgkDgDeUgkKgDcACugPvQCgv0ORpIQGOj8XgKeQmIzCMKkaQVZnzNwB5QXFDEk0IlQgtBRkbFHQjBDTBUBHQAgAZVMl/QWSmXEbAAQLqAAIVGhQIVGiAAJIQAAJNoVGiQhgBRkBDsQjIC2gmAPQsdEKgnDjQggCvG8DPQI1DnEIB5QHODYAADKQAAIahaDyQhzFCmVE9QncF1qJIHQqPIBnpDOQhiAphzAAQnNABrQqag");
	var mask_1_graphics_73 = new cjs.Graphics().p("EARSA3FUgMAAAUgikgB5UgisgB5AVrgLyQVlrxBOrOUABHgLTgkNgDeUgkTgDeACugPzQChv4OVpKQGQj9XmKgQmKzHMNkbQVfn1N0B6QXLDFk1InQguBRkcFIQjBDVBUBGQAgAaVSmBQWYmZEcAAQLtAAIYGkQIXGjAAJLQAAJPoXGkQhhBRkCDtQjIC2gnAPQsgEMgnDkQggCwG9DPQI4DpEIB5QHRDZAADKQAAIdhaDzQh0FEmXE+QneF2qLIJQqTIEnqDPQhjAphzAAQnPAArUqcg");
	var mask_1_graphics_74 = new cjs.Graphics().p("EARWA3QUgMDAAUgirgB6UgizgB5AVwgL0QVpr0BOrQUABHgLVgkUgDfUgkagDeACvgP2QCiv7OXpNQGRj9XrKiQmLzLMPkcQVjn2N3B6QXQDGk3IoQgtBSkdFJQjCDVBUBHQAgAZVWmBQWdmbEdAAQLvAAIZGlQIZGlAAJMQAAJSoZGkQhhBSkDDuQjJC2gmAQQsjEMgnDlQggCwG+DQQI6DpEJB6QHSDaAADLQAAIehaD0Qh1FEmYFAQnfF3qNIKQqVIFnsDQQhjAqhzAAQnQAArWqeg");
	var mask_1_graphics_75 = new cjs.Graphics().p("EARYA3WUgMEAAUgivgB6Ugi3gB6AVygL0QVsr1BOrSUABHgLWgkYgDgUgkegDeACvgP4QCiv9OZpNQGSj+XtKjQmLzNMQkdQVln2N5B5QXSDHk3IpQgtBSkeFKQjCDVBUBHQAhAaVYmCQWfmcEeAAQLwAAIaGmQIbGlAAJOQAAJSobGmQhhBRkDDvQjJC2gnAQQskENgnDlQghCwHADRQI6DpEKB6QHTDbAADLQAAIfhbD0Qh0FFmZFAQngF4qPILQqVIHntDQQhjAph0AAQnRAArXqfg");
	var mask_1_graphics_76 = new cjs.Graphics().p("EARYA3YUgMEAAUgiwgB6Ugi4gB6AVzgL1QVsr1BOrSUABHgLXgkZgDgUgkggDeACvgP5QCjv9OZpOQGSj+XvKkQmMzOMRkdQVmn3N5B6QXTDGk3IqQguBSkdFKQjDDVBVBIQAgAZVZmCQWhmcEdAAQLxAAIaGmQIbGmAAJNQAAJTobGmQhhBRkEDvQjJC3gnAPQskEOgnDlQghCwHADRQI7DqEKB6QHTDaAADLQAAIghaD0Qh1FGmZFAQngF4qQIMQqVIGnuDQQhjAqh0AAQnRAArYqgg");
	var mask_1_graphics_150 = new cjs.Graphics().p("EARYA3YUgMEAAUgiwgB6Ugi4gB6AVzgL1QVsr1BOrSUABHgLXgkZgDgUgkggDeACvgP5QCjv9OZpOQGSj+XvKkQmMzOMRkdQVmn3N5B6QXTDGk3IqQguBSkdFKQjDDVBVBIQAgAZVZmCQWhmcEdAAQLxAAIaGmQIbGmAAJNQAAJTobGmQhhBRkEDvQjJC3gnAPQskEOgnDlQghCwHADRQI7DqEKB6QHTDaAADLQAAIghaD0Qh1FGmZFAQngF4qQIMQqVIGnuDQQhjAqh0AAQnRAArYqgg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(36).to({graphics:mask_1_graphics_36,x:89.6159,y:69.7964}).wait(1).to({graphics:mask_1_graphics_37,x:101.105,y:79.0837}).wait(1).to({graphics:mask_1_graphics_38,x:112.3034,y:88.1359}).wait(1).to({graphics:mask_1_graphics_39,x:123.2108,y:96.953}).wait(1).to({graphics:mask_1_graphics_40,x:133.8274,y:105.5349}).wait(1).to({graphics:mask_1_graphics_41,x:136.9006,y:113.8817}).wait(1).to({graphics:mask_1_graphics_42,x:133.4659,y:114.3212}).wait(1).to({graphics:mask_1_graphics_43,x:130.1308,y:113.155}).wait(1).to({graphics:mask_1_graphics_44,x:126.8952,y:112.0236}).wait(1).to({graphics:mask_1_graphics_45,x:123.7592,y:110.927}).wait(1).to({graphics:mask_1_graphics_46,x:120.7227,y:109.8651}).wait(1).to({graphics:mask_1_graphics_47,x:117.7858,y:108.8382}).wait(1).to({graphics:mask_1_graphics_48,x:114.9485,y:107.846}).wait(1).to({graphics:mask_1_graphics_49,x:112.2107,y:106.8886}).wait(1).to({graphics:mask_1_graphics_50,x:109.5724,y:105.9661}).wait(1).to({graphics:mask_1_graphics_51,x:107.0338,y:105.0783}).wait(1).to({graphics:mask_1_graphics_52,x:104.5946,y:104.2254}).wait(1).to({graphics:mask_1_graphics_53,x:102.2551,y:103.4073}).wait(1).to({graphics:mask_1_graphics_54,x:100.015,y:102.624}).wait(1).to({graphics:mask_1_graphics_55,x:97.8746,y:101.8755}).wait(1).to({graphics:mask_1_graphics_56,x:95.8337,y:101.1618}).wait(1).to({graphics:mask_1_graphics_57,x:93.8923,y:100.483}).wait(1).to({graphics:mask_1_graphics_58,x:92.0505,y:99.8389}).wait(1).to({graphics:mask_1_graphics_59,x:90.3083,y:99.2297}).wait(1).to({graphics:mask_1_graphics_60,x:88.6656,y:98.6553}).wait(1).to({graphics:mask_1_graphics_61,x:87.1225,y:98.1157}).wait(1).to({graphics:mask_1_graphics_62,x:85.6789,y:97.6109}).wait(1).to({graphics:mask_1_graphics_63,x:84.3349,y:97.1409}).wait(1).to({graphics:mask_1_graphics_64,x:83.0905,y:96.7058}).wait(1).to({graphics:mask_1_graphics_65,x:81.9456,y:96.3054}).wait(1).to({graphics:mask_1_graphics_66,x:80.9002,y:95.9399}).wait(1).to({graphics:mask_1_graphics_67,x:79.9544,y:95.6091}).wait(1).to({graphics:mask_1_graphics_68,x:79.1082,y:95.3132}).wait(1).to({graphics:mask_1_graphics_69,x:78.3615,y:95.0521}).wait(1).to({graphics:mask_1_graphics_70,x:77.7144,y:94.8258}).wait(1).to({graphics:mask_1_graphics_71,x:77.1669,y:94.6344}).wait(1).to({graphics:mask_1_graphics_72,x:76.7189,y:94.4777}).wait(1).to({graphics:mask_1_graphics_73,x:76.3704,y:94.3559}).wait(1).to({graphics:mask_1_graphics_74,x:76.1215,y:94.2688}).wait(1).to({graphics:mask_1_graphics_75,x:75.9722,y:94.2166}).wait(1).to({graphics:mask_1_graphics_76,x:77.869,y:94.1992}).wait(74).to({graphics:mask_1_graphics_150,x:77.869,y:94.1992}).wait(1).to({graphics:null,x:0,y:0}).wait(39));

	// Layer_10
	this.instance_1 = new lib.germs_group();
	this.instance_1.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(36).to({_off:false},0).wait(114).to({_off:true},1).wait(39));

	// mask_idn (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_1 = new cjs.Graphics().p("AGFLkQgSABg2gEQg2gDAigYQAhgXACgXQACgWg4gHQg5gHAEgfQAEggAXgSQAJgIAlAVQgKgmATgJQAigPAVAEQAkAGgHARIgIANQgFAGACACQABABAhgMQAjgMAHAAQASAAANANQANANAAASQAAASgNANIgJAKIgFAGQgUAIgBAHQgBAGALAGIAUALQAMAHAAAGQAAARgCAIQgDAKgKAKIgcAbQgQAQgMAHIgFABQgLAAgSgVg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AF2LwQgXABhFgFQhEgFArgeQAqgdADgdQACgchIgJQhHgJAFgoQAFgoAcgXQANgKAuAbQgMgxAYgLQArgTAbAEQAuAIgKAWIgKAQQgGAIADADQABABAqgPQAsgQAJAAQAXAAAQAQQARARAAAXQAAAXgRARIgKANIgIAHQgZALgBAJQgBAHAOAIIAaAOQAOAJAAAHQAAAWgDAJQgDANgNANIgjAjQgUAUgPAIQgDACgEAAQgOAAgXgag");
	var mask_2_graphics_3 = new cjs.Graphics().p("AFoL7QgdABhTgGQhTgGA0gkQA0gkADgiQACgihWgLQhXgLAGgwQAGgwAjgcQAPgMA4AgQgPg7AegNQAzgYAhAGQA4AJgMAaIgMAUQgIAKAEADQABACAzgTQA1gTALAAQAcAAAUAUQAUAUAAAcQAAAcgUAUIgNAPIgJAKQgeANgCAKQgBAJARAKIAfARQARAKAAAKQAAAZgDAMQgEAPgQAQIgqAqQgZAZgSAKQgEACgEAAQgRAAgbggg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AFZMGQghABhhgHQhigGA9grQA9gqADgoQADgohlgNQhmgMAHg5QAHg5ApggQARgOBCAlQgRhEAigQQA9gcAmAHQBBALgNAeIgPAXQgIAMADAEQACACA8gWQA+gXANAAQAhAAAXAYQAYAXAAAhQAAAhgYAYIgPARIgLALQgjAPgCANQgBAKATAMIAlATQAUANAAALQAAAegEAOQgFASgSASIgxAyQgdAdgVALQgFACgFAAQgUAAggglg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AFLMRQgnABhvgHQhvgIBFgwQBGgxAEguQADguh0gOQh0gOAJhBQAHhBAugmQAUgQBMArQgUhOAngTQBFggAtAIQBKANgPAjQgDAFgOAVQgKAOAFAEQABACBFgZQBIgaAOAAQAlAAAbAbQAbAbAAAmQAAAlgbAbIgSAVIgMAMQgoASgCAOQgBALAWAOIAqAWQAXAOAAANQAAAjgEAPQgGAVgVAVIg4A5QghAhgZANQgFADgGAAQgXAAgkgrg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AE9McQgsABh9gIQh9gJBOg2QBOg3AFgzQAEg1iDgQQiCgQAJhIQAKhKAzgqQAWgSBVAwQgWhYAsgUQBOgkAyAIQBTAPgRAnQgDAGgQAYQgLAPAFAFQACACBNgcQBRgdAQAAQAqAAAeAeQAeAeAAArQAAAqgeAeIgUAXQgLANgCACQguATgCAQQgCANAaAPIAvAZQAaAQAAAPQAAAngFARQgHAXgXAXIhABBQglAlgbAPQgGADgGAAQgbAAgogwg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AEuMnQgwABiKgKQiKgJBWg8QBWg9AFg5QAEg6iRgSQiQgSALhQQAKhSA5gvQAZgUBeA2QgZhiAxgXQBWgoA4AKQBdAQgUAsQgDAGgRAbQgNARAGAFQACACBVgeQBaghASAAQAuAAAiAhQAiAiAAAvQAAAvgiAiIgWAZQgNAPgCABQgyAVgDATQgCAOAcAQIA0AdQAdARAAAQQAAAsgFATQgIAagZAZIhHBIQgpApgfARQgGADgHAAQgdAAgug1g");
	var mask_2_graphics_8 = new cjs.Graphics().p("AEhMxQg1ACiYgLQiYgKBehDQBfhCAGg/QAEg/iegUQiggTAMhZQALhZA/g0QAcgWBnA7QgbhrA1gZQBfgsA9AKQBmASgVAwQgEAHgTAdQgNATAFAGQADACBdgiQBjgjATAAQA0AAAlAkQAlAlAAA0QAAA0glAlIgZAbQgNAQgDACQg3AXgDAUQgCAQAfASIA5AfQAgATAAASQAAAvgGAWQgIAcgcAcIhOBPQgtAtgiASQgHAEgIAAQggAAgxg7g");
	var mask_2_graphics_9 = new cjs.Graphics().p("AETM8Qg6ACilgMQilgMBnhIQBnhIAGhEQAFhFisgWQiugVANhgQAMhhBEg4QAegZBxBBQgdh1A5gbQBngwBCALQBvATgXA1QgDAIgVAfQgPAUAGAHQADADBmglQBrgnAVAAQA4AAAoAoQAoAoAAA4QAAA4goApIgaAeQgPARgDACQg8AZgDAWQgCARAhAUIA+AiQAjAUAAAUQAAAzgHAYQgIAegfAfIhUBVQgyAygkATQgIAEgIAAQgjAAg2g/g");
	var mask_2_graphics_10 = new cjs.Graphics().p("AEFNGQg+ACizgNQiygMBwhOQBvhNAGhLQAGhKi7gXQi7gXAOhoQANhpBKg9QAggaB6BGQggh/BAgdQBugzBHAMQB4AUgZA5QgEAJgXAiQgPAVAHAIQACACBugnQB0grAXAAQA8AAAsAsQArArAAA9QAAA9grArIgdAhQgQASgDACQhBAcgDAXQgDASAkAWQAuAYAWAMQAlAXAAAVQAAA3gHAZQgKAiggAhIhcBcQg1A1gnAWQgIAEgKAAQglAAg7hFg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AD4NQQhDACi/gNQjAgOB4hTQB3hTAHhQQAGhQjIgYQjKgZAQhwQAOhwBPhBQAjgcCDBKQgiiHBDggQB2g2BNANQCBAVgbA9QgEAJgZAkQgQAYAHAIQADADB2grQB8gtAZAAQBBAAAuAuQAvAvAABBQAABBgvAuIgfAkQgRAUgDACQhGAdgDAZQgDAUAnAXQAxAaAXANQAoAYAAAXQAAA7gIAbQgKAkgjAjIhiBjQg5A6grAWQgIAFgKAAQgoAAg/hKg");
	var mask_2_graphics_12 = new cjs.Graphics().p("ADrNaQhHADjMgPQjOgOCBhZQB/hZAHhVQAGhVjVgbQjXgaAQh3QAPh4BVhGQAlgeCMBQQgliRBIggQB/g7BRAOQCKAXgdBAQgEAKgaAnQgSAZAIAIQADADB+gtQCEgwAaAAQBGAAAxAxQAyAyAABFQAABGgyAxIghAmQgSAWgEABQhKAggDAbQgDAVApAYQA0AcAZAOQArAaAAAYQAABAgIAcQgLAmgmAmIhoBqQg9A9guAYQgJAFgKAAQgrAAhDhPg");
	var mask_2_graphics_13 = new cjs.Graphics().p("ADeNkQhMADjYgQQjbgPCJheQCIhfAHhaQAHhbjkgcQjkgcARh+QAQiABahKQAngfCVBUQgniYBNgkQCGg/BXAQQCSAYgfBFQgEAKgcApQgTAaAIAJQADADCGgwQCNgyAcAAQBKAAA0A0QA1A0AABKQAABKg1A1IgjAoQgTAWgEACQhPAigEAdQgDAWAsAaQA4AdAaAPQAuAbAAAaQAABEgJAeQgMApgoAoIhvBwQhABBgxAaQgJAFgMAAQgtAAhHhUg");
	var mask_2_graphics_14 = new cjs.Graphics().p("ADRNuQhQADjlgRQjngQCQhkQCQhkAIhfQAHhgjxgdQjxgeASiGQARiHBfhOQAqghCdBZQgpiiBRglQCOhDBcARQCaAaggBJQgFALgdAqQgUAcAIAKQAEADCNgzQCVg1AeAAQBOAAA3A2QA4A4AABOQAABPg4A3IglAqQgUAZgFACQhTAjgEAeQgDAYAuAbQA7AfAcAQQAwAdAAAbQAABIgJAgQgMArgrAqIh1B3QhFBFgzAbQgKAGgMAAQgwAAhLhZg");
	var mask_2_graphics_15 = new cjs.Graphics().p("ADEN3QhUADjygRQjzgRCYhpQCYhpAIhlQAIhlj+gfQj/gfATiOQASiOBlhSQArgiCmBdQgriqBVgoQCXhGBgARQCiAcghBNQgFALggAuQgVAdAJAKQAEADCVg0QCdg6AfAAQBSAAA7A7QA7A6AABSQAABSg7A7IgnAtQgWAZgEACQhYAmgEAgQgEAYAxAdQA/AhAdARQAyAeAAAcQAABMgJAiQgNAtgtAtIh8B9QhIBIg1AdQgLAGgNAAQgzAAhPheg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AC4OBQhZADj+gSQj/gSCghuQCfhvAJhpQAIhrkLggQkLghAUiVQASiVBqhVQAuglCuBiQguizBagqQCehJBlARQCrAdgkBRQgFAMghAxQgWAfAKAKQAEAECcg5QClg8AhAAQBWAAA+A+QA9A+AABVQAABXg9A9IgpAvQgXAbgFACQhcAngEAiQgEAaAzAeQBCAiAeASQA2AgAAAeQAABPgLAkQgNAwgvAuIiCCEQhMBMg4AeQgMAGgNAAQg1AAhThig");
	var mask_2_graphics_17 = new cjs.Graphics().p("ACrOKQhcAEkKgTQkMgTCnh0QCnh0AJhuQAJhvkXgjQkZgiAVibQAUidBuhZQAxgnC2BmQgwi7BegrQCmhNBqASQCzAfgmBUQgFANgiAyQgYAhAKALQAEAECkg7QCtg/AiAAQBbAABABAQBBBBAABZQAABbhBBBIgrAxQgYAcgEACQhhApgFAjQgDAcA1AgQBFAjAgATQA4AhAAAgQAABTgLAlQgOAygxAxIiICKQhQBPg7AgQgMAGgOAAQg3AAhYhng");
	var mask_2_graphics_18 = new cjs.Graphics().p("ACfOUQhhADkVgUQkYgTCvh5QCuh5AJh0QAJh0kjgkQklgjAWijQAUijB0heQAygoC+BsQgxjFBigtQCthRBvAUQC6AfgnBZQgFANgkA1QgYAiAKALQAEAECsg9QC0hCAkAAQBeAABEBDQBDBEAABdQAABfhDBEIgtAzQgZAdgFACQhlAsgFAkQgEAdA4AhQBIAlAhAUQA7AjAAAgQAABXgMAnQgOA0g0AzIiOCQQhTBTg+AhQgMAHgOAAQg7AAhbhrg");
	var mask_2_graphics_19 = new cjs.Graphics().p("ACTOdQhlADkhgUQkkgUC3h/QC1h+AKh4QAJh5kwglQkxgmAXipQAVipB5hjQA0gqDGBxQgzjNBmgwQC1hTBzAUQDCAhgoBcQgGAOglA3QgaAjALAMQAEAECzhAQC8hFAlAAQBjAABGBHQBGBGAABiQAABihGBHIgvA1QgaAfgFACQhpAtgFAmQgEAeA6AiQBLAnAiAVQA9AkAAAiQAABbgMAoQgPA2g1A2IiUCWQhXBWhAAjQgNAHgPAAQg9AAhfhwg");
	var mask_2_graphics_20 = new cjs.Graphics().p("ACXOmQhpADktgVQkvgVC+iDQC8iDALh9QAJh+k8gnQk9gnAYiwQAWiwB9hmQA2gsDPB1Qg2jVBqgxQC8hYB5AWQDJAigqBgQgGAOgnA5QgaAlALANQAEAEC6hDQDEhHAmAAQBnAABJBJQBJBJAABmQAABmhJBJIgxA4QgbAfgFADQhtAvgGAnQgEAfA9AkQBNApAkAVQBAAmAAAjQAABegNAqQgQA5g3A3IiaCcQhaBahDAkQgNAHgQAAQg/AAhjh0g");
	var mask_2_graphics_21 = new cjs.Graphics().p("ACdOvQhtADk5gWQk6gVDFiJQDDiIALiCQAKiClIgoQlJgpAZi2QAXi3CBhqQA5guDWB6Qg4jdBvg0QDChaB+AWQDRAjgsBkQgGAPgpA7QgbAmAMANQAEAFDBhGQDLhKAoAAQBqAABMBMQBMBMAABqQAABqhMBMIgyA5QgcAhgGADQhxAxgGApQgEAgA/AlQBQAqAmAWQBBAnAAAlQAABigMAsQgRA6g5A6IigChQheBehFAlQgOAIgQAAQhCAAhmh5g");
	var mask_2_graphics_22 = new cjs.Graphics().p("ACiO4QhwADlEgWQlGgXDMiNQDKiNAMiHQAKiHlUgqQlUgpAZi+QAYi9CGhuQA7gvDdB+Qg5jlByg1QDKheCCAXQDYAlgtBnQgHAPgpA+QgdAnAMAOQAFAEDIhIQDShMAqAAQBuAABOBOQBPBPAABuQAABthPBPIg0A8QgdAigGACQh1AzgGAqQgFAhBCAnQBTAsAnAWQBEApAAAmQAABlgNAuQgRA8g8A8IimCoQhgBghIAnQgPAIgRAAQhEAAhqh9g");
	var mask_2_graphics_23 = new cjs.Graphics().p("ACoPIQh1AElOgYQlRgXDSiSQDSiSAMiLQAKiMlfgrQlhgrAbjEQAYjDCLhyQA9gxDlCCQg8jtB3g3QDQhgCGAXQDhAmgvBrQgHAQgrA/QgeApANAOQAFAFDPhKQDZhQArAAQBxAABSBSQBRBRAABxQAABzhRBQQgPAQgnAuQgeAjgGADQh6A0gGAsQgFAiBEAoQBWAtAoAYQBHAqAAAnQAABpgOAvQgSA+g9A+IisCtQhjBkhLAoQgPAIgRAAQhGAAhuiBg");
	var mask_2_graphics_150 = new cjs.Graphics().p("ACoPIQh1AElOgYQlRgXDSiSQDSiSAMiLQAKiMlfgrQlhgrAbjEQAYjDCLhyQA9gxDlCCQg8jtB3g3QDQhgCGAXQDhAmgvBrQgHAQgrA/QgeApANAOQAFAFDPhKQDZhQArAAQBxAABSBSQBRBRAABxQAABzhRBQQgPAQgnAuQgeAjgGADQh6A0gGAsQgFAiBEAoQBWAtAoAYQBHAqAAAnQAABpgOAvQgSA+g9A+IisCtQhjBkhLAoQgPAIgRAAQhGAAhuiBg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_2_graphics_1,x:50.0008,y:76.1147}).wait(1).to({graphics:mask_2_graphics_2,x:51.5032,y:77.8108}).wait(1).to({graphics:mask_2_graphics_3,x:52.9884,y:79.4874}).wait(1).to({graphics:mask_2_graphics_4,x:54.4564,y:81.1447}).wait(1).to({graphics:mask_2_graphics_5,x:55.9072,y:82.7825}).wait(1).to({graphics:mask_2_graphics_6,x:57.3409,y:84.401}).wait(1).to({graphics:mask_2_graphics_7,x:58.7574,y:86.0002}).wait(1).to({graphics:mask_2_graphics_8,x:60.1568,y:87.5799}).wait(1).to({graphics:mask_2_graphics_9,x:61.539,y:89.1402}).wait(1).to({graphics:mask_2_graphics_10,x:62.904,y:90.6812}).wait(1).to({graphics:mask_2_graphics_11,x:64.2518,y:92.2028}).wait(1).to({graphics:mask_2_graphics_12,x:65.5825,y:93.705}).wait(1).to({graphics:mask_2_graphics_13,x:66.896,y:95.1878}).wait(1).to({graphics:mask_2_graphics_14,x:68.1923,y:96.6512}).wait(1).to({graphics:mask_2_graphics_15,x:69.4714,y:98.0953}).wait(1).to({graphics:mask_2_graphics_16,x:70.7334,y:99.5199}).wait(1).to({graphics:mask_2_graphics_17,x:71.9782,y:100.9252}).wait(1).to({graphics:mask_2_graphics_18,x:73.2059,y:102.3111}).wait(1).to({graphics:mask_2_graphics_19,x:74.4163,y:103.6776}).wait(1).to({graphics:mask_2_graphics_20,x:74.0363,y:105.0248}).wait(1).to({graphics:mask_2_graphics_21,x:73.4753,y:106.3525}).wait(1).to({graphics:mask_2_graphics_22,x:72.9224,y:107.6609}).wait(1).to({graphics:mask_2_graphics_23,x:73.3567,y:109.733}).wait(127).to({graphics:mask_2_graphics_150,x:73.3567,y:109.733}).wait(1).to({graphics:null,x:0,y:0}).wait(39));

	// Layer_1
	this.instance_2 = new lib.germs_group();
	this.instance_2.setTransform(156.5,130,1,1,0,0,0,210.5,142);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(149).to({_off:true},1).wait(39));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128,-210,498,662);


// stage content:
(lib.LysolGeneric_LDS_300x600_en = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var self = this;
		//this.btnColor;
		////this.downText = this.cta.cta.textDown;
		////this.upText = this.cta.cta.textUp;
		////this.textRestingYPos = 17;
		//this.ctaTextOffset = 30;
		
		////self.upText.y = this.textRestingYPos + this.ctaTextOffset;
		////self.downText.y = this.textRestingYPos;
		
		//this.setBtnColor = function(p_color) {
		//	switch (p_color) {
		//		case "white":
		//			self.cta.cta.arrow.gotoAndPlay("dark-green");
		//			//self.cta.cta.textDown.gotoAndPlay("dark-green");
		//			self.cta.cta.bg.gotoAndPlay("white");
		//			self.btnColor = "white";
		//			break;
		//		case "regular-green":
		//			self.cta.cta.arrow.gotoAndPlay("white");
		//			//self.cta.cta.textDown.gotoAndPlay("white");
		//			self.cta.cta.bg.gotoAndPlay("regular-green");
		//			self.btnColor = "regular-green";
		//			break;	
		//	}
		//}
		//this.setRolloverBtnColor = function() {
		//	if (self.btnColor == "regular-green") {
		//		setTimeout(function() {
		//			self.cta.cta.arrow.gotoAndPlay("dark-green");
		//		}, 150);
		//	}	
		//}
		//this.setRolloutBtnColor = function() {
		//	if (self.btnColor == "regular-green") {
		//		setTimeout(function() {
		//			self.cta.cta.arrow.gotoAndPlay("white");
		//		}, 150);
		//	}
		//}
		
		//// Set initial button color
		//setTimeout(function() {
		//	self.setBtnColor("regular-green");
		//}, 50);
		
		// Clicktag =======================
		
		this.clicktag.addEventListener('click', handleClick);
		//this.clicktag.addEventListener('mouseover', handleMouseOver);
		//this.clicktag.addEventListener('mouseout', handleMouseOut);
		
		function handleClick() {
		    window.ctaClick();
		}
		//function handleMouseOver() {
		//	//var landingY = self.textRestingYPos;
		//	self.cta.gotoAndPlay("over"); 
		//	self.cta.cta.gotoAndPlay("over");
		//	self.setRolloverBtnColor();
		//	//self.downText.y = landingY;
		//	//self.upText.y = landingY-self.ctaTextOffset;
		//	//createjs.Tween.get(self.downText, {override:true}).to({y:landingY+self.ctaTextOffset}, 200, createjs.Ease.quintIn);
		//	//createjs.Tween.get(self.upText, {override:true}).wait(200).to({y:landingY}, 300, createjs.Ease.quintOut);
		//}
		//function handleMouseOut() {
		//	//var landingY = self.textRestingYPos;
		//	self.cta.gotoAndPlay("out");
		//	self.cta.cta.gotoAndPlay("out");
		//	self.setRolloutBtnColor();
		//	//self.downText.y = landingY+self.ctaTextOffset;
		//	//self.upText.y = landingY;
		//	//createjs.Tween.get(self.downText, {override:true}).wait(200).to({y:landingY}, 300, createjs.Ease.quintOut);
		//	//createjs.Tween.get(self.upText, {override:true}).to({y:landingY-self.ctaTextOffset}, 200, createjs.Ease.quintIn);
		//}
		//
	}
	this.frame_370 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(370).call(this.frame_370).wait(489));

	// ClickTag
	this.clicktag = new lib.click();
	this.clicktag.setTransform(150.1,300.65,1,2.3997,0,0,0,0.1,0.3);
	new cjs.ButtonHelper(this.clicktag, 0, 1, 2, false, new lib.click(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clicktag).to({_off:true},371).wait(488));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("EgXbgu3MAu3AAAMAAABdvMgu3AAAg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},438).wait(421));

	// copy_04
	this.instance = new lib.copy_04();
	this.instance.setTransform(78.1,589.8,1,1,0,0,0,61.1,12);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(349).to({_off:false},0).to({alpha:1},14,cjs.Ease.get(1)).to({_off:true},8).wait(488));

	// what_it_takes
	this.instance_1 = new lib.whatittakes();
	this.instance_1.setTransform(45.5,554,1,1,0,0,0,32.5,11);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(342).to({_off:false},0).to({alpha:1},14,cjs.Ease.get(1)).to({_off:true},15).wait(488));

	// product
	this.instance_2 = new lib.product_1();
	this.instance_2.setTransform(340.5,386.5,1,1,0,0,0,35.5,54.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(335).to({_off:false},0).to({x:115.5},14,cjs.Ease.get(1)).to({_off:true},22).wait(488));

	// bg_blue
	this.instance_3 = new lib.bg_blue();
	this.instance_3.setTransform(52,725,1,1,0,0,0,52,125);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(328).to({_off:false},0).to({y:386},9,cjs.Ease.get(1)).to({_off:true},34).wait(488));

	// btn_cta
	this.instance_4 = new lib.btn_cta();
	this.instance_4.setTransform(95,179,1,1,0,0,0,61,20.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(314).to({_off:false},0).to({x:75,alpha:1},9,cjs.Ease.get(1)).to({_off:true},48).wait(488));

	// copy_03
	this.instance_5 = new lib.copy_03();
	this.instance_5.setTransform(114.7,86.25,1,1,0,0,0,82,27.3);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(308).to({_off:false},0).to({x:94.7,alpha:1},9,cjs.Ease.get(1)).to({_off:true},54).wait(488));

	// copy_02
	this.instance_6 = new lib.copy_02();
	this.instance_6.setTransform(150.05,270.2,1,1,0,0,0,122.8,27.7);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(255).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).to({_off:true},38).wait(551));

	// logo
	this.instance_7 = new lib.logo_1();
	this.instance_7.setTransform(265.5,562,1,1,0,0,0,24.5,23);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(163).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).to({_off:true},130).wait(551));

	// bg_light_blue
	this.instance_8 = new lib.bg_lightblue();
	this.instance_8.setTransform(98,-474,1,1,0,0,0,98,125);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(241).to({_off:false},0).to({y:125},14,cjs.Ease.get(1)).to({_off:true},116).wait(488));

	// hand
	this.instance_9 = new lib.hand_spray_1("single",0);
	this.instance_9.setTransform(-97.1,445.05,1,1,-22.7187,0,0,-0.1,112);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(178).to({_off:false},0).to({regX:0,rotation:0,x:0,y:385},4,cjs.Ease.get(1)).wait(3).to({mode:"synched"},0).to({regX:0.1,rotation:4.9513,x:-4.05,startPosition:12},20,cjs.Ease.get(1)).to({regX:-0.1,rotation:-7.0392,x:-5.2,y:395,startPosition:38},20,cjs.Ease.get(1)).to({regX:0,rotation:0,x:0,y:385,mode:"single",startPosition:0},19,cjs.Ease.get(1)).to({y:765},11,cjs.Ease.get(1)).to({_off:true},1).wait(603));

	// spray
	this.instance_10 = new lib.spray_mist("synched",0);
	this.instance_10.setTransform(150,325,0.6263,0.6263,0,0,0,150,150.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(185).to({_off:false},0).to({regX:149.8,regY:149.8,scaleX:1.486,scaleY:1.486,x:149.9,y:324.65,alpha:0.2813},40,cjs.Ease.get(1)).to({scaleX:2.1808,scaleY:2.1808,x:150,y:324.75,alpha:0},10).to({_off:true},4).wait(620));

	// ice_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_33 = new cjs.Graphics().p("AmXVDIAAikIdOAAIAACkg");
	var mask_graphics_34 = new cjs.Graphics().p("AumB3IAAjtIdNAAIAADtg");
	var mask_graphics_35 = new cjs.Graphics().p("AumCbIAAk1IdNAAIAAE1g");
	var mask_graphics_36 = new cjs.Graphics().p("AumC/IAAl9IdNAAIAAF9g");
	var mask_graphics_37 = new cjs.Graphics().p("AumDkIAAnHIdNAAIAAHHg");
	var mask_graphics_38 = new cjs.Graphics().p("AumEIIAAoPIdNAAIAAIPg");
	var mask_graphics_39 = new cjs.Graphics().p("AumEsIAApXIdNAAIAAJXg");
	var mask_graphics_40 = new cjs.Graphics().p("AumFRIAAqgIdNAAIAAKgg");
	var mask_graphics_41 = new cjs.Graphics().p("AumF1IAArpIdNAAIAALpg");
	var mask_graphics_42 = new cjs.Graphics().p("AumGZIAAsxIdNAAIAAMxg");
	var mask_graphics_43 = new cjs.Graphics().p("AumG9IAAt5IdNAAIAAN5g");
	var mask_graphics_44 = new cjs.Graphics().p("AumHiIAAvDIdNAAIAAPDg");
	var mask_graphics_45 = new cjs.Graphics().p("AumIGIAAwLIdNAAIAAQLg");
	var mask_graphics_46 = new cjs.Graphics().p("AumIrIAAxUIdNAAIAARUg");
	var mask_graphics_47 = new cjs.Graphics().p("AumJPIAAydIdNAAIAASdg");
	var mask_graphics_48 = new cjs.Graphics().p("AumJzIAAzlIdNAAIAATlg");
	var mask_graphics_49 = new cjs.Graphics().p("AumKXIAA0tIdNAAIAAUtg");
	var mask_graphics_50 = new cjs.Graphics().p("AmXevIAA13IdOAAIAAV3g");
	var mask_graphics_51 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_52 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_53 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_54 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_55 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_56 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_57 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_58 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_59 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_60 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_61 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_62 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_63 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_64 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_65 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_66 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_67 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_68 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_69 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_70 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_71 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_72 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_73 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_74 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_75 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_76 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_77 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_78 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_79 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_80 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_81 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_82 = new cjs.Graphics().p("AumK8IAA13IdNAAIAAV3g");
	var mask_graphics_83 = new cjs.Graphics().p("AmXevIAA13IdOAAIAAV3g");
	var mask_graphics_84 = new cjs.Graphics().p("AumJvIAAzdIdNAAIAATdg");
	var mask_graphics_85 = new cjs.Graphics().p("AumIiIAAxCIdNAAIAARCg");
	var mask_graphics_86 = new cjs.Graphics().p("AumHUIAAunIdNAAIAAOng");
	var mask_graphics_87 = new cjs.Graphics().p("AumGHIAAsNIdNAAIAAMNg");
	var mask_graphics_88 = new cjs.Graphics().p("AumE6IAApzIdNAAIAAJzg");
	var mask_graphics_89 = new cjs.Graphics().p("AumDtIAAnZIdNAAIAAHZg");
	var mask_graphics_90 = new cjs.Graphics().p("AumCfIAAk9IdNAAIAAE9g");
	var mask_graphics_91 = new cjs.Graphics().p("AmvVDIAAikIdMAAIAACkg");
	var mask_graphics_92 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_93 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_94 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_95 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_96 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_97 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_98 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_99 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_100 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_101 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_102 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_103 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_104 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_105 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_106 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_107 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_108 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_109 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_110 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_111 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_112 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_113 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_114 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_115 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_116 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_117 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_118 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_119 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_120 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_121 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_122 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_123 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_124 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_125 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_126 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_127 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_128 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_129 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_130 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_131 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_132 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_133 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_134 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_135 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_136 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_137 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_138 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_139 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_140 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_141 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_142 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_143 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_144 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_145 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_146 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_147 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_148 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_149 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_150 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_151 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_152 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_153 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_154 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_155 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_156 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_157 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_158 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_159 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_160 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_161 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_162 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_163 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_164 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_165 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_166 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_167 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_168 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_169 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_170 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_171 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_172 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_173 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_174 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_175 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_176 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_177 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_178 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_179 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_180 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_181 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_182 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_183 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_184 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_185 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_186 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_187 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_188 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_189 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_190 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_191 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_192 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_193 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_194 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_195 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_196 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_197 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_198 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_199 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_200 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_201 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_202 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_203 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_204 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_205 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_206 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_207 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_208 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_209 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_210 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_211 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_212 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_213 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_214 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_215 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_216 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_217 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_218 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_219 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_220 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_221 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_222 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_223 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_224 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_225 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_226 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_227 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_228 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_229 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_230 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_231 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_232 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_233 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_234 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_235 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_236 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_237 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_238 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_239 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_240 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_241 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_242 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_243 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_244 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_245 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_246 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_247 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_248 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_249 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_250 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_251 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_252 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_253 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_254 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_255 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_256 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_257 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_258 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_259 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_260 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_261 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_262 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_263 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_264 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_265 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_266 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_267 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_268 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_269 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_270 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_271 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_272 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_273 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_274 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_275 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_276 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_277 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_278 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_279 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_280 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_281 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_282 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_283 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_284 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_285 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_286 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_287 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_288 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_289 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_290 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_291 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_292 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_293 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_294 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_295 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_296 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_297 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_298 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_299 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_300 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_301 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_302 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_303 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_304 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_305 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_306 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_307 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_308 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_309 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_310 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_311 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_312 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_313 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_314 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_315 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_316 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_317 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_318 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_319 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_320 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_321 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_322 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_323 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_324 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_325 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_326 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_327 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_328 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_329 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_330 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_331 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_332 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_333 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_334 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_335 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_336 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_337 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_338 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_339 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_340 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_341 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_342 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_343 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_344 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_345 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_346 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_347 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_348 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_349 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_350 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_351 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_352 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_353 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_354 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_355 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_356 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_357 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_358 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_359 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_360 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_361 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_362 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_363 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_364 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_365 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_366 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_367 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_368 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_369 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_370 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_371 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_372 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_373 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_374 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_375 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_376 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_377 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_378 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_379 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_380 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_381 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_382 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_383 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_384 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_385 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_386 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_387 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_388 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_389 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_390 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_391 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_392 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_393 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_394 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_395 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_396 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_397 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_398 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_399 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_400 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_401 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_402 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_403 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_404 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_405 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_406 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_407 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_408 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_409 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_410 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_411 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_412 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_413 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_414 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_415 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_416 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_417 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_418 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_419 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_420 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_421 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_422 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_423 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_424 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_425 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_426 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_427 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_428 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_429 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_430 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_431 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_432 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_433 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_434 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_435 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_436 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_437 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_438 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_439 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_440 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_441 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_442 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_443 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_444 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_445 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_446 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_447 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_448 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_449 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_450 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_451 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_452 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_453 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_454 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_455 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_456 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_457 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_458 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_459 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_460 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_461 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_462 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_463 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_464 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_465 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_466 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_467 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_468 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_469 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_470 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_471 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_472 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_473 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_474 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_475 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_476 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_477 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_478 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_479 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_480 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_481 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_482 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_483 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_484 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_485 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_486 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_487 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_488 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_489 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_490 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_491 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_492 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_493 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_494 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_495 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_496 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_497 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_498 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_499 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_500 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_501 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_502 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_503 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_504 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_505 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_506 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_507 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_508 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_509 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_510 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_511 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_512 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_513 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_514 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_515 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_516 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_517 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_518 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_519 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_520 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_521 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_522 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_523 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_524 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_525 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_526 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_527 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_528 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_529 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_530 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_531 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_532 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_533 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_534 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_535 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_536 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_537 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_538 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_539 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_540 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_541 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_542 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_543 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_544 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_545 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_546 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_547 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_548 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_549 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_550 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_551 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_552 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_553 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_554 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_555 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_556 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_557 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_558 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_559 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_560 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_561 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_562 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_563 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_564 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_565 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_566 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_567 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_568 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_569 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_570 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_571 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_572 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_573 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_574 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_575 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_576 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_577 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_578 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_579 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_580 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_581 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_582 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_583 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_584 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_585 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_586 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_587 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_588 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_589 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_590 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_591 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_592 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_593 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_594 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_595 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_596 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_597 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_598 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_599 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_600 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_601 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_602 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_603 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_604 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_605 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_606 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_607 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_608 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_609 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_610 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_611 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_612 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_613 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_614 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_615 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_616 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_617 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_618 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_619 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_620 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_621 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_622 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_623 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_624 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_625 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_626 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_627 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_628 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_629 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_630 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_631 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_632 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_633 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_634 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_635 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_636 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_637 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_638 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_639 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_640 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_641 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_642 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_643 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_644 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_645 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_646 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_647 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_648 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_649 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_650 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_651 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_652 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_653 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_654 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_655 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_656 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_657 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_658 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_659 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_660 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_661 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_662 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_663 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_664 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_665 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_666 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_667 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_668 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_669 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_670 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_671 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_672 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_673 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_674 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_675 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_676 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_677 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_678 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_679 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_680 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_681 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_682 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_683 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_684 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_685 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_686 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_687 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_688 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_689 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_690 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_691 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_692 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_693 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_694 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_695 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_696 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_697 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_698 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_699 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_700 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_701 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_702 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_703 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_704 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_705 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_706 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_707 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_708 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_709 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_710 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_711 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_712 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_713 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_714 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_715 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_716 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_717 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_718 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_719 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_720 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_721 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_722 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_723 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_724 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_725 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_726 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_727 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_728 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_729 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_730 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_731 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_732 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_733 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_734 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_735 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_736 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_737 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_738 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_739 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_740 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_741 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_742 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_743 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_744 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_745 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_746 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_747 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_748 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_749 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_750 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_751 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_752 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_753 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_754 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_755 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_756 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_757 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_758 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_759 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_760 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_761 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_762 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_763 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_764 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_765 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_766 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_767 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_768 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_769 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_770 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_771 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_772 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_773 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_774 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_775 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_776 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_777 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_778 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_779 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_780 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_781 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_782 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_783 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_784 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_785 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_786 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_787 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_788 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_789 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_790 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_791 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_792 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_793 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_794 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_795 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_796 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_797 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_798 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_799 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_800 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_801 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_802 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_803 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_804 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_805 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_806 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_807 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_808 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_809 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_810 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_811 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_812 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_813 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_814 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_815 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_816 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_817 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_818 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_819 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_820 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_821 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_822 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_823 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_824 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_825 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_826 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_827 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_828 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_829 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_830 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_831 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_832 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");
	var mask_graphics_833 = new cjs.Graphics().p("AumBSIAAijIdNAAIAACjg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(33).to({graphics:mask_graphics_33,x:146.25,y:134.75}).wait(1).to({graphics:mask_graphics_34,x:199,y:264.95}).wait(1).to({graphics:mask_graphics_35,x:199,y:268.625}).wait(1).to({graphics:mask_graphics_36,x:199,y:272.275}).wait(1).to({graphics:mask_graphics_37,x:199,y:275.95}).wait(1).to({graphics:mask_graphics_38,x:199,y:279.575}).wait(1).to({graphics:mask_graphics_39,x:199,y:283.25}).wait(1).to({graphics:mask_graphics_40,x:199,y:286.9}).wait(1).to({graphics:mask_graphics_41,x:199,y:290.575}).wait(1).to({graphics:mask_graphics_42,x:199,y:294.225}).wait(1).to({graphics:mask_graphics_43,x:199,y:297.9}).wait(1).to({graphics:mask_graphics_44,x:199,y:301.55}).wait(1).to({graphics:mask_graphics_45,x:199,y:305.225}).wait(1).to({graphics:mask_graphics_46,x:199,y:308.85}).wait(1).to({graphics:mask_graphics_47,x:199,y:312.525}).wait(1).to({graphics:mask_graphics_48,x:199,y:316.175}).wait(1).to({graphics:mask_graphics_49,x:199,y:319.85}).wait(1).to({graphics:mask_graphics_50,x:146.25,y:196.75}).wait(1).to({graphics:mask_graphics_51,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_52,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_53,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_54,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_55,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_56,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_57,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_58,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_59,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_60,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_61,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_62,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_63,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_64,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_65,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_66,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_67,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_68,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_69,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_70,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_71,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_72,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_73,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_74,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_75,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_76,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_77,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_78,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_79,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_80,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_81,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_82,x:199,y:323.5}).wait(1).to({graphics:mask_graphics_83,x:146.25,y:196.75}).wait(1).to({graphics:mask_graphics_84,x:198.4,y:315.725}).wait(1).to({graphics:mask_graphics_85,x:197.75,y:307.95}).wait(1).to({graphics:mask_graphics_86,x:197.15,y:300.175}).wait(1).to({graphics:mask_graphics_87,x:196.5,y:292.4}).wait(1).to({graphics:mask_graphics_88,x:195.9,y:284.625}).wait(1).to({graphics:mask_graphics_89,x:195.25,y:276.85}).wait(1).to({graphics:mask_graphics_90,x:194.65,y:269.075}).wait(1).to({graphics:mask_graphics_91,x:143.75,y:134.75}).wait(1).to({graphics:mask_graphics_92,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_93,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_94,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_95,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_96,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_97,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_98,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_99,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_100,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_101,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_102,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_103,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_104,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_105,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_106,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_107,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_108,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_109,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_110,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_111,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_112,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_113,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_114,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_115,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_116,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_117,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_118,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_119,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_120,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_121,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_122,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_123,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_124,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_125,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_126,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_127,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_128,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_129,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_130,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_131,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_132,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_133,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_134,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_135,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_136,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_137,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_138,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_139,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_140,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_141,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_142,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_143,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_144,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_145,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_146,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_147,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_148,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_149,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_150,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_151,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_152,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_153,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_154,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_155,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_156,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_157,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_158,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_159,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_160,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_161,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_162,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_163,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_164,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_165,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_166,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_167,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_168,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_169,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_170,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_171,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_172,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_173,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_174,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_175,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_176,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_177,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_178,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_179,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_180,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_181,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_182,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_183,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_184,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_185,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_186,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_187,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_188,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_189,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_190,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_191,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_192,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_193,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_194,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_195,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_196,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_197,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_198,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_199,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_200,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_201,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_202,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_203,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_204,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_205,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_206,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_207,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_208,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_209,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_210,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_211,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_212,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_213,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_214,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_215,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_216,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_217,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_218,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_219,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_220,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_221,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_222,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_223,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_224,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_225,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_226,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_227,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_228,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_229,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_230,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_231,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_232,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_233,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_234,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_235,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_236,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_237,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_238,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_239,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_240,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_241,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_242,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_243,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_244,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_245,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_246,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_247,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_248,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_249,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_250,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_251,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_252,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_253,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_254,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_255,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_256,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_257,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_258,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_259,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_260,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_261,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_262,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_263,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_264,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_265,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_266,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_267,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_268,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_269,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_270,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_271,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_272,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_273,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_274,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_275,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_276,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_277,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_278,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_279,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_280,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_281,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_282,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_283,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_284,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_285,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_286,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_287,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_288,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_289,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_290,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_291,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_292,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_293,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_294,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_295,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_296,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_297,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_298,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_299,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_300,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_301,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_302,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_303,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_304,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_305,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_306,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_307,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_308,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_309,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_310,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_311,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_312,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_313,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_314,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_315,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_316,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_317,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_318,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_319,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_320,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_321,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_322,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_323,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_324,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_325,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_326,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_327,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_328,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_329,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_330,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_331,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_332,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_333,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_334,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_335,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_336,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_337,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_338,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_339,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_340,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_341,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_342,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_343,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_344,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_345,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_346,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_347,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_348,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_349,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_350,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_351,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_352,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_353,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_354,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_355,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_356,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_357,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_358,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_359,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_360,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_361,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_362,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_363,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_364,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_365,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_366,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_367,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_368,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_369,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_370,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_371,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_372,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_373,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_374,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_375,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_376,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_377,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_378,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_379,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_380,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_381,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_382,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_383,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_384,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_385,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_386,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_387,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_388,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_389,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_390,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_391,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_392,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_393,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_394,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_395,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_396,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_397,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_398,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_399,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_400,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_401,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_402,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_403,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_404,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_405,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_406,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_407,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_408,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_409,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_410,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_411,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_412,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_413,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_414,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_415,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_416,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_417,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_418,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_419,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_420,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_421,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_422,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_423,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_424,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_425,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_426,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_427,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_428,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_429,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_430,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_431,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_432,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_433,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_434,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_435,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_436,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_437,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_438,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_439,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_440,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_441,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_442,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_443,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_444,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_445,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_446,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_447,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_448,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_449,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_450,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_451,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_452,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_453,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_454,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_455,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_456,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_457,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_458,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_459,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_460,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_461,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_462,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_463,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_464,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_465,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_466,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_467,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_468,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_469,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_470,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_471,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_472,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_473,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_474,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_475,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_476,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_477,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_478,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_479,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_480,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_481,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_482,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_483,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_484,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_485,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_486,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_487,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_488,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_489,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_490,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_491,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_492,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_493,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_494,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_495,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_496,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_497,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_498,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_499,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_500,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_501,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_502,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_503,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_504,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_505,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_506,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_507,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_508,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_509,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_510,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_511,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_512,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_513,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_514,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_515,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_516,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_517,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_518,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_519,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_520,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_521,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_522,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_523,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_524,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_525,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_526,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_527,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_528,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_529,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_530,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_531,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_532,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_533,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_534,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_535,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_536,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_537,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_538,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_539,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_540,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_541,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_542,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_543,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_544,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_545,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_546,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_547,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_548,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_549,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_550,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_551,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_552,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_553,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_554,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_555,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_556,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_557,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_558,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_559,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_560,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_561,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_562,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_563,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_564,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_565,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_566,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_567,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_568,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_569,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_570,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_571,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_572,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_573,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_574,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_575,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_576,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_577,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_578,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_579,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_580,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_581,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_582,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_583,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_584,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_585,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_586,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_587,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_588,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_589,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_590,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_591,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_592,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_593,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_594,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_595,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_596,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_597,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_598,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_599,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_600,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_601,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_602,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_603,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_604,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_605,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_606,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_607,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_608,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_609,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_610,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_611,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_612,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_613,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_614,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_615,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_616,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_617,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_618,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_619,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_620,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_621,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_622,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_623,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_624,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_625,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_626,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_627,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_628,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_629,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_630,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_631,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_632,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_633,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_634,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_635,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_636,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_637,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_638,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_639,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_640,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_641,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_642,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_643,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_644,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_645,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_646,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_647,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_648,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_649,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_650,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_651,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_652,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_653,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_654,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_655,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_656,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_657,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_658,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_659,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_660,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_661,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_662,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_663,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_664,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_665,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_666,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_667,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_668,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_669,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_670,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_671,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_672,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_673,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_674,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_675,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_676,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_677,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_678,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_679,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_680,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_681,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_682,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_683,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_684,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_685,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_686,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_687,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_688,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_689,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_690,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_691,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_692,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_693,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_694,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_695,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_696,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_697,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_698,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_699,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_700,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_701,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_702,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_703,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_704,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_705,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_706,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_707,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_708,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_709,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_710,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_711,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_712,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_713,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_714,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_715,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_716,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_717,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_718,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_719,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_720,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_721,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_722,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_723,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_724,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_725,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_726,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_727,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_728,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_729,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_730,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_731,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_732,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_733,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_734,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_735,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_736,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_737,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_738,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_739,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_740,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_741,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_742,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_743,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_744,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_745,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_746,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_747,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_748,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_749,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_750,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_751,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_752,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_753,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_754,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_755,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_756,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_757,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_758,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_759,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_760,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_761,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_762,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_763,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_764,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_765,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_766,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_767,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_768,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_769,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_770,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_771,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_772,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_773,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_774,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_775,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_776,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_777,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_778,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_779,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_780,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_781,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_782,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_783,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_784,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_785,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_786,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_787,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_788,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_789,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_790,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_791,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_792,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_793,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_794,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_795,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_796,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_797,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_798,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_799,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_800,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_801,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_802,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_803,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_804,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_805,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_806,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_807,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_808,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_809,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_810,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_811,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_812,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_813,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_814,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_815,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_816,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_817,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_818,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_819,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_820,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_821,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_822,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_823,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_824,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_825,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_826,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_827,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_828,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_829,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_830,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_831,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_832,x:194,y:261.3}).wait(1).to({graphics:mask_graphics_833,x:194,y:261.3}).wait(26));

	// ice
	this.instance_11 = new lib.ice_1();
	this.instance_11.setTransform(156,305,1,1,0,0,0,150,125);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(33).to({_off:false},0).wait(50).to({regX:150.1,scaleX:0.72,scaleY:0.72,x:155.05,y:274,alpha:0},8).to({_off:true},306).wait(462));

	// cold_ice
	this.instance_12 = new lib.text_cold_1();
	this.instance_12.setTransform(156,305,1,1,0,0,0,150,125);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({alpha:1},8).wait(42).to({regX:150.1,regY:125.1,scaleX:0.6155,scaleY:0.6155,x:156.15,y:278.1,alpha:0},8).to({_off:true},306).wait(462));

	// text_cold1
	this.instance_13 = new lib.copy_01();
	this.instance_13.setTransform(168.2,311.5,1,1,0,0,0,84.2,25.9);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(24).to({_off:false},0).to({alpha:1},9).wait(50).to({regX:84.3,regY:26.2,scaleX:0.6324,scaleY:0.6323,x:164.45,y:280.25},8).to({_off:true},306).wait(462));

	// text_cold2
	this.instance_14 = new lib.text_andFluSeason();
	this.instance_14.setTransform(151,305.95,1,1,0,0,0,102.2,20.2);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(93).to({_off:false},0).to({alpha:1},4).to({_off:true},300).wait(462));

	// text_cold3
	this.instance_15 = new lib.text_cold3();
	this.instance_15.setTransform(71,336.95,1,1,0,0,0,69,20.2);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(93).to({_off:false},0).to({alpha:1},4).to({_off:true},300).wait(462));

	// germs
	this.instance_16 = new lib.germs("synched",0,false);
	this.instance_16.setTransform(0,175);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(94).to({_off:false},0).wait(110).to({startPosition:110},0).to({alpha:0,startPosition:141},31).to({_off:true},10).wait(614));

	// white_box
	this.instance_17 = new lib.whitebox();
	this.instance_17.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(16).to({_off:false},0).to({alpha:0.4414},8).wait(39).to({alpha:1},31,cjs.Ease.get(1)).to({_off:true},277).wait(488));

	// logo
	this.instance_18 = new lib.logo_1();
	this.instance_18.setTransform(265.5,562,1,1,0,0,0,24.5,23);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(16).to({alpha:0},8,cjs.Ease.get(1)).to({_off:true},1).wait(834));

	// frost
	this.instance_19 = new lib.frost();
	this.instance_19.setTransform(150,126,1,1,0,0,0,150,125);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(25).to({_off:false},0).to({alpha:1},13).wait(821));

	// boy
	this.instance_20 = new lib.girl();
	this.instance_20.setTransform(169.4,144.7,0.9999,0.9999,-0.0009,0,0,169.4,144.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(63).to({alpha:0.0508},31,cjs.Ease.get(1)).to({_off:true},277).wait(488));

	// BG
	this.instance_21 = new lib.whitebox();
	this.instance_21.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({_off:true},371).wait(488));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-205.5,-299,861.9,1249);
// library properties:
lib.properties = {
	id: '3CE4C820892743FB9D5BF0281A417E72',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/boy.jpg?1574352472335", id:"boy"},
		{src:"images/boy_frost.jpg?1574352472335", id:"boy_frost"},
		{src:"images/germs_sm.png?1574352472335", id:"germs_sm"},
		{src:"images/hand_spray.png?1574352472335", id:"hand_spray"},
		{src:"images/ice.png?1574352472335", id:"ice"},
		{src:"images/logo.png?1574352472335", id:"logo"},
		{src:"images/product.jpg?1574352472335", id:"product"},
		{src:"images/spray_01.png?1574352472335", id:"spray_01"},
		{src:"images/spray_02.png?1574352472335", id:"spray_02"},
		{src:"images/text_cold.png?1574352472335", id:"text_cold"},
		{src:"images/whatittaketoprotect.jpg?1574352472335", id:"whatittaketoprotect"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3CE4C820892743FB9D5BF0281A417E72'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;